
import { Observable } from 'rxjs';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

export class  HttpRequestInterceptor implements HttpInterceptor {
    constructor() { } 

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        // request = request.clone({
        //     setHeaders: {
        //         'x-functions-key' : environment.apiKey
        //     }
        //   });

        return next.handle(request).pipe(tap(event => {
            if (event instanceof HttpResponse) {
                // do stuff with response if you want
                return event;
            }
        }, (err: any) => {
            if (err instanceof HttpErrorResponse) {
                console.log('error>>', err);
                return event;
            }
        }))
         
    } 
}
