import { Headers, RequestOptions } from '@angular/http';
import { UserData, UserAssociations, UserUnits, FeatureMenuPermissions } from './shared/models/user-data-model';
import { Subject, Observable } from 'rxjs';


export class AppConfig {

    userData;
    private subject = new Subject<any>();

    public getCurrentUser(): UserData {
         let currentUserObj = JSON.parse(String(localStorage.getItem('userData')));
        //let currentUserObj = this.userData;
        if (currentUserObj) {
            var currUser = new UserData();
            var userAssociations = new Array<UserAssociations>();
            var userUnits = new Array<UserUnits>();
            var featureMenuPermissions = new Array<FeatureMenuPermissions>();
            currUser.Role = currentUserObj.UserClaim.Role;
            currUser.UserName = currentUserObj.UserClaim.FirstName + ' ' + currentUserObj.UserClaim.LastName;
            currUser.UserProfileId = currentUserObj.UserClaim.UserProfileId;
            currUser.LastLogin = currentUserObj.UserClaim.LastLogin;
            if (currentUserObj.UserClaim.UserAssociations != null) {
                currentUserObj.UserClaim.UserAssociations.forEach(element => {
                    let userAssociation: UserAssociations = {
                        AssociationId: element.AssociationId,
                        Name: element.Name,
                        Domain: element.Domain,
                        PMCompanyId: element.PMCompanyId,
                        PMCompanyAssociationMappingId: element.PMCompanyAssociationMappingId
                    }
                    userAssociations.push(userAssociation);
                });
            }
            if (currentUserObj.UserClaim.UserUnits != null) {
                currentUserObj.UserClaim.UserUnits.forEach(element => {
                    let userUnit: UserUnits = {
                        UnitId: element.UnitId,
                        UnitNumber: element.UnitNumber
                    }
                    userUnits.push(userUnit);
                });
            }

            if (currentUserObj.UserClaim.FeatureMenuPermissions != null) {
                currentUserObj.UserClaim.FeatureMenuPermissions.forEach(element => {
                    let featureMenuPermission: FeatureMenuPermissions = {
                        UnitId: element.UnitId,
                        MenuOrder: element.MenuOrder,
                        IsMenuItem: element.IsMenuItem,
                        FeatureParentId: element.FeatureParentId,
                        Name: element.Name,
                        PMCompanyId: element.PMCompanyId,
                        AssociationId: element.AssociationId,
                        FeatureMenuImage: element.FeatureMenuImage,
                        FeatureId: element.FeatureId,
                        CanUpdate: element.CanUpdate,
                        CanDelete: element.CanDelete,
                        CanRead: element.CanRead,
                        CanCreate: element.CanCreate,
                        WebPage: element.WebPage
                    }
                    featureMenuPermissions.push(featureMenuPermission);
                });
            }
            currUser.FeatureMenuPermissions = featureMenuPermissions;
            currUser.UserUnits = userUnits;
            currUser.UserAssociations = userAssociations;
            return currUser;
        }
        else {
            return null;
        }
    }

    public setCurrentUser(model: any) {
       // localStorage.removeItem('userData');
        localStorage.setItem('userData', JSON.stringify(model));
        this.subject.next({ data: model });
        this.userData = model;
    }


    clearMessage() {
        this.subject.next();
    }

    getData() {
       return this.subject.asObservable()
    }

    public removeCurrentUser() {
        localStorage.removeItem('email');
    }

    public isAuthenticated(): boolean {
        const currentUser = JSON.parse(String(localStorage.getItem('email')));
        if (currentUser !== null && currentUser !== undefined) {
            return true;
        }
        else {
            return false;
        }
    }
};
