import { Component } from '@angular/core';
import { LoginApiService } from './services/login-api.service';
import { AppConfig } from 'src/app/app.config';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'app';
  resData
  constructor(private service: LoginApiService, private readonly appConfig: AppConfig){
    //this.getData();
  }

   getData() {
    this.service.login(localStorage.getItem('email')).subscribe(res => {
      this.resData = res
      if(this.resData.Errors.length !== 0)
        alert('Invalid UserName or Password');
      else {
        this.appConfig.setCurrentUser(this.resData);
      }
    },
    (err) => {
      console.log(err);
    }
  );
  }
}
