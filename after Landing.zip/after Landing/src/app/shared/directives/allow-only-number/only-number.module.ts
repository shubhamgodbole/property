import { NgModule } from '@angular/core';
import { NumberOnlyDirective } from "./only-number.directive";
import { CommonModule } from '@angular/common';

@NgModule({
  declarations: [
    NumberOnlyDirective
  ],
  imports: [CommonModule],
  exports: [
    NumberOnlyDirective
  ]
})

export class NumberOnlyDirectiveModule {
}
