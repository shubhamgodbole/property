import { ValidatorFn, AbstractControl, ValidationErrors } from "@angular/forms";

export class ValidationService {
  static getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
    let config: any = {
      'invalidPassword': 'Invalid password. Password must be at least 6 characters long, and contain a number.',
    };
    return config[validatorName];
  }


  static emailValidator(control: any) {
    if (control.value === null) return null;
    var ctrl = control.value.trim();
    if (ctrl.match(/^\w+([-+.']\w+)*@[^_\W]+([-.]\w+)*\.\w+([-.]\w+)*([A-Za-z])$/)) {
      return null;
    } else {
      return { 'invalidEmailAddress': true };
    }
  }

  
  static phoneNumberValidator(control: any) {
    if (control.value === null || control.value === "") return null;
    if (control.value.match(/^\d{3}\d{3}\d{4}$/)) {
      return null;
    } else {
      return { 'invalidPhoneNumber': true };
    }
  }

  static passwordValidator(control: any) {
    if (control.value === null) return null;
    if (control.value.match(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{6,}$/)) {
      return null;
    } else {
      return { 'invalidPassword': true };
    }
  }
}

export const ConfirmPasswordValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {

  if (!control.parent || !control) {
    return null;
  }

  const password = control.parent.get('newPassword');
  const passwordConfirm = control.parent.get('confirmPassword');

  if (!password || !passwordConfirm) {
    return null;
  }

  if (passwordConfirm.value === '') {
    return null;
  }

  if (password.value === passwordConfirm.value) {
    return null;
  }

  return { 'passwordsNotMatching': true };
};
