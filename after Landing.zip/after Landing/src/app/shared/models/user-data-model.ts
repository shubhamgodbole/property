export class UserData 
{
    UserProfileId: string
    Email: string
    FeatureMenuPermissions: FeatureMenuPermissions[]
    LastLogin: string
    UserName: string
    UserAssociations: UserAssociations []
    UserUnits: UserUnits[]
    Role: string
}

export class FeatureMenuPermissions
{
    UnitId: string
    MenuOrder: string
    IsMenuItem: true
    FeatureParentId: string
    Name: string
    PMCompanyId: string
    AssociationId: string
    FeatureMenuImage: string
    FeatureId:string
    CanUpdate: string
    CanDelete: string
    CanRead: string
    CanCreate: string
    WebPage: string
}

export class UserAssociations
{
    AssociationId: string
    Name: string
    Domain: string
    PMCompanyId: string
    PMCompanyAssociationMappingId: string
}

export class UserUnits
{
    UnitId: string
    UnitNumber: string
}