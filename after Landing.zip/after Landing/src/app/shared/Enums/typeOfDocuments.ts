export enum TypeOfDocument
{
    NewsLetterDocuments = "NewsLetterDocuments",
    ViolationReportedDocuments = "ViolationReportedDocuments",
    UserDocuments = "UserDocuments",
    UnitDocuments = "UnitDocuments",
    ServiceRequestDocuments= "ServiceRequestDocuments",
    MeetingDocuments = "MeetingDocuments",
    MeetingMinuteDocuments = "MeetingMinuteDocuments",
    HomeSaleDocuments = "HomeSaleDocuments",
    AssociationImages = "AssociationImages",
    CaseDocuments = "CaseDocuments",
    AssociationDocuments = "AssociationDocuments",
    ARCProjectCompletionDocuments = "ARCProjectCompletionDocuments",
    ARCRequestDocuments = "ARCRequestDocuments",
    ClassifiedAdDocuments = "ClassifiedAdDocuments",
    ServiceActivityDocuments = "ServiceActivityDocuments",
    EventDocuments = "EventDocuments",
    BoardConversationDocuments = "BoardConversationDocuments"
}