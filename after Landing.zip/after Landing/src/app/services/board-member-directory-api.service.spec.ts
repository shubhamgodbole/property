import { TestBed, inject } from '@angular/core/testing';

import { BoardMemberDirectoryApiService } from './board-member-directory-api.service';

describe('BoardMemberDirectoryApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BoardMemberDirectoryApiService]
    });
  });

  it('should be created', inject([BoardMemberDirectoryApiService], (service: BoardMemberDirectoryApiService) => {
    expect(service).toBeTruthy();
  }));
});
