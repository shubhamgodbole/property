import { TestBed, inject } from '@angular/core/testing';

import { BoardTaskApiService } from './board-task-api.service';

describe('BoardTaskApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BoardTaskApiService]
    });
  });

  it('should be created', inject([BoardTaskApiService], (service: BoardTaskApiService) => {
    expect(service).toBeTruthy();
  }));
});
