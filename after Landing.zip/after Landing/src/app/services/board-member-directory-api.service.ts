import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BoardMemberDirectoryApiService {

  constructor(private http: HttpClient, private commonService: CommonService) { }
  url = environment.baseUrl + 'BoardMemberRequests'

  getBoardMembers(associationId) {
    const requestParam = { associationId }
    const data = this.commonService.getBodyData(requestParam, 'BoardMember', 'List');
    return this.http.post(this.url, JSON.stringify(data));
  }

  getMasterData(associationId){
    const requestParam = { associationId }
    const data = this.commonService.getBodyData(requestParam, 'BoardMember', 'GetMasterData');
    return this.http.post(this.url, JSON.stringify(data));
  }

  addBoardMember(boardMember, associationDomain){
    const requestParam = { boardMember , associationDomain}
    const data = this.commonService.getBodyData(requestParam, 'BoardMember', 'AddBoardMember');
    return this.http.post(this.url,  JSON.stringify(data));
  }

  editBoardMember(boardMember){
    const requestParam = { boardMember }
    const data = this.commonService.getBodyData(requestParam, 'BoardMember', 'UpdateBoardMember');
    return this.http.post(this.url, JSON.stringify(data));
  }

}
