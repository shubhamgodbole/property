import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CommitteeApiService {
  public headers: any = new Headers();

    committeeUrl  = environment.baseUrl + 'CommitteeRequest';
    constructor(private http: HttpClient, private commonService: CommonService) { }
    getAllCommittee(AssociationId) {
      const requestParam = {
        "AssociationId":AssociationId,
        "Domain": "testassociation",
        "DesignationDocumentType": "DesignationTypes",
        "CommitteeDocumentType": "CommitteeTypes"
      }
      const data = this.commonService.getBodyData(requestParam, 'Committee', 'List');
      return this.http.post(this.committeeUrl, data);
    }
    addCommittee(CommitteeData,imageStream) {
      const requestParam = {
        "AssociationCommittee": CommitteeData,
        "Domain": "testassociation",
        "ImageStream": imageStream
      }
      const data = this.commonService.getBodyData(requestParam, 'Committee', 'Add');
      return this.http.post(this.committeeUrl, data);
    }
    addCommitteeMember(AssociationCommitteeUser,AssociationCommitteeId) {
      const requestParam = {
        "AssociationCommitteeUser": AssociationCommitteeUser,
        "Domain": "testassociation",
        "AssociationCommitteeId": AssociationCommitteeId
      }
      const data = this.commonService.getBodyData(requestParam, 'Committee', 'AddCommitteeMember');
      return this.http.post(this.committeeUrl,data);
    }
    getAllMember(AssociationId,AssociationCommitteeId) {
      const requestParam = {
        "AssociationId": AssociationId,
        "AssociationCommitteeId": AssociationCommitteeId
      }
      const data = this.commonService.getBodyData(requestParam, 'Committee', 'GetMemberForCommittee');
      return this.http.post(this.committeeUrl, data);
    }
    sendMessage(CommitteeContactData) {
      const requestParam = {
        "CommitteeContactData": CommitteeContactData
      }
      const data = this.commonService.getBodyData(requestParam, 'Committee', 'Contact');
      return this.http.post(this.committeeUrl, data);
    }
    updateCommittee(AssociationCommittee,ImageStream) {
      const requestParam = {
        "AssociationCommittee": AssociationCommittee,
        "Domain": "testassociation",
        "ImageStream":ImageStream
      }
      const data = this.commonService.getBodyData(requestParam, 'Committee', 'Update');
      return this.http.post(this.committeeUrl, data);
    }
    sendUserJoinRequest(AssociationCommitteeJoinRequest,AssociationCommitteeId) {
      const requestParam = {
        "AssociationCommitteeId":AssociationCommitteeId,
        "AssociationCommitteeJoinRequest": AssociationCommitteeJoinRequest
      }
      const data = this.commonService.getBodyData(requestParam, 'Committee', 'AddUserJoinRequest');
      return this.http.post(this.committeeUrl, data);
    }
}
