import { TestBed, inject } from '@angular/core/testing';

import { MeetingApiService } from './meeting-api.service';

describe('MeetingApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MeetingApiService]
    });
  });

  it('should be created', inject([MeetingApiService], (service: MeetingApiService) => {
    expect(service).toBeTruthy();
  }));
});
