import { TestBed, inject } from '@angular/core/testing';

import { AssociationLandingService } from './association-landing.service';

describe('AssociationLandingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AssociationLandingService]
    });
  });

  it('should be created', inject([AssociationLandingService], (service: AssociationLandingService) => {
    expect(service).toBeTruthy();
  }));
});
