import { TestBed, inject } from '@angular/core/testing';

import { HoaDirectoryApiService } from './hoa-directory-api.service';

describe('HoaDirectoryApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HoaDirectoryApiService]
    });
  });

  it('should be created', inject([HoaDirectoryApiService], (service: HoaDirectoryApiService) => {
    expect(service).toBeTruthy();
  }));
});
