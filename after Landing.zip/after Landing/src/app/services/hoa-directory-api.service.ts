import { Injectable } from '@angular/core';
import { CommonService } from './common.service';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class HoaDirectoryApiService {
  userId: string;
  associationUnitId: string;
  associationId: string;
  url = environment.baseUrl + 'UserProfileRequest';
  changePasswordUrl = environment.baseUrl + 'UserAuthentication';

  constructor(private http: HttpClient, private commonService: CommonService) { }

  getHoaDirectory(associationId) {
    const requestParam = { associationId }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'List');
    return this.http.post(this.url, JSON.stringify(data));
  }

  getMyprofile(userId, requestId) {
    const requestParam = { userId, requestId }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'Detail');
    return this.http.post(this.url, JSON.stringify(data));
  }

  getHoaDetails(userId, requestId, associationId) {
    const requestParam = { userId, requestId, associationId }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'HOADetail');
    return this.http.post(this.url, JSON.stringify(data));
  }

  doChangePassword(changePasswordModel) {
    const userId = changePasswordModel.userId;
    const oldPassword = changePasswordModel.currentPassword;
    const newPassword = changePasswordModel.newPassword;
    const requestParam = { userId, oldPassword, newPassword }
    const data = this.commonService.getBodyData(requestParam, 'UserLogin', 'ChangePassword');
    return this.http.post(this.changePasswordUrl, JSON.stringify(data));
  }

  changeProfilePicture(userId, inputStream) {
    const requestParam = { userId, inputStream }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'ProfilePicture');
    return this.http.post(this.url, JSON.stringify(data));
  }

  changeCoverPicture(userId, inputStream) {
    const requestParam = { userId, inputStream }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'CoverProfilePicture');
    return this.http.post(this.url, JSON.stringify(data));
  }

  deleteVehical(userId, unitId, requestId) {
    const requestParam = { userId, unitId, requestId }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'DeleteVehical');
    return this.http.post(this.url, JSON.stringify(data));
  }
  deleteTenant(userId, unitId, requestId) {
    const requestParam = { userId, unitId, requestId }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'DeleteTenant');
    return this.http.post(this.url, JSON.stringify(data));
  }
  deletePet(userId, unitId, requestId) {
    const requestParam = { userId, unitId, requestId }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'DeletePet');
    return this.http.post(this.url, JSON.stringify(data));
  }

  createPet(UnitPets: any,userId:string) {
    const requestParam = { UnitPets,userId }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'AddPet');
    return this.http.post(this.url, JSON.stringify(data));
  }

  editPet(UnitPets: any,userId:string) {
    const requestParam = { UnitPets,userId }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'UpdatePet');
    return this.http.post(this.url, JSON.stringify(data));
  }
  createVehicle(UnitVehicles: any,userId:string) {
    const requestParam = { UnitVehicles,userId }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'AddVehical');
    return this.http.post(this.url, JSON.stringify(data));
  }

  editVehicle(UnitVehicles: any,userId:string) {
    const requestParam = { UnitVehicles,userId }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'UpdateVehical');
    return this.http.post(this.url, JSON.stringify(data));
  }

  EditBasicDetails(UnitPets: any,userId:string) {
    const requestParam = { UnitPets,userId }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'UpdateEmergencyContact');
    return this.http.post(this.url, JSON.stringify(data));
  }

  createEmergencyContact(UnitEmergencyContacts: any,userId:string) {
    const requestParam = { UnitEmergencyContacts,userId }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'AddEmergencyContact');
    return this.http.post(this.url, JSON.stringify(data));
  }
  
  editEmergencyContact(UnitEmergencyContacts: any,userId:string) {
    const requestParam = { UnitEmergencyContacts,userId }
    const data = this.commonService.getBodyData(requestParam, 'UserProfile', 'UpdateEmergencyContact');
    return this.http.post(this.url, JSON.stringify(data));
  }

}
