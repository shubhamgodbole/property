import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class AssociationLandingService {
  serviceRequestUrl = environment.baseUrl + 'UserAuthentication';
  constructor(private http: HttpClient,private commonService: CommonService) { }
  getAssociationLandingData(AssociationId,DocumentType,Domain,UserId) {
    const requestParam = { AssociationId,DocumentType,Domain,UserId }
    const data = this.commonService.getBodyData(requestParam, 'AssociationLanding', 'AssociationLanding');
    return this.http.post(this.serviceRequestUrl, JSON.stringify(data));
  }
  uploadData(Domain,AssociationId,AssociationImages,DocumentType) {
    const requestParam = { Domain,AssociationId,AssociationImages,DocumentType }
    const data = this.commonService.getBodyData(requestParam, 'AssociationLanding', 'AddAssociationImages');
    return this.http.post(this.serviceRequestUrl, JSON.stringify(data));
  }
  soldClassifiedAdds(ClassifiedAdId,soldDate,userId) {
    const requestParam = {
      "ClassifiedAdId": ClassifiedAdId,
      "soldDate": soldDate,
      "UserId":userId
	  }
    const data = this.commonService.getBodyData(requestParam, 'AssociationLanding', 'MarkSold');
    return this.http.post(this.serviceRequestUrl, JSON.stringify(data));
  }
  deleteClassifiedAdds(deleteID,userId) {
    const requestParam = {
      "ClassifiedAdId": deleteID,
      "UserId":userId
	  }
    const data = this.commonService.getBodyData(requestParam, 'AssociationLanding', 'Delete');
    return this.http.post(this.serviceRequestUrl, JSON.stringify(data));
  }
  
}
