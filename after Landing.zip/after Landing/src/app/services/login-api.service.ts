import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Headers, Http } from '@angular/http';
import { CommonService } from './common.service';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class LoginApiService {
  //private headers = new Headers({ 'Content-Type': 'application/json', 'x-functions-key': 'OGgzsHuSrLufdTGFrLxtCoUoHUE1amjqKWwBAcF0rcpr2wMgP16dZQ==' });
  constructor(private http: HttpClient, private commonService: CommonService) { }
  url = environment.baseUrl + 'UserAuthentication';

   login(username) {
    const requestParam = { username }
    const data = this.commonService.getBodyData(requestParam, 'UserLogin', 'Login');
    return this.http.post(this.url, JSON.stringify(data));
  }

  forgotPassword(userName) {
    const TokenUrl = "https://testassociation.devpropvivo.com/resetpassword?token={{0}}"
    const requestParam = { userName, TokenUrl }
    const data = this.commonService.getBodyData(requestParam, 'UserLogin', 'ForgetPassword');
    return this.http.post(this.url, data)//{ headers: this.headers });
  }

  validateActivationCade(activationCode) {
    const requestParam = { activationCode }
    const data = this.commonService.getBodyData(requestParam, 'UserLogin', 'ValidateActivationCode');
    return this.http.post(this.url, JSON.stringify(data));
  }

  updatePassword(password) {
    const tokenId = 'qldXnGd8njbZDjWT';
    const requestParam = { password, tokenId }
    const data = this.commonService.getBodyData(requestParam, 'UserLogin', 'PasswordReset');
    return this.http.post(this.url, JSON.stringify(data));
  }

  requestIncorectInfo(requestActivationCode) {
    const requestParam = { requestActivationCode }
    const data = this.commonService.getBodyData(requestParam, 'UserLogin', 'RequestActivationCode');
    return this.http.post(this.url, JSON.stringify(data));
  }

  registration(username, password, activationCode) {
    const requestParam = { username, password, activationCode }
    const data = this.commonService.getBodyData(requestParam, 'UserLogin', 'Registration');
    return this.http.post(this.url, JSON.stringify(data));
  }

  getMasterData() {
    const data = this.commonService.getBodyData({}, 'UserLogin', 'GetMasterData');
    return this.http.post(this.url, JSON.stringify(data));
  }
}
