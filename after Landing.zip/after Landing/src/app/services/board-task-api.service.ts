import { Injectable } from '@angular/core';
import { CommonService } from './common.service';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class BoardTaskApiService {
  boardTaskDetailId: string = "";
  caseId: string = "";
  domain: string = "";
  boardTaskStatus: string = "";
  url = environment.baseUrl + 'CaseRequests';
  constructor(private http: HttpClient, private commonService: CommonService) { }

  getBoardTask(associationId, role) {
    const requestParam = { associationId, role }
    const data = this.commonService.getBodyData(requestParam, 'BoardTask', 'List');
    return this.http.post(this.url, JSON.stringify(data));
  }

  getFilteredBoardTask(associationId, role, statusType, priority, caseCategory, filterByKeyWords) {
    const requestParam = { associationId, role, statusType, priority, caseCategory, filterByKeyWords }
    const data = this.commonService.getBodyData(requestParam, 'BoardTask', 'List');
    return this.http.post(this.url, JSON.stringify(data));
  }

  getCaseCategoryDdl(customerType, caseType) {
    const requestParam = { customerType, caseType };
    const data = this.commonService.getBodyData(requestParam, 'BoardTask', 'CaseCategory');
    return this.http.post(this.url, JSON.stringify(data));
  }

  createBoardTask(requestMessage: any) {
    const data = this.commonService.getBodyData(requestMessage, 'BoardTask', 'Add');
    return this.http.post(this.url, JSON.stringify(data));
  }

  getBoardTaskDetails(requestId, domain) {
    const requestParam = { requestId, domain }
    const data = this.commonService.getBodyData(requestParam, 'BoardTask', 'Detail');
    return this.http.post(this.url, JSON.stringify(data));
  }

  createCaseNote(request: any) {
    const data = this.commonService.getBodyData(request, 'CaseNote', 'Add');
    return this.http.post(this.url, JSON.stringify(data));
  }

  updateBoardTaskStatus(requestMessage: any) {
    const data = this.commonService.getBodyData(requestMessage, 'BoardTask', 'UpdateStatus');
    return this.http.post(this.url, JSON.stringify(data));
  }

  createMotion(requestId, requestMessage: any) {
    const requestParam = { "motion": requestMessage, "RequestId": requestId }
    const data = this.commonService.getBodyData(requestParam, 'Motion', 'Add');
    return this.http.post(this.url, JSON.stringify(data));
  }

  createMotionVote(caseId: string, requestId: string, associationId: string, votes: any) {
    const CaseId = caseId;
    const RequestId = requestId;
    const AssociationId = associationId;
    const Votes = votes;
    const requestParam = { CaseId, RequestId, AssociationId, Votes }
    const data = this.commonService.getBodyData(requestParam, 'BoardTask', 'CreateVote');
    return this.http.post(this.url, JSON.stringify(data));
  }
}
