import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ServiceRequestService {
  
  serviceRequestUrl = environment.baseUrl + 'CaseRequests';
  requestId: any;
  domain:string; 
  constructor(private http: HttpClient, private commonService: CommonService) { }

  getAllServiceRequest(UserId,AssociationId, Role, StatusType,CaseCategory,Priority,SeachString) {
    const requestParam = { UserId,AssociationId, Role,CaseCategory, StatusType, Priority,SeachString }
    const data = this.commonService.getBodyData(requestParam, 'ServiceRequest', 'List');
    return this.http.post(this.serviceRequestUrl, JSON.stringify(data));
  }
  
  getServiceRequestDetail(RequestId) {
    const requestParam = { RequestId:RequestId,Domain:this.domain}
    const data = this.commonService.getBodyData(requestParam, 'ServiceRequest', 'Detail');
    return this.http.post(this.serviceRequestUrl, JSON.stringify(data));
  }

  sortAllCategoryServiceRequest(AssociationId, Role,CaseCategory, StatusType, Priority) {
    const requestParam = { AssociationId, Role,CaseCategory, StatusType, Priority }
    const data = this.commonService.getBodyData(requestParam, 'ServiceRequest', 'List');
    return this.http.post(this.serviceRequestUrl, JSON.stringify(data));
  }

  getAllCategories(CustomerType, CaseType) {
    const requestParam = {
      "CustomerType": CustomerType,
      "CaseType": CaseType,
    }
    const data = this.commonService.getBodyData(requestParam, 'ServiceRequest', 'CaseCategory');
    return this.http.post(this.serviceRequestUrl, JSON.stringify(data));
  }
  getAllAssociationUnit(UserId, AssociationId) {
    const requestParam = {UserId,AssociationId }
    const data = this.commonService.getBodyData(requestParam, 'ServiceRequest', 'AssociationUnit');
    return this.http.post(this.serviceRequestUrl, JSON.stringify(data));
  }
  addRequest(requestMessage) {
    const data = this.commonService.getBodyData(requestMessage, 'ServiceRequest', 'Add');
    return this.http.post(this.serviceRequestUrl, JSON.stringify(data));
  }
  addCaseNote(requestMessage) {   
    const data = this.commonService.getBodyData(requestMessage, 'CaseNote', 'Add');
    return this.http.post(this.serviceRequestUrl,JSON.stringify(data));
  }

  addMotion(motion) {   
    const requestParam = { motion};
    const data = this.commonService.getBodyData(requestParam, 'Motion', 'Add');
    return this.http.post(this.serviceRequestUrl,JSON.stringify(data));
  }
  vote(CaseId,AssociationId,RequestId,Votes) {   
    const requestParam = { CaseId,AssociationId,RequestId,Votes};
    const data = this.commonService.getBodyData(requestParam, 'ServiceRequest', 'CreateVote');
    return this.http.post(this.serviceRequestUrl,JSON.stringify(data));
  }

  updatServiceRequestStatus(requestMessage: any) {
    const data = this.commonService.getBodyData(requestMessage, 'ServiceRequest', 'UpdateStatus');
    return this.http.post(this.serviceRequestUrl, JSON.stringify(data));
  }
  rate(RequestId,Domain,CaseSatisfaction) {   
    const requestParam = { RequestId,Domain,CaseSatisfaction};
    const data = this.commonService.getBodyData(requestParam, 'ServiceRequest', 'UpdateRating');
    return this.http.post(this.serviceRequestUrl,JSON.stringify(data));
  }
}
