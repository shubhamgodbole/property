import { TestBed, inject } from '@angular/core/testing';

import { MarketPlaceApiService } from './market-place-api.service';

describe('MarketPlaceApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MarketPlaceApiService]
    });
  });

  it('should be created', inject([MarketPlaceApiService], (service: MarketPlaceApiService) => {
    expect(service).toBeTruthy();
  }));
});
