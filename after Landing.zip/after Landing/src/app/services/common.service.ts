import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class CommonService {
  url = environment.baseUrl + 'UserAuthentication';
  userData
  constructor(private http: HttpClient) { 
    //this.setUserData();
  }
  email = localStorage.getItem("email");
  
    getBodyData(requestParam, requestType, requestSubType) {
        const data = {
          RequestType: requestType,
          RequestSubType: requestSubType,
          RequestParam: requestParam
        };
        return data;
    }

    getUserData(){
      const requestParam = { UserName: this.email, password: '' }
      const data = this.getBodyData(requestParam, 'UserLogin', 'Login');
      let resData;
      this.http.post(this.url, data).subscribe(
      (res)=>{
        resData = res;
        //localStorage.setItem("UserName");
      }
    );
    }

  }
