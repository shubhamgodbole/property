import { TestBed, inject } from '@angular/core/testing';

import { ArcRequestApiService } from './arc-request-api.service';

describe('ArcRequestApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ArcRequestApiService]
    });
  });

  it('should be created', inject([ArcRequestApiService], (service: ArcRequestApiService) => {
    expect(service).toBeTruthy();
  }));
});
