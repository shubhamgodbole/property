import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { CommonService } from './common.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DocumentsApiService {

  url = environment.baseUrl + 'AssociationDocument';
  
  constructor(private http: HttpClient , private commonService: CommonService) { }
 
  getDocument(associationId,domain,typeOfDocument) {
    const requestParam = { associationId,domain,typeOfDocument }
    const data = this.commonService.getBodyData(requestParam, 'Documents', 'List');
     return this.http.post(this.url, JSON.stringify(data));
  }

  deleteDocument(documentId) {
    const requestParam = {documentId}
    const data = this.commonService.getBodyData(requestParam, 'Documents', 'Delete');
     return this.http.post(this.url, JSON.stringify(data));
  }
  getDocumentCategoryDdl(associationId,canRead,userId) {
    const requestParam = { associationId,canRead,userId}
    const data = this.commonService.getBodyData(requestParam, 'Documents', 'Create');
     return this.http.post(this.url, JSON.stringify(data));
  }

  createDocument(requestMessage:any) {   
    const data = this.commonService.getBodyData(requestMessage, 'Documents', 'Add');
     return this.http.post(this.url, JSON.stringify(data));
  }

  
  editDocument(requestMessage:any) {   
    const data = this.commonService.getBodyData(requestMessage, 'Documents', 'Update');
     return this.http.post(this.url, JSON.stringify(data));
  }
}
