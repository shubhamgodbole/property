import { TestBed, inject } from '@angular/core/testing';

import { PaymentsApiService } from './payments-api.service';

describe('PaymentsApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PaymentsApiService]
    });
  });

  it('should be created', inject([PaymentsApiService], (service: PaymentsApiService) => {
    expect(service).toBeTruthy();
  }));
});
