import { TestBed, inject } from '@angular/core/testing';

import { DocumentsApiService } from './documents-api.service';

describe('DocumentsApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DocumentsApiService]
    });
  });

  it('should be created', inject([DocumentsApiService], (service: DocumentsApiService) => {
    expect(service).toBeTruthy();
  }));
});
