import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MeetingApiService {

  url = environment.baseUrl + 'MeetingRequest';

  constructor(private http: HttpClient, private commonService: CommonService) { }

  getMeetingList(associationId, userId) {
    const requestParam = { associationId, userId }
    const data = this.commonService.getBodyData(requestParam, 'Meeting', 'List');
    return this.http.post(this.url, JSON.stringify(data));
  }

  getMeetingDetail(meetingId, domain) {
    const requestParam = { meetingId, domain}
    const data = this.commonService.getBodyData(requestParam, 'Meeting', 'Detail');
    return this.http.post(this.url, JSON.stringify(data));
  }

  getMasterData() {
    const requestParam = { }
    const data = this.commonService.getBodyData(requestParam, 'Meeting', 'GetMasterData');
    return this.http.post(this.url, JSON.stringify(data));
  }

  createMeeting(addUpdateMeetingData, requestDocuments, typeOfDocument, domain) {
    const requestParam = {addUpdateMeetingData, requestDocuments, typeOfDocument, domain}
    const data = this.commonService.getBodyData(requestParam, 'Meeting', 'Add');
    return this.http.post(this.url, JSON.stringify(data));
  }

  cancelMeeting(meetingId) {
    const requestParam = { meetingId }
    const data = this.commonService.getBodyData(requestParam, 'Meeting', 'CancelMeeting');
    return this.http.post(this.url, JSON.stringify(data));
  }

  addRSVP(meetingId, meetingRSVP){
    const requestParam = { meetingId , meetingRSVP}
    const data = this.commonService.getBodyData(requestParam, 'Meeting', 'AddMeetingRSVP');
    return this.http.post(this.url, JSON.stringify(data));
  }

  uploadMeetingMinutes(meetingMinutes, requestDocuments, typeOfDocument, meetingId, domain) {
    const requestParam = {meetingMinutes, requestDocuments, typeOfDocument,  domain, meetingId}
    const data = this.commonService.getBodyData(requestParam, 'Meeting', 'UploadMeetingMinute');
    return this.http.post(this.url, JSON.stringify(data));
  }

}
