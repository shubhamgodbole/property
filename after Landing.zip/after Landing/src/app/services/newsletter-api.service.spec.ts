import { TestBed, inject } from '@angular/core/testing';

import { NewsletterApiService } from './newsletter-api.service';

describe('NewsletterApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NewsletterApiService]
    });
  });

  it('should be created', inject([NewsletterApiService], (service: NewsletterApiService) => {
    expect(service).toBeTruthy();
  }));
});
