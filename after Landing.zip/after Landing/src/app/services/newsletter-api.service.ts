import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { CommonService } from './common.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class NewsletterApiService {
  url = environment.baseUrl + 'AssociationDocument';

  constructor(private http: HttpClient , private commonService: CommonService) { }
  
  getNewsletterDocument(associationId,domain,typeOfDocument) {
    const requestParam = { associationId,domain,typeOfDocument }
    const data = this.commonService.getBodyData(requestParam, 'Newsletter', 'List');
     return this.http.post(this.url,JSON.stringify(data));
  }

  deleteNewsletter(documentId) {
    const requestParam = { documentId}
    const data = this.commonService.getBodyData(requestParam, 'Newsletter', 'Delete');
     return this.http.post(this.url, JSON.stringify(data));
  }
 
  createNewsletter(requestMessage:any) {   
    const data = this.commonService.getBodyData(requestMessage, 'Newsletter', 'Add');
     return this.http.post(this.url, JSON.stringify(data));
  }

  editNewsletter(requestMessage:any) {   
    const data = this.commonService.getBodyData(requestMessage, 'Newsletter', 'Update');
     return this.http.post(this.url, JSON.stringify(data));
  }
}

