import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ArcRequestApiService {

  url = environment.baseUrl + 'CaseRequests';
  arcRequestId: string = '';

  constructor(private http: HttpClient, private commonService: CommonService) { }

  getFilteredARCRequestForBM(associationId, role, statusType, filterByKeyWords) {
    const requestParam = { associationId, role, statusType, filterByKeyWords }
    const data = this.commonService.getBodyData(requestParam, 'ARCRequest', 'List');
    return this.http.post(this.url, JSON.stringify(data));
  }

  getFilteredARCRequestForHo(associationId, userId, role, statusType, filterByKeyWords) {
    const requestParam = { associationId, userId, role, statusType, filterByKeyWords }
    const data = this.commonService.getBodyData(requestParam, 'ARCRequest', 'List');
    return this.http.post(this.url, JSON.stringify(data));
  }

  getARCRequestDetail(requestId, domain) {
    const requestParam = { requestId, domain}
    const data = this.commonService.getBodyData(requestParam, 'ARCRequest', 'Detail');
    return this.http.post(this.url, JSON.stringify(data));
  }

  
}
