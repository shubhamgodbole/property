import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PaymentsApiService {

  url = environment.baseUrl + 'FinancialReport';

  constructor(private http: HttpClient, private commonService: CommonService) { }

  getBalanceSheet(balanceSheetReport) {
    const requestParam = { balanceSheetReport }
    const data = this.commonService.getBodyData(requestParam, 'BalanceSheet', '');
    return this.http.post(this.url, JSON.stringify(data));
  }

  getIncomeSheet(incomeSheetReport) {
    const requestParam = { incomeSheetReport }
    const data = this.commonService.getBodyData(requestParam, 'IncomeSheet', '');
     return this.http.post(this.url, JSON.stringify(data));
  }

  getDeliquency(customerAgingReport) {
    const requestParam = { customerAgingReport }
    const data = this.commonService.getBodyData(requestParam, 'Deliquency', '');
     return this.http.post(this.url, JSON.stringify(data));
  }

  getGeneralLedger(generalLedgerReport) {
    const requestParam = { generalLedgerReport }
    const data = this.commonService.getBodyData(requestParam, 'GenralLedger', '');
     return this.http.post(this.url, JSON.stringify(data));
  }

  getPrePayment(customerAgingReport) {
    const requestParam = { customerAgingReport }
    const data = this.commonService.getBodyData(requestParam, 'PrePayment', '');
     return this.http.post(this.url, JSON.stringify(data));
  }

}
