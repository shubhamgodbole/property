import { TestBed, inject } from '@angular/core/testing';

import { CommitteeApiService } from './committee-api.service';

describe('CommitteeApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CommitteeApiService]
    });
  });

  it('should be created', inject([CommitteeApiService], (service: CommitteeApiService) => {
    expect(service).toBeTruthy();
  }));
});
