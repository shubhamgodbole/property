import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonService } from './common.service';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})

export class MarketPlaceApiService {
  public listDetailData;
  classifiedAdId: string;
 
  marketPlaceUrl  = environment.baseUrl + 'ClassifiedAdRequest';
  constructor(private http: HttpClient, private commonService: CommonService) { }
  getAllAdds(associationId, domain) {
    const requestParam = {
		  associationId, domain
	  }
    const data = this.commonService.getBodyData(requestParam, 'ClassifiedAds', 'List');
    return this.http.post(this.marketPlaceUrl, JSON.stringify(data));
  }

  getAllCategories() {
    const requestParam = {
		  "DocumentType": "ClassifiedAdCategory"
	  }
    const data = this.commonService.getBodyData(requestParam, 'ClassifiedAds', 'GetMasterData');
    return this.http.post(this.marketPlaceUrl, JSON.stringify(data));
  }

  addClassifiedAdds(classifiedAd, domain, typeOfDocument, requestDocuments) {
    
    const requestParam = {
		  classifiedAd, domain, typeOfDocument, requestDocuments
    }
    console.log('requestParam ',requestParam);
   const data = this.commonService.getBodyData(requestParam, 'ClassifiedAds', 'Add');
   return this.http.post(this.marketPlaceUrl, JSON.stringify(data));
  }

  deleteClassifiedAdds(deleteID) {
    const requestParam = {
      "ClassifiedAdId": deleteID
	  }
    const data = this.commonService.getBodyData(requestParam, 'ClassifiedAds', 'Delete');
    return this.http.post(this.marketPlaceUrl, JSON.stringify(data));
  }

  addClassifiedEnquiry(enquiryData,ClassifiedAdId) {
    const requestParam = {
      "ClassifiedAdId": ClassifiedAdId,
      "ClassifiedAdUser": enquiryData
	  }
    const data = this.commonService.getBodyData(requestParam, 'ClassifiedAds', 'AddResponse');
    return this.http.post(this.marketPlaceUrl, JSON.stringify(data));
  }

  soldClassifiedAdds(ClassifiedAdId,soldDate) {
    const requestParam = {
      "ClassifiedAdId": ClassifiedAdId,
      "soldDate": soldDate
	  }
    const data = this.commonService.getBodyData(requestParam, 'ClassifiedAds', 'MarkSold');
    return this.http.post(this.marketPlaceUrl, JSON.stringify(data));
  }

  classifiedAdDetail(domain: string){
    const requestParam = {
      'ClassifiedAdId': this.classifiedAdId,
      domain
	  }
    const data = this.commonService.getBodyData(requestParam, 'ClassifiedAds', 'Detail');
    console.log(data);
    return this.http.post(this.marketPlaceUrl, JSON.stringify(data));
  }

  getClassifiedAdListByCategory(classifiedAdCategory) {
    const requestParam = {
      classifiedAdCategory
	  }
    const data = this.commonService.getBodyData(requestParam, 'ClassifiedAds', 'Category');
    console.log(data);
    return this.http.post(this.marketPlaceUrl, JSON.stringify(data));
  }
}
