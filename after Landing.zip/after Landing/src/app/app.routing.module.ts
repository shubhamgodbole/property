import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { UpdatePasswordComponent } from './components/update-password/update-password.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { BmServiceRequestListComponent } from './components/service-request/bm-service-request-list/bm-service-request-list.component';
import { HoServiceRequestListComponent } from './components/service-request/ho-service-request-list/ho-service-request-list.component';
import { BmServiceRequestDetailComponent } from './components/service-request/bm-service-request-detail/bm-service-request-detail.component';
import { HoServiceRequestDetailComponent } from './components/service-request/ho-service-request-detail/ho-service-request-detail.component';
import { BoardTaskListComponent } from './components/board-tasks/board-task-list/board-task-list.component';
import { BoardTaskDetailComponent } from './components/board-tasks/board-task-detail/board-task-detail.component';
import { BalanceSheetComponent } from './components/payments/balance-sheet/balance-sheet.component';
import { IncomeSheetComponent } from './components/payments/income-sheet/income-sheet.component';
import { PrepaymentComponent } from './components/payments/prepayment/prepayment.component';
import { DelienquencyComponent} from './components/payments/delienquency/delienquency.component';
import { MarketListComponent } from './components/market-place/market-list/market-list.component';
import { MarketDetailComponent } from './components/market-place/market-detail/market-detail.component';
import { CmArcListComponent } from './components/arc/cm-arc-list/cm-arc-list.component';
import { BmArcListComponent } from './components/arc/bm-arc-list/bm-arc-list.component';
import { HoArcListComponent } from './components/arc/ho-arc-list/ho-arc-list.component';
import { CmArcDetailComponent } from './components/arc/cm-arc-detail/cm-arc-detail.component';
import { BmArcDetailComponent } from './components/arc/bm-arc-detail/bm-arc-detail.component';
import { HoArcDetailComponent } from './components/arc/ho-arc-detail/ho-arc-detail.component';
import { BmViolationListComponent } from './components/violation/bm-violation-list/bm-violation-list.component';
import { HoViolationListComponent } from './components/violation/ho-violation-list/ho-violation-list.component';
import { HoViolationDetailComponent } from './components/violation/ho-violation-detail/ho-violation-detail.component';
import { BmViolationDetailComponent } from './components/violation/bm-violation-detail/bm-violation-detail.component';
import { BoardMemberDirectoryComponent } from './components/directries/board-member-directory/board-member-directory.component';
import { DocumentsComponent } from './components/documents/documents.component';
import { NewsletterComponent } from './components/newsletter/newsletter.component';
import { MeetingComponent } from './components/meeting/meeting.component';
import { AssociationLandingComponent } from './components/association-landing/association-landing.component';
import { HoaDirectoryComponent } from './components/directries/hoa-directory/hoa-directory.component';
import { MyProfileComponent } from './components/my-profile/my-profile.component';
import { HoaDetailComponent } from './components/directries/hoa-detail/hoa-detail.component';
import { PropertyManagerComponent } from './components/property-inspection/property-manager/property-manager.component';
import { InspectionHistoryComponent } from './components/property-inspection/inspection-history/inspection-history.component';
import { PmCreateReportComponent } from './components/property-inspection/pm-create-report/pm-create-report.component';
import { BmInspectionListComponent } from './components/property-inspection/bm-inspection-list/bm-inspection-list.component';
import { BmCommitteeComponent } from './components/committees/bm-committee/bm-committee.component';
import { HoCommitteeComponent } from './components/committees/ho-committee/ho-committee.component';
import { CalendarComponent } from './components/calendar/calendar.component';
import { ErrorComponent } from './components/error/error.component';

const routes: Routes = [
    {
        path: '',
        pathMatch: 'full',
        component: LoginComponent
    },
    {
        path: 'login',
        component: LoginComponent
    }
    ,
    {
        path: 'forgot-password',
        component: ForgotPasswordComponent
    }
    ,
    {
        path: 'update-password',
        component: UpdatePasswordComponent
    }
    ,
    {
        path: 'sign-up',
        component: SignUpComponent
    }
    ,
    {
        path: 'dashboard',
        component: DashboardComponent
    },
    {
        path: 'ServiceRequest',
        component: BmServiceRequestListComponent
    },
    {
        path: 'servicerequestho',
        component: HoServiceRequestListComponent
    },
    {
        path: 'bm-service-request-detail',
        component: BmServiceRequestDetailComponent
    },
    {
        path: 'ho-service-request-detail',
        component: HoServiceRequestDetailComponent
    },
    {
        path: 'BoardTasks',
        component: BoardTaskListComponent
    },
    {
        path: 'board-task-detail',
        component: BoardTaskDetailComponent,
    },
    {
        path: 'BalanceSheetReport',
        component: BalanceSheetComponent
    },
    {
        path: 'IncomeStatementReport',
        component: IncomeSheetComponent
    },
    {
        path: 'PrepaymentReport',
        component: PrepaymentComponent
    },
    {
        path: 'MyPayments',
        component: DelienquencyComponent
    },
    {
        path: 'ClassifiedAds',
        component: MarketListComponent
    },
    {
        path: 'market-detail',
        component: MarketDetailComponent
    },
    {
        path: 'cm-arc-list',
        component: CmArcListComponent
    },
    {
        path: 'ARCRequestsBoard',
        component: BmArcListComponent
    },
    {
        path: 'ARCRequests',
        component: HoArcListComponent
    },
    {
        path: 'cm-arc-detail',
        component: CmArcDetailComponent
    },
    {
        path: 'bm-arc-detail',
        component: BmArcDetailComponent
    },
    {
        path: 'ho-arc-detail',
        component: HoArcDetailComponent
    },
    {
        path: 'ViolationsBoardView',
        component: BmViolationListComponent
    },
    {
        path: 'Violations',
        component: HoViolationListComponent
    },
    {
        path: 'ho-violation-detail',
        component: HoViolationDetailComponent
    },
    {
        path: 'bm-violation-detail',
        component: BmViolationDetailComponent
    },
    {
        path: 'boardmembers',
        component: BoardMemberDirectoryComponent
    },
    {
        path: 'Documents',
        component: DocumentsComponent
    },
    {
        path: 'newsletters',
        component: NewsletterComponent
    },
    {
        path: 'meetings',
        component: MeetingComponent
    },
    {
        path: 'association-landing',
        component: AssociationLandingComponent
    },
    {
        path: 'hoa_members',
        component: HoaDirectoryComponent
    },
    {
        path: 'my-profile',
        component: MyProfileComponent
    },
    {
        path: 'hoa-detail',
        component: HoaDetailComponent
    },
    {
        path: 'property-manager',
        component: PropertyManagerComponent
    },
    {
        path: 'inspection-history',
        component: InspectionHistoryComponent
    },
    {
        path: 'pm-create-report',
        component: PmCreateReportComponent
    },
    {
        path: 'bm-inspection-list',
        component: BmInspectionListComponent
    },
    {
        path: 'committee',
        component: BmCommitteeComponent
    },
    {
        path: 'ho-committee',
        component: HoCommitteeComponent
    },
    {
        path: 'AssociationCalendar',
        component: CalendarComponent
    },
    {
        path: 'error',
        component: ErrorComponent
    },
];


@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
