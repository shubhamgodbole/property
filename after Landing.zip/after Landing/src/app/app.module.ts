import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing.module';
import { LoginComponent } from './components/login/login.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { UpdatePasswordComponent } from './components/update-password/update-password.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { HeaderComponent } from './components/header/header.component';
import { NavigationComponent } from './components/navigation/navigation.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { BmServiceRequestListComponent } from './components/service-request/bm-service-request-list/bm-service-request-list.component';
import { BmServiceRequestDetailComponent } from './components/service-request/bm-service-request-detail/bm-service-request-detail.component';
import { HoServiceRequestDetailComponent } from './components/service-request/ho-service-request-detail/ho-service-request-detail.component';
import { HoServiceRequestListComponent } from './components/service-request/ho-service-request-list/ho-service-request-list.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import 'hammerjs';
import {
  MatAutocompleteModule,
  MatBadgeModule,
  MatBottomSheetModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatTreeModule,
} from '@angular/material';

import { BoardTaskListComponent } from './components/board-tasks/board-task-list/board-task-list.component';
import { BoardTaskDetailComponent } from './components/board-tasks/board-task-detail/board-task-detail.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BalanceSheetComponent } from './components/payments/balance-sheet/balance-sheet.component';
import { IncomeSheetComponent } from './components/payments/income-sheet/income-sheet.component';
import { PrepaymentComponent } from './components/payments/prepayment/prepayment.component';
import { DelienquencyComponent } from './components/payments/delienquency/delienquency.component';
import { MarketListComponent } from './components/market-place/market-list/market-list.component';
import { MarketDetailComponent } from './components/market-place/market-detail/market-detail.component';
import { BoardMemberDirectoryComponent } from './components/directries/board-member-directory/board-member-directory.component';
import { CmArcListComponent } from './components/arc/cm-arc-list/cm-arc-list.component';
import { BmArcListComponent } from './components/arc/bm-arc-list/bm-arc-list.component';
import { HoArcListComponent } from './components/arc/ho-arc-list/ho-arc-list.component';
import { HoArcDetailComponent } from './components/arc/ho-arc-detail/ho-arc-detail.component';
import { BmArcDetailComponent } from './components/arc/bm-arc-detail/bm-arc-detail.component';
import { CmArcDetailComponent } from './components/arc/cm-arc-detail/cm-arc-detail.component';
import { HttpClientModule, HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { HttpRequestInterceptor } from './interceptor/http.request.interceptor';
import { BmViolationListComponent } from './components/violation/bm-violation-list/bm-violation-list.component';
import { HoViolationListComponent } from './components/violation/ho-violation-list/ho-violation-list.component';
import { HoViolationDetailComponent } from './components/violation/ho-violation-detail/ho-violation-detail.component';
import { BmViolationDetailComponent } from './components/violation/bm-violation-detail/bm-violation-detail.component';
import { DocumentsComponent } from './components/documents/documents.component';
import { MeetingComponent } from './components/meeting/meeting.component';
import { AssociationLandingComponent } from './components/association-landing/association-landing.component';
import { NewsletterComponent } from './components/newsletter/newsletter.component';
import { HoaDirectoryComponent } from './components/directries/hoa-directory/hoa-directory.component';
import { Http, HttpModule } from '@angular/http';
import { MyProfileComponent } from './components/my-profile/my-profile.component';
import { HoaDetailComponent } from './components/directries/hoa-detail/hoa-detail.component';
import { PropertyManagerComponent } from './components/property-inspection/property-manager/property-manager.component';
import { BoardMemberComponent } from './components/property-inspection/board-member/board-member.component';
import { BmCommitteeComponent } from './components/committees/bm-committee/bm-committee.component';
import { HoCommitteeComponent } from './components/committees/ho-committee/ho-committee.component';
import { CalendarComponent } from './components/calendar/calendar.component';
import { ErrorComponent } from './components/error/error.component';
import { MatDatetimepickerModule } from '@mat-datetimepicker/core';
import { MatMomentDatetimeModule } from '@mat-datetimepicker/moment';
import {NumberOnlyDirectiveModule} from './shared/directives/allow-only-number/only-number.module';
import { InspectionHistoryComponent } from './components/property-inspection/inspection-history/inspection-history.component';
import { PmCreateReportComponent } from './components/property-inspection/pm-create-report/pm-create-report.component';
import { BmInspectionListComponent } from './components/property-inspection/bm-inspection-list/bm-inspection-list.component';
import { AppConfig } from './app.config';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ForgotPasswordComponent,
    UpdatePasswordComponent,
    SignUpComponent,
    HeaderComponent,
    NavigationComponent,
    DashboardComponent,
    BmServiceRequestListComponent,
    BmServiceRequestDetailComponent,
    HoServiceRequestDetailComponent,
    HoServiceRequestListComponent,
    BoardTaskListComponent,
    BoardTaskDetailComponent,
    BalanceSheetComponent,
    IncomeSheetComponent,
    PrepaymentComponent,
    DelienquencyComponent,
    MarketListComponent,
    MarketDetailComponent,
    BoardMemberDirectoryComponent,
    CmArcListComponent,
    BmArcListComponent,
    HoArcListComponent,
    HoArcDetailComponent,
    BmArcDetailComponent,
    CmArcDetailComponent,
    BmViolationListComponent,
    HoViolationListComponent,
    HoViolationDetailComponent,
    BmViolationDetailComponent,
    DocumentsComponent,
    MeetingComponent,
    AssociationLandingComponent,
    NewsletterComponent,
    HoaDirectoryComponent,
    MyProfileComponent,
    HoaDetailComponent,
    PropertyManagerComponent,
    BoardMemberComponent,
    BmCommitteeComponent,
    HoCommitteeComponent,
    CalendarComponent,
    ErrorComponent,
    InspectionHistoryComponent,
    PmCreateReportComponent,
    BmInspectionListComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatStepperModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    BrowserAnimationsModule,
    HttpModule,
    MatDatepickerModule,
    MatMomentDatetimeModule,
    MatDatetimepickerModule,
    NumberOnlyDirectiveModule,
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory
    }),
    NgbModule,
    HttpModule
  ],
  providers: [
    AppConfig,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpRequestInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
