export class BasicDetailsModel{
    propertyAddress:string;
    mailingAddress:string;
    emailAddress:string;
    dateOfBirth: string;
    mobileNumber: string;
    homePhoneNumber: string;
    workPhoneNumber: string;
    gender: string;  
}

export class DisplayGender
{
   public static GenderList = [
     {value:"Female" , text :"Female"} ,
     {value:"Male" , text :"Male"} 
    ]
}

// export class UnitPetsModel
// {
//     userId:string;
//     UnitPetModel :UnitPetModel;
// }

export class UnitPetsModel
{
    unitId:string;
    PetDetails :PetDetailModel[];
}
export class PetDetailModel
{
    userPetDetailId:string;
    petName:string;
    petTypeName:string;
    breedName:string;
}

export class UnitVehiclesModel
{
    unitId:string;
    VehicleDetails :VehicleDetailModel[];
}
export class VehicleDetailModel
{
    userVehicleDetailId:string;
    makeModel:string;
    year:string;
    licensePlate:string;
    state:string;
}

export class EmergencyContactModel
{
    unitId:string;
    EmergencyContacts :EmergencyContactsModel[];
}
export class EmergencyContactsModel
{
    firstName:string;
    lastName:string;
    middleName:string;
    email:string;
    city:string;
    state:string;
    zip:string;
    mobile:string;
    homePhone:string;
    workPhone:string;
    addressLine1:string;
    addressLine2:string;
    emergencyContactDetailId:string;
}