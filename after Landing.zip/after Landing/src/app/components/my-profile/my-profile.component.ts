import { Component, OnInit, ViewChild } from '@angular/core';
import { HoaDirectoryApiService } from 'src/app/services/hoa-directory-api.service';
import { BasicDetailsModel, UnitPetsModel, UnitVehiclesModel, EmergencyContactModel, DisplayGender } from './my-profile.model';
import { FormGroup, FormBuilder, Validators, ValidatorFn, AbstractControl, ValidationErrors, FormGroupDirective } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ValidationService, ConfirmPasswordValidator } from 'src/app/shared/services/validation.service';
import { Router } from '@angular/router';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss']
})
export class MyProfileComponent implements OnInit {
  isProfilePicture: boolean = true;
  frmChangePassword: FormGroup;
  resData: any;
  userProfileList: any;
  tenantsList: any;
  unitEmergencyContactsList: any;
  vehiclesList: any;
  petsList: any;
  associationUnitId: string;
  accountNumber: string;
  coverImagePath: string;
  profileImagePath: string;
  basicDetails: BasicDetailsModel;
  userData: UserData;

  /*Variables for Add or Edit Pet*/
  addPet: boolean = false;
  resDataCreatePet: any;
  frmPet: FormGroup;
  isEditModePet: boolean = false;
  isSubmitBtnDisabledForPet: boolean = false;
  @ViewChild('formDirectiveForPet') formDirectiveForPet: FormGroupDirective;

  /*Variables for Add or Edit Vehicle*/
  addVehicle: boolean = false;
  resDataCreateVehicle: any;
  frmVehicle: FormGroup;
  isEditModeVehicle: boolean = false;
  isSubmitBtnDisabledForVehicle: boolean = false;
  @ViewChild('formDirectiveForVehicle') formDirectiveForVehicle: FormGroupDirective;

  /*Variables for Edit Basic Details*/
  frmEditBasicDetails: FormGroup;
  addBasicDetails: boolean = false;
  resDataCreateBasicDetail: any;
  isSubmitBtnDisabledForBasicDetail: boolean = false;
  genderDdl: any;
  @ViewChild('formDirectiveForBasicDetail') formDirectiveForBasicDetail: FormGroupDirective;

  /*Variables for Add or Edit Emergency Contact*/
  addEmergencyContact: boolean = false;
  resDataCreateEmergencyContact: any;
  frmEmergencyContact: FormGroup;
  isEditModeEmergencyContact: boolean = false;
  isSubmitBtnDisabledForEmergencyContact: boolean = false;

  @ViewChild('formDirectiveForEmergencyContact') formDirectiveForEmergencyContact: FormGroupDirective;

  // Private
  private unsubscribeAll: Subject<any>;

  isSubmitBtnDisabled: boolean = false;

  constructor(
    private _router: Router,
    private readonly formBuilder: FormBuilder,
    private hoaDirectoryApiService: HoaDirectoryApiService,
    private readonly appConfig: AppConfig) {
    this.unsubscribeAll = new Subject();
    this.genderDdl = DisplayGender.GenderList;
    this.userData = this.appConfig.getCurrentUser();
    this.createChangePasswordForm();
    this.createFormPet();
    this.createFormVehicle();
    this.createFormEmergencyContact();
  }
  ngOnInit() {
    if (this.hoaDirectoryApiService.userId !== undefined && this.hoaDirectoryApiService.associationUnitId !== "") {
      this.getData();
    } else {
      this._router.navigate(["/hoa-directory"]);
    }
  }

  getData() {
    this.hoaDirectoryApiService.getMyprofile(this.hoaDirectoryApiService.userId, this.hoaDirectoryApiService.associationUnitId).subscribe(res => {
      this.resData = res;
      if (this.resData.Success) {
        this.userProfileList = this.resData.UserProfileDetailWithAddress;
        this.associationUnitId = this.hoaDirectoryApiService.associationUnitId;
        if (this.userProfileList !== null && this.userProfileList !== undefined) {
          this.unitEmergencyContactsList = this.userProfileList.UnitEmergencyContacts;
          this.vehiclesList = this.userProfileList.UnitVehicles;
          this.petsList = this.userProfileList.UnitPets;
          this.tenantsList = this.userProfileList.UnitTenants;
          this.accountNumber = this.userProfileList.UnitRole.UnitRoleProfiles[0].AccountNumber;
          this.coverImagePath = this.userProfileList.UserProfile.CoverImagePath;
          this.profileImagePath = this.userProfileList.UserProfile.ProfileImagePath;
          this.getBasicDetails();
        }
      }else{
        alert("Details not found");
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  getBasicDetails() {
    let propertyAddress = this.getFullMailingAddress();
    let mailAddress = this.getFullMailingAddress();
    let basicDetail: BasicDetailsModel = {
      dateOfBirth: this.userProfileList.UserProfile.BirthDate,
      emailAddress: this.userProfileList.UserProfile.EmailAddress,
      gender: this.userProfileList.UserProfile.Gender,
      homePhoneNumber: this.userProfileList.UserProfile.HomePhone,
      mailingAddress: mailAddress,
      mobileNumber: this.userProfileList.UserProfile.Mobile,
      propertyAddress: propertyAddress,
      workPhoneNumber: this.userProfileList.UserProfile.WorkPhone1,
    }
    this.basicDetails = basicDetail;
  }

  getFullPropertyAddress(): string {
    let propertyAddress = "";
    let fullPropertyAddress = this.userProfileList.AssociationUnit;
    if (fullPropertyAddress.AssociationUnitAddress1 !== null) {
      propertyAddress = fullPropertyAddress.AssociationUnitAddress1 + ",";
    }
    if (fullPropertyAddress.AssociationUnitAddress2 !== null) {
      propertyAddress = propertyAddress + fullPropertyAddress.AssociationUnitAddress2;
    }
    if (fullPropertyAddress.AssociationUnitCity !== null) {
      propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitCity;
    }
    if (fullPropertyAddress.AssociationUnitState !== null) {
      propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitState + ",";
    }
    if (fullPropertyAddress.AssociationUnitCounty !== null) {
      propertyAddress = propertyAddress + fullPropertyAddress.AssociationUnitCounty;
    }
    if (fullPropertyAddress.AssociationUnitZip !== null) {
      propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitZip;
    }
    return propertyAddress;
  }

  getFullMailingAddress(): string {
    let fullMailingAddress = this.userProfileList.Address;
    let mailAddress = "";
    if (fullMailingAddress.Address1 !== null) {
      mailAddress = fullMailingAddress.Address1 + ",";
    }
    if (fullMailingAddress.Address2 !== null) {
      mailAddress = mailAddress + fullMailingAddress.Address2;
    }
    if (fullMailingAddress.City !== null) {
      mailAddress = mailAddress + " " + fullMailingAddress.City;
    }
    if (fullMailingAddress.State !== null) {
      mailAddress = mailAddress + " " + fullMailingAddress.State + ",";
    }
    if (fullMailingAddress.County !== null) {
      mailAddress = mailAddress + fullMailingAddress.County;
    }
    if (fullMailingAddress.ZIP !== null) {
      mailAddress = mailAddress + " " + fullMailingAddress.ZIP;
    }
    return mailAddress;
  }

  createChangePasswordForm() {
    this.frmChangePassword = this.formBuilder.group({
      currentPassword: ['', [Validators.required]],
      newPassword: ['', [Validators.required, ValidationService.passwordValidator]],
      confirmPassword: ['', [Validators.required, ConfirmPasswordValidator]],
    });

    // Update the validity of the 'passwordConfirm' field
    // when the 'password' field changes
    this.frmChangePassword.get('newPassword').valueChanges
      .pipe(takeUntil(this.unsubscribeAll))
      .subscribe(() => {
        this.frmChangePassword.get('confirmPassword').updateValueAndValidity();
      });
  }

  doChangePassword() {
    // const oldPassword = "Macosx123";
    // const newPassword = "Macosx123";
    let model = {
      userId: this.hoaDirectoryApiService.userId,//this.userId,
      currentPassword: this.frmChangePassword.controls.currentPassword.value,
      newPassword: this.frmChangePassword.controls.newPassword.value,
      confirmPassword: this.frmChangePassword.controls.confirmPassword.value
    };
    if (this.frmChangePassword.valid) {
      this.isSubmitBtnDisabled = true;
      this.hoaDirectoryApiService.doChangePassword(model).subscribe(res => {
        this.resData = res;
        this.isSubmitBtnDisabled = false;
        if (this.resData.Success === true) {
          alert("Your password changed successfully.");
          this.resetForm();
        }
        else {
          alert("Your password not changed, Please try again.");
        }
      },
        (err) => {
          console.log(err);
        }
      )
    }
  }
  resetForm() {
    this.frmChangePassword.reset();
    this.frmChangePassword.controls.currentPassword.setErrors(null);
    this.frmChangePassword.controls.newPassword.setErrors(null);
    this.frmChangePassword.controls.confirmPassword.setErrors(null);
    this.frmChangePassword.clearValidators();
  }
  base64textStringProfilePicture = [];
  onChangeProfilePicture(evt: any, imageType: string) {
    if (imageType === "CoverImage") {
      this.isProfilePicture = false;
    }
    const file = evt.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = this.handleReaderLoadedProfilePicture.bind(this);
      reader.readAsBinaryString(file);
    }
  }

  handleReaderLoadedProfilePicture(e) {
    this.base64textStringProfilePicture = [];
    this.base64textStringProfilePicture.push('data:image/png;base64,' + btoa(e.target.result));
    this.onChangePicture();
  }

  onChangePicture() {
    const inputStream = this.base64textStringProfilePicture[0];
    if (this.isProfilePicture) {
      this.hoaDirectoryApiService.changeProfilePicture(this.hoaDirectoryApiService.userId, inputStream).subscribe(res => {
        this.resData = res;
        if (this.resData.Success === true) {
          alert("Your Profile Picture changed successfully.");
        }
        else {
          alert("Your Profile Picture not changed, Please try again.");
        }
      },
        (err) => {
          console.log(err);
        }
      )
    }
    else {
      this.hoaDirectoryApiService.changeCoverPicture(this.hoaDirectoryApiService.userId, inputStream).subscribe(res => {
        this.resData = res;
        if (this.resData.Success === true) {
          alert("Your Cover Picture changed successfully.");
        }
        else {
          alert("Your Cover Picture not changed, Please try again.");
        }
      },
        (err) => {
          console.log(err);
        }
      )
    }
  }

  deleteVehical(requestId, unitId) {
    this.hoaDirectoryApiService.deleteVehical(this.hoaDirectoryApiService.userId, unitId, requestId).subscribe(res => {
      this.resData = res;
      if (this.resData.Success === true) {
        alert("Vehical Deleted successfully.");
        this.getData();
      }
      else {
        alert("Vehical is not deleted, Please try again.");
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }
  deletePet(requestId, unitId) {
    this.hoaDirectoryApiService.deletePet(this.hoaDirectoryApiService.userId, unitId, requestId).subscribe(res => {
      this.resData = res;
      if (this.resData.Success === true) {
        alert("Pet Deleted successfully.");
        this.getData();
      }
      else {
        alert("Pet is not deleted, Please try again.");
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }
  deleteTenant(requestId, unitId) {
    this.hoaDirectoryApiService.deleteTenant(this.hoaDirectoryApiService.userId, unitId, requestId).subscribe(res => {
      this.resData = res;
      if (this.resData.Success === true) {
        alert("Tenant Deleted successfully.");
        this.getData();
      }
      else {
        alert("Tenant is not deleted, Please try again.");
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }
  /* Region Edit or Add Basic details */
  addBasicDetailsToggle() {
    if (this.addBasicDetails) {
      this.addBasicDetails = false;
    }
    else
      this.addBasicDetails = true;
  }

  createFormBasicDetails() {
    this.frmEditBasicDetails = this.formBuilder.group({
      id: [''],
      //propertyAddress: ['', Validators.required],
      propertyAddressLine1: ['', Validators.required],
      propertyAddressLine2: [''],
      propertyCity: ['', Validators.required],
      propertyState: ['', Validators.required],
      propertyZip: ['', Validators.required],
      propertyCounty: ['', Validators.required],
      mailingAddressLine1: ['', Validators.required],
      mailingAddressLine2: [''],
      mailingCity: ['', Validators.required],
      mailingState: ['', Validators.required],
      mailingZip: ['', Validators.required],
      mailingCounty: ['', Validators.required],
      //mailingAddress: ['', Validators.required],
      email: ['', Validators.required],
      dateOfBirth: ['', Validators.required],
      mobile: ['', Validators.required],
      homePhone: ['', Validators.required],
      workPhone: ['', Validators.required],
      gender: ['', Validators.required]
    });
  }

  onBasicDetailSubmit() {
    if (this.frmEditBasicDetails.valid) {
      this.isSubmitBtnDisabledForBasicDetail = true;
      let model = this.createPetFormModel();
      this.hoaDirectoryApiService.createPet(model, this.hoaDirectoryApiService.userId).subscribe(res => {
        this.isSubmitBtnDisabledForBasicDetail = false;
        this.resDataCreatePet = res;
        if (this.resDataCreatePet.Success === true) {
          alert("Basic details updated successfully.");
          this.getData();
          this.addPet = false;
          this.resetFormPet();
        }
        else if (this.resDataCreatePet.Success === false) {
          alert("Not Saved");
        }
      });
    }

  }


  /* Region Edit or Add Pet details */
  addPetToggle() {
    if (this.addPet) {
      this.addPet = false;
    }
    else
      this.addPet = true;
    this.resetFormPet();
  }

  createFormPet() {
    this.frmPet = this.formBuilder.group({
      userPetDetailId: [''],
      petType: ['', Validators.required],
      petName: ['', Validators.required],
      breedName: ['', Validators.required]
    });
  }

  onPetSubmit() {
    if (this.frmPet.valid) {
      this.isSubmitBtnDisabledForPet = true;
      let model = this.createPetFormModel();
      if (this.isEditModePet) {
        this.editPet(model);
      } else {
        this.savePet(model);
      }
    }
  }

  savePet(model) {
    this.hoaDirectoryApiService.createPet(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.isSubmitBtnDisabledForPet = false;
      this.resDataCreatePet = res;
      if (this.resDataCreatePet.Success === true) {
        alert("Pet details saved successfully.");
        this.getData();
        this.addPet = false;
        this.resetFormPet();
      }
      else if (this.resDataCreatePet.Success === false) {
        alert("Not Saved");
      }
    });
  }

  editPet(model) {
    this.hoaDirectoryApiService.editPet(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.isSubmitBtnDisabledForPet = false;
      this.resDataCreatePet = res;
      if (this.resDataCreatePet.Success === true) {
        alert("Pet details updated successfully.");
        this.getData();
        this.addPet = false;
        this.resetFormPet();
      }
      else if (this.resDataCreatePet.Success === false) {
        alert("Not saved");
      }
    });
  }
  createPetFormModel() {
    const model: UnitPetsModel = {
      unitId: this.hoaDirectoryApiService.associationUnitId,
      PetDetails:
        [{
          userPetDetailId: this.frmPet.controls.userPetDetailId.value,
          petName: this.frmPet.controls.petName.value,
          petTypeName: this.frmPet.controls.petType.value,
          breedName: this.frmPet.controls.breedName.value
        }]
    }
    return model;
  }

  editRowPet(pet) {
    this.isEditModePet = true;
    this.addPet = true;
    this.frmPet.controls.userPetDetailId.setValue(pet.UserPetDetailId);
    this.frmPet.controls.petType.setValue(pet.PetTypeName);
    this.frmPet.controls.petName.setValue(pet.PetName);
    this.frmPet.controls.breedName.setValue(pet.BreedName);
  }

  resetFormPet() {
    this.frmPet.reset();
    this.formDirectiveForPet.resetForm();
    this.isSubmitBtnDisabledForPet = false;
    this.isEditModePet = false;
  }

  /* Region Edit or Add Vehicle details */
  addVehicleToggle() {
    // this.createFormPet();
    if (this.addVehicle) {
      this.addVehicle = false;
    }
    else
      this.addVehicle = true;
    this.resetFormVehicle();
  }

  createFormVehicle() {
    this.frmVehicle = this.formBuilder.group({
      userVehicleDetailId: [''],
      makeModel: ['', Validators.required],
      year: ['', Validators.required],
      licensePlate: ['', Validators.required],
      state: ['', Validators.required],
    });
  }

  onVehicleSubmit() {
    if (this.frmVehicle.valid) {
      this.isSubmitBtnDisabledForVehicle = true;
      let model = this.createVehicleFormModel();
      if (this.isEditModeVehicle) {
        this.editVehicle(model);
      } else {
        this.saveVehicle(model);
      }
    }
  }

  saveVehicle(model) {
    this.hoaDirectoryApiService.createVehicle(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.resDataCreateVehicle = res;
      this.isSubmitBtnDisabledForVehicle = false;
      if (this.resDataCreateVehicle.Success === true) {
        alert("Vehicle details saved successfully.");
        this.addVehicle = false;
        this.resetFormPet();
        this.getData();


      }
      else if (this.resDataCreateVehicle.Success === false) {
        alert("Not Saved");
      }
    });
  }

  editVehicle(model) {
    this.hoaDirectoryApiService.editVehicle(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.resDataCreateVehicle = res;
      this.isSubmitBtnDisabledForVehicle = false;
      if (this.resDataCreateVehicle.Success === true) {
        alert("Vehicle details updated successfully.");
        this.addVehicle = false;
        this.resetFormVehicle();
        this.getData();
      }
      else if (this.resDataCreateVehicle.Success === false) {
        alert("Not updated");
      }
    });
  }
  createVehicleFormModel() {

    const model: UnitVehiclesModel = {
      unitId: this.hoaDirectoryApiService.associationUnitId,
      VehicleDetails:
        [{
          userVehicleDetailId: this.frmVehicle.controls.userVehicleDetailId.value,
          makeModel: this.frmVehicle.controls.makeModel.value,
          licensePlate: this.frmVehicle.controls.licensePlate.value,
          state: this.frmVehicle.controls.state.value,
          year: this.frmVehicle.controls.year.value
        }]
    }
    return model;
  }

  editRowVehicle(vehicle) {
    this.isEditModeVehicle = true;
    this.addVehicle = true;
    this.frmVehicle.controls.userVehicleDetailId.setValue(vehicle.UserVehicleDetailId);
    this.frmVehicle.controls.makeModel.setValue(vehicle.MakeModel);
    this.frmVehicle.controls.licensePlate.setValue(vehicle.LicensePlate);
    this.frmVehicle.controls.state.setValue(vehicle.State);
    this.frmVehicle.controls.year.setValue(vehicle.Year);
  }

  resetFormVehicle() {
    this.frmVehicle.reset();
    this.formDirectiveForVehicle.resetForm();
    this.isSubmitBtnDisabledForVehicle = false;
    this.isEditModeVehicle = false;
  }



  /* Region Edit or Add Emergency Contact */

  setMobileNumber() {
    let ctrlValue = this.frmEmergencyContact.controls.mobile.value;
    let newCtrlValue = this.convertMobileNumber(ctrlValue);
    this.frmEmergencyContact.controls.mobile.setValue(newCtrlValue);
  }





  addEmergencyContactToggle() {
    if (this.addEmergencyContact) {
      this.addEmergencyContact = false;
    }
    else
      this.addEmergencyContact = true;
    this.resetFormEmergencyContact();
  }

  createFormEmergencyContact() {
    this.frmEmergencyContact = this.formBuilder.group({
      emergencyContactDetailId: [''],
      firstName: ['', Validators.required],
      middleName: ['', Validators.required],
      lastName: ['', Validators.required],
      mobile: ['', [Validators.required, Validators.minLength(10)]],
      email: ['', [Validators.required, ValidationService.emailValidator]],
      addressLine1: ['', Validators.required],
      addressLine2: [''],
      city: ['', Validators.required],
      state: ['', Validators.required],
      zip: ['', Validators.required],
      homePhone: [''],
      workPhone: [''],
    });
  }

  onEmergencyContactSubmit() {

    if (this.frmEmergencyContact.valid) {
      this.isSubmitBtnDisabledForEmergencyContact = true;
      let model = this.createEmergencyContactFormModel();
      if (this.isEditModeEmergencyContact) {
        this.editEmergencyContact(model);
      } else {
        this.saveEmergencyContact(model);
      }
    }
  }

  saveEmergencyContact(model) {
    this.hoaDirectoryApiService.createEmergencyContact(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.resDataCreateEmergencyContact = res;
      this.isSubmitBtnDisabledForEmergencyContact = false;
      if (this.resDataCreateEmergencyContact.Success === true) {
        alert("Contact details saved successfully.");
        this.addEmergencyContact = false;
        this.resetFormEmergencyContact();
        this.getData();


      }
      else if (this.resDataCreateEmergencyContact.Success === false) {
        alert("Not Saved");
      }
    });
  }

  editEmergencyContact(model) {
    this.hoaDirectoryApiService.editEmergencyContact(model, this.hoaDirectoryApiService.userId).subscribe(res => {
      this.resDataCreateEmergencyContact = res;
      this.isSubmitBtnDisabledForEmergencyContact = false;
      if (this.resDataCreateEmergencyContact.Success === true) {
        alert("Vehicle details updated successfully.");
        this.addEmergencyContact = false;
        this.resetFormEmergencyContact();
        this.getData();
      }
      else if (this.resDataCreateEmergencyContact.Success === false) {
        alert("Not updated");
      }
    });
  }
  createEmergencyContactFormModel() {
    const model: EmergencyContactModel = {
      unitId: this.hoaDirectoryApiService.associationUnitId,
      EmergencyContacts:
        [{
          emergencyContactDetailId: this.frmEmergencyContact.controls.emergencyContactDetailId.value,
          firstName: this.frmEmergencyContact.controls.firstName.value,
          lastName: this.frmEmergencyContact.controls.lastName.value,
          middleName: this.frmEmergencyContact.controls.middleName.value,
          mobile: this.frmEmergencyContact.controls.mobile.value,
          email: this.frmEmergencyContact.controls.email.value,
          addressLine1: this.frmEmergencyContact.controls.addressLine1.value,
          addressLine2: this.frmEmergencyContact.controls.addressLine2.value,
          state: this.frmEmergencyContact.controls.state.value,
          city: this.frmEmergencyContact.controls.city.value,
          workPhone: this.frmEmergencyContact.controls.workPhone.value,
          homePhone: this.frmEmergencyContact.controls.homePhone.value,
          zip: this.frmEmergencyContact.controls.zip.value
        }]
    }
    return model;
  }

  editRowEmergencyContact(emergencyContact) {
    this.isEditModeEmergencyContact = true;
    this.addEmergencyContact = true;
    this.frmEmergencyContact.controls.emergencyContactDetailId.setValue(emergencyContact.EmergencyContactDetailId);
    this.frmEmergencyContact.controls.firstName.setValue(emergencyContact.FirstName);
    this.frmEmergencyContact.controls.lastName.setValue(emergencyContact.LastName);
    this.frmEmergencyContact.controls.middleName.setValue(emergencyContact.MiddleName);
    if (emergencyContact.Mobile !== null && emergencyContact.Mobile !== "") {
      let mobileNumber = this.convertMobileNumber(emergencyContact.Mobile);
      this.frmEmergencyContact.controls.mobile.setValue(mobileNumber);
    }
    else {
      this.frmEmergencyContact.controls.mobile.setValue("");
    }
    this.frmEmergencyContact.controls.email.setValue(emergencyContact.Email);
    this.frmEmergencyContact.controls.addressLine1.setValue(emergencyContact.AddressLine1);
    this.frmEmergencyContact.controls.addressLine2.setValue(emergencyContact.AddressLine2);
    this.frmEmergencyContact.controls.state.setValue(emergencyContact.State);
    this.frmEmergencyContact.controls.city.setValue(emergencyContact.City);
    this.frmEmergencyContact.controls.workPhone.setValue(emergencyContact.WorkPhone);
    this.frmEmergencyContact.controls.homePhone.setValue(emergencyContact.HomePhone);
    this.frmEmergencyContact.controls.zip.setValue(emergencyContact.Zip);
  }

  resetFormEmergencyContact() {
    this.frmEmergencyContact.reset();
    this.formDirectiveForEmergencyContact.resetForm();
    this.isSubmitBtnDisabledForEmergencyContact = false;
    this.isEditModeEmergencyContact = false;
  }

  /*Method for conversion*/
  convertMobileNumber(ctrlValue) {
    return ctrlValue.replace(/(\d{3})(\d{3})(\d{4})/, "($1)$2-$3");
  }
}