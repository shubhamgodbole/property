import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {LoginApiService} from '../../services/login-api.service';
import {Router} from '@angular/router';
import { AppConfig } from 'src/app/app.config';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  resData; 
  constructor(private formBuilder: FormBuilder,
     private service: LoginApiService, private router: Router,  
     private readonly appConfig: AppConfig) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: [''],
      password: ['']
    });
  }

  onSubmit() {
   this.service.login(this.loginForm.value.email).subscribe(res => {
        this.resData = res
        if(this.resData.Errors.length !== 0)
          alert('Invalid UserName or Password');
        else {
          localStorage.setItem('email', this.resData.UserClaim.Email);
          this.appConfig.setCurrentUser(this.resData);
          this.router.navigate(['dashboard']);
          this.loginForm.reset();
        }
      },
      (err) => {
        console.log(err);
      }
    );
   
  }

}
