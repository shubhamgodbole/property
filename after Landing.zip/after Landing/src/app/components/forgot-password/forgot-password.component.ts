import { Component, OnInit } from '@angular/core';
import { LoginApiService } from '../../services/login-api.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  
  email:any;

  constructor(private service: LoginApiService) { }

  ngOnInit() {
  }
  forgotPassword(event) {
    if (event) {
      this.service.forgotPassword(event).subscribe(response => {
        console.log(response);
      }, error => {

      })
    }

  }
}
