import { Component, OnInit } from '@angular/core';
import { AssociationLandingService } from 'src/app/services/association-landing.service';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { TypeOfDocument } from 'src/app/shared/Enums/typeOfDocuments';
import { MarketPlaceApiService } from 'src/app/services/market-place-api.service';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { fileData } from './association-landing.model';

@Component({
  selector: 'app-association-landing',
  templateUrl: './association-landing.component.html',
  styleUrls: ['./association-landing.component.scss']
})
export class AssociationLandingComponent implements OnInit {
  nav = false;
  userData: UserData;
  associationId: string;
  userId: string;
  userName: string;
  domain: string;
  documnetType: string;
  associationData: any;
  classifiedAdBuyData: any;
  classifiedAdSaleData : any;
  homeForSaleData: any;
  homeForSaleDoc: any;
  bannerImageUrl : any;
  soldMarketListForm: FormGroup;
  isComponentLoad : boolean= false;
  fileData: any =[];
  constructor(private service: AssociationLandingService, private formBuilder: FormBuilder,  private router: Router ,public marketPlaceService: MarketPlaceApiService , private readonly appConfig: AppConfig) { 
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.userId = this.userData.UserProfileId;
    this.domain =  "testassociation";//this.userData.UserAssociations[0].Domain;
    this.documnetType = TypeOfDocument.AssociationImages;
    this.userName = this.userData.UserName;
 
  }

  ngOnInit() {
    this.getAssociationLandingData();
    this.soldMarketListForm = this.formBuilder.group({
      date: ['', Validators.required],
    });
  }
  // get Landing Data
  getAssociationLandingData() {
    this.service.getAssociationLandingData(this.associationId,this.documnetType,this.domain,this.userId).subscribe(
      (response: any) => {
        if(response.Success) {
          this.associationData = response.Association;
          this.classifiedAdBuyData = response.ClassifiedAdBuy;
          this.classifiedAdSaleData = response.ClassifiedAdSale;
          this.homeForSaleData = response.HomeForSale[0].HomeForSale;
          this.homeForSaleDoc = response.HomeForSale[0].Documents;
          this.bannerImageUrl = response.BannerImageUrl;
          this.isComponentLoad = true;
        }
      }
    );
  }
  addClass()
  {
    if(this.nav)
      this.nav = false;
    else 
      this.nav = true;
  }
  // get classifiedAd Id & redirect on detail page
  detail(classifiedAdId: string) {
    this.marketPlaceService.classifiedAdId = classifiedAdId;
    this.router.navigate(['/market-detail']);
  }
  // get classifiedID for sold
  soldId(id) {
    this.soldId = id;
  }
  // sold
  sold() {
    var date =  this.soldMarketListForm.controls.date.value;
    this.service.soldClassifiedAdds(this.soldId,date,this.userId).subscribe(
      (response: any) => {
        if(response.Success) {
          this.classifiedAdBuyData = response.ClassifiedAdBuy;
            this.classifiedAdSaleData = response.ClassifiedAdSale;
          console.log('ClassifiedAd was sold');
        }
      });
  }
  // delte
  delete(id) {
    if(confirm("Are you sure to delete ?")) {
      this.service.deleteClassifiedAdds(id,this.userId).subscribe(
        (response: any) => {
          if (response.Success === true) {
            this.classifiedAdBuyData = response.ClassifiedAdBuy;
            this.classifiedAdSaleData = response.ClassifiedAdSale;
            console.log('ClassifiedAd was deleted');
          }
          else {
            console.log('Some Error');
          }
        }
      );
    } 
  }
  // uplad images
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
              var reader = new FileReader();
              reader.onload = (event: any) => {
                let type =  evt.target.files[i].name.split(".");
                 this.fileData.push({
                   inputStream: event.target.result,
                   name: evt.target.files[i].name,
                   type: evt.target.files[i].type,
                   mediaType: type[1],
                   CreatedByUserId: this.userId,
                   CreatedByUserName: this.userName
                 });
              }
              reader.readAsDataURL(evt.target.files[i]);
      }

      this.uploadImages();
    }
  }
  uploadImages() {
    let modeldata = this.uploadImagesModel();
    this.service.uploadData(this.domain,this.associationId,this.fileData,this.documnetType).subscribe(
      (response: any) => {
        if (response.Success === true) {
          console.log('Images uploaded');
        }
        else {
          console.log('Some Error');
        }
      }
    );
  }
  uploadImagesModel() {
    let model: fileData = {
      Domain : this.domain,
      AssociationId: this.associationId,
      AssociationImages: this.fileData,
      DocumentType: this.documnetType
    }
    return model;
  }
}
