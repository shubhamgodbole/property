export class fileData {
    Domain: string
    AssociationId: string
    AssociationImages: any
    DocumentType: string
}