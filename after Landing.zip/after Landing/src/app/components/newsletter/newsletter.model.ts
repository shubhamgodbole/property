export class DisplayMonth
{
   public static monthList = [
     {value:"January" , text :"January"} ,
     {value:"February" , text :"February"} ,
     {value:"March" , text :"March"} ,
     {value:"April" , text :"April"} ,
     {value:"May" , text :"May"} ,
     {value:"June" , text :"June"} ,
     {value:"July" , text :"July"} ,
     {value:"August" , text :"August"} ,
     {value:"September" , text :"September"} ,
     {value:"October" , text :"October"} ,
     {value:"November" , text :"November"} ,
     {value:"December" , text :"December"} 
    ]
}
export class NewsletterModel{
    Domain :string;
    AssociationId:string;
    TypeOfDocument
    RequestDocuments :RequestNewsletterModel[];
}
export class RequestNewsletterModel{
    mediaType:string;
    monthName:string;
    name:string;
    documentId:string;
    inputStream: string;
    isPublished:boolean ;
    publishDate:string;
    documentTitle:string;
    documentCategoryId:string;
    associationDocumentCategoryId:string;
    documentCategoryName:string;
    CreatedByUserId:string;
    CreatedByUserName:string;
}