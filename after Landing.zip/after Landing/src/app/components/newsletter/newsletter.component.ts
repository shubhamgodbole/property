import { Component, OnInit, ViewChild } from '@angular/core';
import { NewsletterApiService } from 'src/app/services/newsletter-api.service';
import { FormGroup, FormGroupDirective, FormBuilder, Validators } from '@angular/forms';
import { DisplayMonth, NewsletterModel } from './newsletter.model';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { TypeOfDocument } from 'src/app/shared/Enums/typeOfDocuments';

@Component({
  selector: 'app-newsletter',
  templateUrl: './newsletter.component.html',
  styleUrls: ['./newsletter.component.scss']
})
export class NewsletterComponent implements OnInit {
  domain: string;
  associationId: string;
  associationName: string;
  userName: string;
  userId: string;
  frmCreateNewletter: FormGroup;
  isEditMode: boolean = false;
  adddocument = false;
  newsletterList: any;
  monthNameDdl: any;
  resData: any;
  resDataCreate: any;
  fileFullName: any;
  url: string = "";
  fileName: string;
  pdfvalidation: boolean = false;
  
  //For Filter data
  selectedMonthName: string = "All";
  filterNewsletterList: any;
  userData: UserData;
  isSubmitBtnDisabled: boolean = false;
  //base64textString = [];
  inputStreamString= "";
  @ViewChild('formDirective') formDirective: FormGroupDirective;

  constructor(private readonly formBuilder: FormBuilder,
    private newsletterApiService: NewsletterApiService, private readonly appConfig: AppConfig ) {
    this.monthNameDdl = DisplayMonth.monthList;
    this.userData = this.appConfig.getCurrentUser();
    this.userData = appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.domain =  this.userData.UserAssociations[0].Domain;
    this.getData();
  }

  ngOnInit() {
    this.createForm();
  }

  getData() {
    this.newsletterApiService.getNewsletterDocument(this.associationId, this.domain, TypeOfDocument.NewsLetterDocuments).subscribe(res => {
      this.resData = res;
      this.newsletterList = this.resData.DocumentDetails.Documents;
      this.filterNewsletterList = this.resData.DocumentDetails.Documents;
    },
      (err) => {
        console.log(err);
      }
    )
  }
  deleteNewsletter(documentId) {
    this.newsletterApiService.deleteNewsletter(documentId).subscribe(res => {
      this.resData = res;
      if (this.resData.Success === true) {
        this.getData();
        alert(this.resData.Message);
      }

    },
      (err) => {
        console.log(err);
      })
  }

  filterGetData() {
    let filterNewsletter = this.filterNewsletterList;
    if (this.selectedMonthName === "All") {
      this.newsletterList = filterNewsletter;
    } else {
      this.newsletterList = filterNewsletter.filter(x => x.MonthName === this.selectedMonthName);
    }
  }

 

  onUploadChange(evt: any) {
    const file = evt.target.files[0];
    if (file !== undefined) {
      this.fileFullName = file;
      this.fileName = this.fileFullName.name;
      const reader = new FileReader();
      reader.onload = this.handleReaderLoaded.bind(this);
      reader.readAsBinaryString(file);
    }
    else{
      this.url = "";
      this.fileName = "";
      this.pdfvalidation = true;
    }
  }

  handleReaderLoaded(e) {
    //this.base64textString = [];
    //this.base64textString.push('data:image/png;base64,' + btoa(e.target.result));
    this.inputStreamString = 'data:image/png;base64,' + btoa(e.target.result);
    if (this.fileFullName.name.substring(this.fileFullName.name.indexOf(".")) === ".pdf") {
      this.url = "../../../../assets/images/preview-images/pdf-preview.png";
      this.pdfvalidation = false;
    }
    else {
      this.url = "";
      this.fileName = "";
      this.pdfvalidation = true;
    }
  }

  onSubmit(formDirective: FormGroupDirective) {
    if (this.pdfvalidation === true || this.fileFullName === undefined || this.fileFullName === null) {
      this.pdfvalidation = true;
      return
    }
    this.isSubmitBtnDisabled = true;
    if (this.frmCreateNewletter.valid) {
      let model = this.createFormModel();
      if (this.isEditMode) {
        this.editData(model, formDirective);
      } else {
        this.saveData(model, formDirective);
      }
    }
  }
  editData(model: any, formDirective: FormGroupDirective) {
    this.newsletterApiService.editNewsletter(model).subscribe(res => {
      this.isSubmitBtnDisabled = false;
      this.resDataCreate = res;
      if (this.resDataCreate.Success === true) {
        alert("Newsletter updated successfully.");
        this.getData();
        this.adddocument = false;
        this.resetForm();
      }
      else if (this.resDataCreate.Success === false) {
        alert("Not Save");
      }
    });
  }

  saveData(model: any, formDirective: FormGroupDirective) {
    this.newsletterApiService.createNewsletter(model).subscribe(res => {
      this.isSubmitBtnDisabled = false;
      this.resDataCreate = res;
      if (this.resDataCreate.Success === true) {
        alert("Newsletter saved successfully.");
        this.getData();
        this.adddocument = false;
        this.resetForm();
      }
      else if (this.resDataCreate.Success === false) {
        alert("Not Save");
      }
    });
  }
  createFormModel() {
    let isPublished;
    let currentDate = new Date();
    const publishDate = new Date(this.frmCreateNewletter.controls.publishDate.value);
    if (publishDate.toLocaleDateString() <= currentDate.toLocaleDateString()) {
      isPublished = true;
    } else {
      isPublished = false;
    }
   
    let inputStream = "";
    let name = "";
    let mediaType = "";
    if (this.inputStreamString !=="") {
      inputStream = this.inputStreamString;//this.base64textString[0];
      name = this.fileFullName.name;
      mediaType = this.fileFullName.name.substring(this.fileFullName.name.indexOf("."));
    }
    const model: NewsletterModel = {
      Domain: this.domain,
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.NewsLetterDocuments,
      RequestDocuments:
        [{
          documentId: this.frmCreateNewletter.controls.documentId.value,
          documentCategoryId: '',
          documentTitle: this.frmCreateNewletter.controls.newletterTitle.value,
          monthName: this.frmCreateNewletter.controls.monthName.value,
          associationDocumentCategoryId: '',
          publishDate: publishDate.toISOString(),
          isPublished: isPublished,
          documentCategoryName: '',
          inputStream: inputStream,
          name: name,
          mediaType: mediaType,
          CreatedByUserId: this.userId,
          CreatedByUserName: this.userName
        }]
    }
    return model;
  }

  adddocumentToggle() {
    if (this.adddocument)
      this.adddocument = false;
    else
      this.adddocument = true;
    this.resetForm();
  }


  createForm() {
    this.frmCreateNewletter = this.formBuilder.group({
      documentId: [''],
      newletterTitle: ['', Validators.required],
      monthName: ['', Validators.required],
      publishDate: ['', Validators.required]
    });
  }
  resetForm() {
    this.url = "";
    this.pdfvalidation = false;
    this.frmCreateNewletter.reset();
    this.formDirective.resetForm();
    this.fileFullName = "";
    this.fileName = "";
    this.isEditMode = false;
    this.isSubmitBtnDisabled = false;
    this.inputStreamString = "";
    //this.base64textString = [];
    //console.log(this.base64textString);
  }

  editRow(newsletter: any) {
    this.isEditMode = true;
    this.adddocument = true;
    if (newsletter.DocumentPath !== "" && newsletter.DocumentPath !== null) {
      this.url = "../../../../assets/images/preview-images/pdf-preview.png";
      this.fileName = newsletter.DocumentName;
      this.pdfvalidation = false;
      this.fileFullName = newsletter.FilePath;
    }
    this.frmCreateNewletter.controls.documentId.setValue(newsletter.id);
    this.frmCreateNewletter.controls.newletterTitle.setValue(newsletter.DocumentTitle);
    this.frmCreateNewletter.controls.publishDate.setValue(newsletter.PublishDate);
    this.frmCreateNewletter.controls.monthName.setValue(newsletter.MonthName);
  }
}
