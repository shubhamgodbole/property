import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BmViolationDetailComponent } from './bm-violation-detail.component';

describe('BmViolationDetailComponent', () => {
  let component: BmViolationDetailComponent;
  let fixture: ComponentFixture<BmViolationDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BmViolationDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BmViolationDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
