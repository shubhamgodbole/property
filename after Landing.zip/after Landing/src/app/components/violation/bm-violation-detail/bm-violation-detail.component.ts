import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bm-violation-detail',
  templateUrl: './bm-violation-detail.component.html',
  styleUrls: ['./bm-violation-detail.component.scss']
})
export class BmViolationDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
