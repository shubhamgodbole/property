import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bm-violation-list',
  templateUrl: './bm-violation-list.component.html',
  styleUrls: ['./bm-violation-list.component.scss']
})
export class BmViolationListComponent implements OnInit {

  status = "All";
  filter = false;

  constructor() { }

  ngOnInit() {
  }

  addClass()
  {
    if(this.filter)
      this.filter = false;
    else 
      this.filter = true;
  }

  statusChange(s) {
    this.status = s;
  }
}
