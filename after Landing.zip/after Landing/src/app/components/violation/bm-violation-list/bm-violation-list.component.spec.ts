import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BmViolationListComponent } from './bm-violation-list.component';

describe('BmViolationListComponent', () => {
  let component: BmViolationListComponent;
  let fixture: ComponentFixture<BmViolationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BmViolationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BmViolationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
