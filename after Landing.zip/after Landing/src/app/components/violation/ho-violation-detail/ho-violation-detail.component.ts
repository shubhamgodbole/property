import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ho-violation-detail',
  templateUrl: './ho-violation-detail.component.html',
  styleUrls: ['./ho-violation-detail.component.scss']
})
export class HoViolationDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
