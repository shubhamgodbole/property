import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ho-violation-list',
  templateUrl: './ho-violation-list.component.html',
  styleUrls: ['./ho-violation-list.component.scss']
})
export class HoViolationListComponent implements OnInit {
  status = "All";
  filter = false;

  constructor() { }

  ngOnInit() {
  }

  addClass()
  {
    if(this.filter)
      this.filter = false;
    else 
      this.filter = true;
  }

  statusChange(s) {
    this.status = s;
  }

}
