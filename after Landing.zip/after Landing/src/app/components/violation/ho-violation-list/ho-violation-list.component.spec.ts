import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoViolationListComponent } from './ho-violation-list.component';

describe('HoViolationListComponent', () => {
  let component: HoViolationListComponent;
  let fixture: ComponentFixture<HoViolationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoViolationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoViolationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
