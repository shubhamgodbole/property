import { Component, OnInit, createPlatformFactory, ViewChild } from '@angular/core';
import { MeetingApiService } from 'src/app/services/meeting-api.service';
import { DomSanitizer } from '@angular/platform-browser';
import { FormBuilder, FormGroup, Validators, FormArray, FormGroupDirective } from '@angular/forms';
import { Meeting, MeetingAgenda, RSVPType, MeetingRSVPs, MeetingMinuteStatusType, MeetingMinute } from './meeting-model';
import { Guid } from 'guid-typescript';
import { RequestDocument } from './meeting-model';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';

@Component({
  selector: 'app-meeting',
  templateUrl: './meeting.component.html',
  styleUrls: ['./meeting.component.scss']
})

export class MeetingComponent implements OnInit {
  pastMeetings: any;
  upcommingMeetings: any;
  meetingDetail: any;
  showMeetingDetail: Boolean;
  display: Boolean = false;
  documentIndex: number;
  singleUrl: string;
  meetingTypes: any;
  meetingMinutesStatusTypes: any;
  meetingForm: FormGroup;
  showMeetingMinuteBox: boolean = false;
  rsvpUserListDisplay: boolean;
  meetingAgendaList: MeetingAgenda[] = new Array<MeetingAgenda>();
  agendaForm: FormGroup;
  agendaItemNumber: number = 0;
  fileData: RequestDocument[] = new Array<RequestDocument>();
  requestDocuments: RequestDocument[] = new Array<RequestDocument>();
  fileDataForMeetingMinute: RequestDocument;
  agendaEditMode: boolean = false;
  agendaId: string;
  isRSVP: boolean = false;
  rsvpTypes = RSVPType;
  meetingId: string;
  meetingMinuteForm: FormGroup;
  meetingMinuteStatusType = MeetingMinuteStatusType;
  meetingEditMode: boolean = false;
  disableBtn: boolean = false;
  userId = localStorage.getItem('UserProfileId');
  disableUploadMinuteBtn: boolean = false;
  showMeetingMinuteDiv: boolean;
  userData: UserData;
  associationId: string;
  associationName: string;
  userName: string;
  domain: string;

  @ViewChild('meetingMinuteFormDirective') meetingMinuteFormDirective: FormGroupDirective;
  @ViewChild('agendaFormDirective') agendaFormDirective: FormGroupDirective;
  @ViewChild('meetingFormDirective') meetingFormDirective: FormGroupDirective;

  constructor(private service: MeetingApiService, private sanitizer: DomSanitizer, private formBuilder: FormBuilder, private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    this.userData = appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.domain =  this.userData.UserAssociations[0].Domain;
    this.getMeetingList();
    this.getMasterData();
  }

  ngOnInit() {
    this.createForm();
    this.createAendaForm();
    this.createMeetingMinuteForm();
    this.showMeetingDetail = false;
  }

  createForm() {
    this.meetingForm = this.formBuilder.group({
      title: ['', Validators.required],
      meetingAudienceType: ['true'],
      location: ['', Validators.required],
      startDateTime: ['', Validators.required],
      endDateTime: ['', Validators.required],
      meetingType: ['', Validators.required]
    });
  }

  createAendaForm() {
    this.agendaForm = this.formBuilder.group({
      agendaDetail: ['', Validators.required],
      agendaDescription: ['', Validators.required]
    });
  }

  createMeetingMinuteForm() {
    this.meetingMinuteForm = this.formBuilder.group({
      meetingMinutesType: ['', Validators.required],
      meetingMinuteStatusType: ['', Validators.required]
    });
  }


  createMeetingModel(): Meeting {
    let model: Meeting = {
      Title: this.meetingForm.controls.title.value,
      ScheduledStart: new Date(this.meetingForm.controls.startDateTime.value).toISOString(),
      ScheduledEnd: new Date(this.meetingForm.controls.endDateTime.value).toISOString(),
      MeetingAudienceType: this.meetingForm.controls.meetingAudienceType.value,
      AssociationId: this.associationId,
      AssociationName: this.associationName,
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      MeetingType: this.meetingForm.controls.meetingType.value.Name,
      CreatedOn: new Date().toISOString(),
      Location: this.meetingForm.controls.location.value,
      MeetingAgenda: this.meetingAgendaList,
      id: this.meetingEditMode ? this.meetingId : ''
    }
    return model;
  }

  createMeetingRSVPModel(rsvpType): MeetingRSVPs {
    var model: MeetingRSVPs = {
      CreatedByUserId: localStorage.getItem('UserProfileId'),
      CreatedByUserName: localStorage.getItem('UserName'),
      RSVPType: rsvpType,
      IsRSVP: (rsvpType == this.rsvpTypes.Accept || rsvpType == this.rsvpTypes.Tentative) ? true : false
    }
    return model;
  }

  createMeetingMinutesModel(): MeetingMinute {
    var model: MeetingMinute = {
      CreatedByUserId: localStorage.getItem('UserProfileId'),
      CreatedByUserName: localStorage.getItem('UserName'),
      MeetingMinuteStatusTypeName: this.meetingMinuteForm.value.meetingMinuteStatusType,
      MeetingMinutesType: this.meetingMinuteForm.value.meetingMinutesType,
      PublishDate: new Date().toISOString()
    }
    return model;
  }


  getMeetingList() {
    let resData;
    this.service.getMeetingList(this.associationId, this.userId).subscribe(response => {
      resData = response;
      if (resData.Success) {
        this.pastMeetings = resData.MeetingList.PastMeetings;
        this.upcommingMeetings = resData.MeetingList.UpcommingMeetings;
        if(this.upcommingMeetings.length !== 0){
          this.getMeetingDetail(this.upcommingMeetings[0].id);
        }
        
      } else {
        console.log('Error');
      }
    }, error => {
      console.log('error');
    });
  }

  getMeetingDetail(meetingId: string) {
    let resData;
    this.service.getMeetingDetail(meetingId, this.domain).subscribe(response => {
      resData = response;
      if (resData.Success) {
        this.meetingDetail = resData.MeetingDetail;
        this.singleUrl = this.meetingDetail.MeetingDocuments != null ? this.meetingDetail.MeetingDocuments[0].DocumentPath : null;
        this.showMeetingDetail = true;
      } else {
        console.log('Error');
      }
    }, error => {

    });
  }

  cancelMeeting(meetingId: string) {
    let resData;
    this.service.cancelMeeting(meetingId).subscribe(response => {
      resData = response;
      if (resData.Success) {
        this.getMeetingList();
      } else {
        console.log('Error');
      }
    }, error => {

    });
  }

  getMasterData() {
    let resData;
    this.service.getMasterData().subscribe(response => {
      resData = response;
      if (resData.Success) {
        this.meetingTypes = resData.MasterData.MeetingTypes;
        this.meetingMinutesStatusTypes = resData.MasterData.MeetingMinutesStatusTypes;
      } else {
        console.log('Error');
      }
    }, error => {

    });
  }


  scheduleMeeting() {
    this.disableBtn = true;
    const meeting = this.createMeetingModel();
    let resData;
    this.service.createMeeting(meeting, this.fileData, "MeetingDocuments", this.domain).subscribe(response => {
      resData = response;
      if (resData.Success) {
        this.getMeetingList();
        this.resetForm();
      }
    }, error => {

    });
  }


  addRSVP(rsvpType, meetingId) {
    var meetingRSVP: MeetingRSVPs = this.createMeetingRSVPModel(rsvpType);
    let resData;
    this.service.addRSVP(meetingId, meetingRSVP).subscribe(response => {
      resData = response;
      if (resData.Success) {
        this.getMeetingList();
      } else {
        console.log('Error');
      }
    }, error => {

    });
  }

  uploadMeetingMinute(meetingId: string) {
    this.disableUploadMinuteBtn = true;
    const meetingMinutes = this.createMeetingMinutesModel();
    let resData;
    this.service.uploadMeetingMinutes(meetingMinutes, this.requestDocuments, "MeetingMinuteDocuments", meetingId, this.domain).subscribe(response => {
      resData = response;
      if (resData.Success) {
        this.getMeetingDetail(meetingId);
        this.resetMeetingMinuteForm();
      }
    });
    console.log(this.meetingMinuteForm);
  }

  cleanURL(oldURL: string) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(oldURL);
  }

  displayNextDocument() {
    console.log(this.documentIndex);
    this.singleUrl = this.meetingDetail.MeetingDocuments[this.documentIndex].DocumentPath;
  }

  displayDocument(index: number) {
    this.display = true;
    this.singleUrl = this.meetingDetail.MeetingDocuments[this.documentIndex].DocumentPath;
  }

  addAgenda() {
    this.agendaItemNumber = this.agendaItemNumber + 1;
    let meetingAgenda = new MeetingAgenda();
    meetingAgenda.MeetingAgendaId = Guid.create().toString(),
      meetingAgenda.AgendaItemNumber = this.agendaItemNumber,
      meetingAgenda.AgendaDetail = this.agendaForm.controls.agendaDetail.value,
      meetingAgenda.AgendaDescription = this.agendaForm.controls.agendaDescription.value
    this.meetingAgendaList.push(meetingAgenda);
    this.agendaForm.reset();
    this.agendaFormDirective.resetForm();
  }

  //remove agenda
  removeAgenda(agendaId) {
    this.meetingAgendaList = this.meetingAgendaList.filter(a => a.MeetingAgendaId !== agendaId);
  }

  //remove agenda
  editAgendaIconClick(agendaId) {
    this.agendaEditMode = true;
    this.agendaId = agendaId;
    const agenda = this.meetingAgendaList.find(a => a.MeetingAgendaId === agendaId);
    this.agendaForm = this.formBuilder.group({
      agendaDetail: [agenda.AgendaDetail, Validators.required],
      agendaDescription: [agenda.AgendaDescription, Validators.required]
    });
  }

  editMeetingIconClick() {
    this.showMeetingDetail = false;
    this.meetingEditMode = true;
    if (this.meetingDetail.Meeting !== null) {
      this.meetingId = this.meetingDetail.Meeting.id;
      const meetingAudienceType = this.meetingDetail.Meeting.MeetingAudienceType != null ? this.meetingDetail.Meeting.MeetingAudienceType.toString() : null;
      const meetingType = this.meetingTypes.find(a => a.Name == this.meetingDetail.Meeting.MeetingType);
      this.meetingForm.controls.title.setValue(this.meetingDetail.Meeting.Title);
      this.meetingForm.controls.startDateTime.setValue(this.meetingDetail.Meeting.ScheduledEnd);
      this.meetingForm.controls.endDateTime.setValue(this.meetingDetail.Meeting.ScheduledStart);
      this.meetingForm.controls.meetingType.setValue(meetingType);
      this.meetingForm.controls.location.setValue(this.meetingDetail.Meeting.Location);
      this.meetingForm.controls.meetingAudienceType.setValue(meetingAudienceType);
      this.meetingAgendaList = this.meetingDetail.Meeting.MeetingAgenda;
      console.log('deatil', this.meetingDetail);
      if (this.meetingDetail.MeetingDocuments !== null && typeof this.meetingDetail.MeetingDocuments != 'undefined') {
        this.meetingDetail.MeetingDocuments.forEach(document => {
          let doc: RequestDocument = {
            Name: document.DocumentName,
            FileSize: document.FileSize,
            InputStream: document.DocumentPath,
            MediaType: document.MediaType,
            DocumentId: document.id
          }
          this.fileData.push(doc);
        });

      }

      console.log('doc', this.fileData);
    }

  }


  editAgenda() {
    console.log(this.meetingAgendaList);
    this.meetingAgendaList.forEach(
      a => {
        if (a.MeetingAgendaId === this.agendaId) {
          a.AgendaDescription = this.agendaForm.value.agendaDescription,
            a.AgendaDetail = this.agendaForm.value.agendaDetail
        }
        return a;
      }
    );
    this.agendaForm.reset();
    this.agendaEditMode = false;
    this.agendaFormDirective.resetForm();
  }

  getDate() {
    return new Date();
  }

  showRSVP(meetingId: string) {
    this.meetingId = meetingId;
    if (this.rsvpUserListDisplay) {
      this.rsvpUserListDisplay = false;
    } else {
      this.rsvpUserListDisplay = true;
    }
  }


  // on file upload for multiple
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.fileData.push({
            InputStream: event.target.result,
            Name: evt.target.files[i].name,
            MediaType: evt.target.files[i].name.substring(evt.target.files[i].name.indexOf(".")),
            FileSize: evt.target.files[i].size.toString(),
            DocumentId: ''
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  // on file upload For singke file
  onUploadChangeMeetingMinute(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.fileDataForMeetingMinute = {
          InputStream: event.target.result,
          Name: evt.target.files[0].name,
          MediaType: evt.target.files[0].name.substring(evt.target.files[0].name.indexOf(".")),
          FileSize: evt.target.files[0].size.toString(),
          DocumentId: ''
        };
        this.requestDocuments.push(this.fileDataForMeetingMinute);
      }
      reader.readAsDataURL(evt.target.files[0]);

    }
  }


  // remove uploaded images
  removeImage(name) {
    this.fileData = this.fileData.filter(a => a.Name !== name);
  }

  bytesToKb(bytes) {
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return bytes != null ? Math.round(bytes / Math.pow(1024, i)) + 'KB' : '';
  };

  showMeetingMinute() {
    return new Date(this.meetingDetail.Meeting.ScheduledStart).getTime() < new Date().getTime() ? true : false;

  }

  meetingMinuteToggle(meetingId: string) {
    this.meetingId = meetingId;
    if (this.showMeetingMinuteBox)
      this.showMeetingMinuteBox = false;
    else
      this.showMeetingMinuteBox = true;
  }

  resetForm() {
    this.meetingForm.reset();
    this.fileData = [];
    this.meetingFormDirective.resetForm();
    this.agendaEditMode = false;
    this.meetingEditMode = false;
    this.disableBtn = false;
    this.showMeetingDetail = null;
    this.meetingAgendaList = [];
  }

  resetMeetingMinuteForm() {
    this.meetingMinuteForm.reset();
    this.meetingMinuteFormDirective.resetForm();
    this.disableUploadMinuteBtn = false;
    this.showMeetingMinuteBox = false;
    this.fileDataForMeetingMinute = new RequestDocument();
  }

  showEditMeetingIcon() {
    if (this.meetingDetail != null)
      if ((new Date(this.meetingDetail.Meeting.ScheduledStart).getTime() > new Date().getTime()) && this.meetingDetail.Meeting.CreatedByUserId == this.userId)
        return true;
      else
        return false;
    else
      return false;
  }
}
