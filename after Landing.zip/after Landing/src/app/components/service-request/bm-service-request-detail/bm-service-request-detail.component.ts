import { Component, OnInit, ViewChild } from '@angular/core';
import { ServiceRequestService } from 'src/app/services/service-request.service';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { CaseFeatureType, addMotion, VoteModel, NoteType, ServiceRequestStatus, UpdateServiceStatus } from './bm-service-request.model';
import { CaseNoteModel } from '../ho-service-request-detail/ho-service-request-detail.model';
import { Router } from '@angular/router';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';

@Component({
  selector: 'app-bm-service-request-detail',
  templateUrl: './bm-service-request-detail.component.html',
  styleUrls: ['./bm-service-request-detail.component.scss']
})
export class BmServiceRequestDetailComponent implements OnInit {
  requestId;
  serviceRequestData: any;
  documents: any;
  caseNotes: any;
  motion: any;
  addMotionForm: FormGroup;
  addCaseForm: FormGroup;
  reopenForm: FormGroup;
  completeForm: FormGroup;
  cancleForm: FormGroup;
  rateForm: FormGroup;
  associationId :string;
  associationName:string;
  documentType = "Motion";
  typeOfDocument = "CaseDocuments";
  domain: string;
  fileData = [];
  serviceRequestStatusEnum = ServiceRequestStatus;
  serviceRequestStatus: string = "";
  isDisplayVoteList: boolean = false;
  isComponentLoad : boolean= false;
  rate = 0;
  userData: UserData;

  /*Board Cast Status Form*/
  frmCreateBoardTaskStatus: FormGroup;
  isSubmitBtnDisabledBoardTaskStatus: boolean = false;
  resDataCreateBoardTaskStatus: any;
  @ViewChild('formDirectiveBoardTaskStatus') formDirectiveBoardTaskStatus: FormGroupDirective;

   /*Completed Form*/
   frmCreateComplete: FormGroup;
   isSubmitBtnDisabledComplete: boolean = false;
   resDataCreateComplete: any;
   @ViewChild('formDirectiveComplete') formDirectiveComplete: FormGroupDirective;

  constructor(private serviceRrequest: ServiceRequestService, private formBuilder: FormBuilder, private router: Router, private readonly appConfig: AppConfig) { 
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.domain =  "testassociation";//this.userData.UserAssociations[0].Domain;

    this.createBoardTaskStatusForm();
    this.createCompleteForm();
  }

  ngOnInit() {
    
    this.requestId = this.serviceRrequest.requestId;
    if (!this.requestId) {
      this.router.navigate(['/ServiceRequest']);
    }
    
    this.getServiceRequestDetail();
    this.addMotionForm = this.formBuilder.group({
      description: ['', Validators.required],
    });
    this.addCaseForm = this.formBuilder.group({
      note: ['', Validators.required],
      attechment: [''],
      caseNoteId: [''],
    });
    this.reopenForm = this.formBuilder.group({
      reason: ['', Validators.required],
    });
    this.completeForm = this.formBuilder.group({
      comments: ['', Validators.required],
    });
    this.rateForm = this.formBuilder.group({
      comments: ['', Validators.required],
    });

  }
  // get Detail Data
  getServiceRequestDetail() {
    this.serviceRrequest.getServiceRequestDetail(this.requestId).subscribe(
      (response: any) => {
        if (response.RequestDetail.Success) {
          debugger
          this.serviceRequestData = response.RequestDetail.ServiceRequest;
          this.serviceRequestStatus =  this.serviceRequestData.ServiceRequestStatus ;
          this.documents = response.RequestDetail.Document;
          this.caseNotes = response.RequestDetail.CaseNotes;
          this.motion = response.RequestDetail.Motion;
          this.isComponentLoad = true;
        }
      }
    );
  }
  // reset Cancled Request Form
  resetAddMotionForm() {
    this.addMotionForm.reset();
    document.getElementById('closeModel').click();
  }
  // add motion
  addMotion() {
    let motion = this.createMotionModel();
    this.serviceRrequest.addMotion(motion).subscribe(
      (response: any) => {
        if (response.caseRequestListResults[0].Success) {
          this.resetAddMotionForm();
          this.getServiceRequestDetail();
          console.log('Motion is Added');
        }
      }
    );
  }
  // add motion model
  createMotionModel() {
    let model: addMotion = {
      CaseId: this.serviceRequestData.CaseId,
      AssociationId: this.associationId,
      AssociationName: this.associationName,
      CreatedByUserName: this.serviceRequestData.CreatedByUserName,
      CreatedByUserId: this.serviceRequestData.CreatedByUserId,
      CreatedOn: new Date(),
      Description: this.addMotionForm.controls.description.value,
      CaseFeatureType: CaseFeatureType.ServiceRequest,
      DocumentType: this.documentType
    }
    return model;
  }
  /*Display list of vote*/
  displayVoteListToggle() {
    this.isDisplayVoteList
    if (this.isDisplayVoteList)
      this.isDisplayVoteList = false;
    else
      this.isDisplayVoteList = true;
  }
  // add vote
  vote(vote) {
    let votes = this.createVoteModel(vote);
    this.serviceRrequest.vote(this.serviceRequestData.CaseId, this.associationId, this.requestId, votes).subscribe(
      (response: any) => {
        if (response.caseRequestListResults[0].Success) {
          this.getServiceRequestDetail();
          console.log('Vote is Added');
        }
      }
    );
  }
  // vote Model
  createVoteModel(vote) {
    let model: VoteModel = {
      Vote: vote,
      CreatedByUserName: this.serviceRequestData.CreatedByUserName,
      CreatedByUserId: this.serviceRequestData.CreatedByUserId
    }
    return model;
  }
  // upload Document
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          let type = evt.target.files[i].name.split(".");
          this.fileData.push({
            inputStream: event.target.result,
            name: evt.target.files[i].name,
            type: evt.target.files[i].type,
            mediaType: type[1]
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }
  // reset Add CaseNote Form
  resetAddaddCaseForm() {
    this.addCaseForm.reset();
    this.fileData = [];
  }
  // add new case note
  addCase(notType) {
    let CaseNotes = this.createCaseModel(notType);
    this.serviceRrequest.addCaseNote(CaseNotes).subscribe(
      (response: any) => {
        if (response.caseRequestListResults[0].Success) {
          this.getServiceRequestDetail();
          this.resetAddaddCaseForm();
          console.log('Add Notes');
        }
      }
    );
  }
  // case note model
  createCaseModel(notType) {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: this.typeOfDocument,
      Document: this.fileData,
      Domain: this.domain,
      CaseNotes:
      {
        CaseNoteId: this.addCaseForm.controls.caseNoteId.value,
        Note: this.addCaseForm.controls.note.value,
        NotesType: notType,
        CaseFeatureType: CaseFeatureType.ServiceRequest,
        CreatedByUserName: this.serviceRequestData.CreatedByUserName,
        CreatedByUserId: this.serviceRequestData.CreatedByUserId,
        CaseId: this.serviceRequestData.CaseId
      }
    }
    return model;
  }

  // Reopen Request
  reopenRequest() {
    let CaseStatus = this.createReopenRequestModle();
    this.serviceRrequest.updatServiceRequestStatus(CaseStatus).subscribe(
      (response: any) => {
        if (response.caseRequestListResults[0].Success) {
          this.resetreopenForm();
          this.getServiceRequestDetail();
          console.log('Request is Reopen');
        }
      }
    );
  }
  // reset reopen Request Form
  resetreopenForm() {
    this.reopenForm.reset();
    document.getElementById('closeModell').click();
  }
  // Cancled Request Model
  createReopenRequestModle() {
    let model = {
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreateComplete.controls.comments.value,
        CaseId: this.serviceRequestData.caseId,
        CreatedByUserName: this.serviceRequestData.CreatedByUserName,
        CreatedByUserId: this.serviceRequestData.CreatedByUserId,
        NotesType: NoteType.Homeowner,
        CaseFeatureType: CaseFeatureType.BoardTask
      },
      RequestId: this.requestId,
      StatusType: ServiceRequestStatus.InProgress
    }
    return model;
  }

  /*Update status of board task*/

  createBoardTaskStatusForm() {
    this.cancleForm = this.formBuilder.group({
      comments: ['', Validators.required]
    });
  }

  cancleServiceRequestStatus() {
    if (this.cancleForm.valid) {
      this.isSubmitBtnDisabledBoardTaskStatus = true;
      let model = this.createCancleServiceRequestStatusModel();
      this.serviceRrequest.updatServiceRequestStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledBoardTaskStatus = false;
        this.resDataCreateBoardTaskStatus = res;
        if (this.resDataCreateBoardTaskStatus.caseRequestListResults[0].Success) {
          this.getServiceRequestDetail();
          this.resetcancleFormForm();
          console.log('Request is cancle');
        }
      });
    }
  }

  createCancleServiceRequestStatusModel() {
    const model: UpdateServiceStatus = {
      RequestId: this.requestId,
      StatusType: ServiceRequestStatus.Canceled,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.cancleForm.controls.comments.value,
        CaseId: this.serviceRequestData.CaseId,
        NotesType: NoteType.Homeowner,
        CreatedByUserName: this.serviceRequestData.CreatedByUserName,
        CreatedByUserId: this.serviceRequestData.CreatedByUserId,
        CaseFeatureType: CaseFeatureType.ServiceRequest
      }
    }
    return model;
  }


  resetcancleFormForm() {       
    this.cancleForm.reset();
    this.formDirectiveBoardTaskStatus.resetForm();
    document.getElementById('closeCancleModel').click();

  }

  /*Create Complete of board task */
  createCompleteForm() {
    this.frmCreateComplete = this.formBuilder.group({
      comments: ['', Validators.required]
    });
  }

  onSubmitComplete() {

    if (this.frmCreateComplete.valid) {
      this.isSubmitBtnDisabledComplete = true;
      let model = this.createCompleteFormModel();
      this.serviceRrequest.updatServiceRequestStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledComplete = false;
        this.resDataCreateComplete = res;
        if (this.resDataCreateComplete.caseRequestListResults[0].Success === true) {
          console.log("Reopen saved successfully");
          this.getServiceRequestDetail();
          this.resetCompleteForm();
        }
        else if (this.resDataCreateComplete.caseRequestListResults[0].Success === false) {
          console.log("Reopen not saved");
        }
      });
    }
  }

  createCompleteFormModel() {
    const model: UpdateServiceStatus = {
      RequestId: this.requestId,
      StatusType: ServiceRequestStatus.Completed,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreateComplete.controls.comments.value,
        CaseId: this.serviceRequestData.caseId,
        CreatedByUserName: this.serviceRequestData.CreatedByUserName,
        CreatedByUserId: this.serviceRequestData.CreatedByUserId,
        NotesType: NoteType.Homeowner,
        CaseFeatureType: CaseFeatureType.ServiceRequest
      }
    }
    return model;
  }


  resetCompleteForm() {
    this.frmCreateComplete.reset();
    this.formDirectiveComplete.resetForm();
    document.getElementById('closeModelComplete').click();
  }

  getRate(data) {
    this.rate= data;
    let i;
    for( i=1; i<= 5;i++){
      document.getElementById(i).style.backgroundImage = "";
    }
    for( i=1; i<= data;i++){
      document.getElementById(i).style.backgroundImage = "url('http://www.htmldrive.net/edit_media/2010/201008/20100819/starrating/images/star.jpg')";
    }
  }
  resetRateForm() {
    this.rateForm.reset();
    let i;
    for( i=1; i<= 5;i++){
      document.getElementById(i).style.backgroundImage = "";
    }
    document.getElementById('closRate').click();
  }
  addRating() {
    let model = {
      Comment: this.rateForm.controls.comments.value,
      Ratings: this.rate,
      CreatedByUserId: this.serviceRequestData.CreatedByUserId,
      CreatedByUserName: this.serviceRequestData.CreatedByUserName,
    };
    this.serviceRrequest.rate(this.serviceRequestData.id,this.domain,model).subscribe(
      (response) => {
        this.resetRateForm();
      }
    );
    
  }
}
