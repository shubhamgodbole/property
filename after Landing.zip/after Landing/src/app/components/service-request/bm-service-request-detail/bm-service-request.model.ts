
export enum ServiceRequestStatus {
    All = "All",
    New = "New",
    InProgress = "InProgress",
    AwaitingBoardDecision = "AwaitingBoardDecision",
    Completed = "Resolved",
    Canceled = "Canceled",
}

export class addMotion {
    CaseId: string
    AssociationId: string
    AssociationName: string
    CreatedByUserId: string
    CreatedByUserName: string
    CreatedOn: Date
    Description: string
    CaseFeatureType: string
    DocumentType: string
}
export enum CaseFeatureType {
    ServiceRequest = "ServiceRequest",
    BoardTask = "BoardTask",
    Violation = "Violation",
    ARCRequest = "ARCRequest"
}

export class VoteModel {
    Vote: string
    CreatedByUserId: string
    CreatedByUserName: string
}

export class CaseNoteModel {
    AssociationId: string;
    Domain: string;
    TypeOfDocument: string;
    Document: any[];
    CaseNotes: RequestCaseNoteModel;
}
export class RequestCaseNoteModel {
    CaseNoteId: string;
    Note: string;
    CreatedByUserId: string;
    CaseId: string;
    NotesType: string;
    CreatedByUserName: string;
    CaseFeatureType: string;
}
export enum NoteType {
    BoardMember = "BoardMember",
    CommitteeMember = "CommitteeMember",
    Homeowner = "Homeowner",
    General = "General"
}

export class ReopenModel {
    CaseNoteId:string
    StatusReason: string
    Reason: string
    CreatedByUserId: string
    CreatedByUserName: string
    CreatedOn: Date
}


export class UpdateServiceStatus {
    RequestId: string;
    StatusType: string;
    CaseNotes: CaseNotesModel;

}
export class CaseNotesModel {
    CaseNoteId: string;
    Note: string;
    CaseId: string;
    CreatedByUserId: string;
    NotesType: string;
    CaseFeatureType: string;
    CreatedByUserName: string;
}