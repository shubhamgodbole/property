import { Component, OnInit } from '@angular/core';
import { ServiceRequestService } from 'src/app/services/service-request.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CaseNoteModel, NoteType, CaseFeatureType } from './ho-service-request-detail.model';
import { Router } from '@angular/router';
import { ServiceRequestStatus } from '../ho-service-request-list/ho-service-request.model';
import { UpdateServiceStatus } from '../bm-service-request-detail/bm-service-request.model';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';

@Component({
  selector: 'app-ho-service-request-detail',
  templateUrl: './ho-service-request-detail.component.html',
  styleUrls: ['./ho-service-request-detail.component.scss']
})
export class HoServiceRequestDetailComponent implements OnInit {
  requestId: string;
  serviceRequestData:any;
  documents:any;
  caseNotes:any;
  addCaseForm: FormGroup;
  cancleServiceRequestForm: FormGroup;
  fileData = [];
  associationId :string;
  typeOfDocument="CaseDocuments";
  domain:string; 
  isComponentLoad : boolean= false;
  userData: UserData; 
  constructor(private serviceRrequest: ServiceRequestService,  private formBuilder: FormBuilder, private router: Router, private readonly appConfig: AppConfig) { 
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.domain = this.userData.UserAssociations[0].Domain;
  }

  ngOnInit() {
    this.requestId= this.serviceRrequest.requestId;
    this.domain = this.serviceRrequest.domain;
    if(!this.requestId) {
      this.router.navigate(['/servicerequestho']);
    }
    this.getServiceRequestDetail();
    this.addCaseForm = this.formBuilder.group({
      note: ['', Validators.required],
      attechment: [''],
      caseNoteId: [''],
    });
    this.cancleServiceRequestForm = this.formBuilder.group({
      comments: ['', Validators.required],
    });
    
  }
  // get Service Request Detail
  getServiceRequestDetail() {
    this.serviceRrequest.getServiceRequestDetail(this.requestId).subscribe(
      (response: any) => {
        if (response.RequestDetail.Success) {
          this.serviceRequestData =response.RequestDetail.ServiceRequest;
          this.documents = response.RequestDetail.Document;
          this.caseNotes =response.RequestDetail.CaseNotes;
          this.isComponentLoad = true;
        }
      }
    );
  }
  // upload Document
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
              var reader = new FileReader();
              reader.onload = (event: any) => {
                let type =  evt.target.files[i].name.split(".");
                 this.fileData.push({
                   inputStream: event.target.result,
                   name: evt.target.files[i].name,
                   type: evt.target.files[i].type,
                   mediaType: type[1]
                 });
              }
              reader.readAsDataURL(evt.target.files[i]);
      }
    } 
  }
  // reset Add case Form
  resetAddaddCaseForm() {
    this.addCaseForm.reset();
    this.fileData = [];
  }
  // add Case Note
  addCase() {
    let CaseNotes = this.createCaseModel();
    this.serviceRrequest.addCaseNote(CaseNotes).subscribe(
      (response: any) => {
          if(response.caseRequestListResults[0].Success) {
            this.getServiceRequestDetail();
            this.resetAddaddCaseForm();
            console.log('Add Notes');  
          }
      }
    );
  }
  // CaseNote Model
  createCaseModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: this.typeOfDocument,
      Document: this.fileData,
      Domain: this.domain,
      CaseNotes:
      {
        CaseNoteId: this.addCaseForm.controls.caseNoteId.value,
        Note: this.addCaseForm.controls.note.value,
        NotesType: NoteType.Homeowner,
        CaseFeatureType: CaseFeatureType.ServiceRequest,
        CreatedByUserName: this.serviceRequestData.CreatedByUserName,
        CreatedByUserId: this.serviceRequestData.CreatedByUserId,
        CaseId:this.serviceRequestData.CaseId
      }
    }
    return model;
  }
  // Cancled Request
  cancelRequest() {
    let CaseStatusReason =this.createCancleRequestModle();
    this.serviceRrequest.updatServiceRequestStatus(CaseStatusReason).subscribe(
      (response: any) => {
        if(response.caseRequestListResults[0].Success) {
            this.resetCancledRequestForm();
            this.getServiceRequestDetail();
            console.log('Request is Cancled');
        }
      }
    );
  }
  // reset Cancled Request Form
  resetCancledRequestForm() {
    this.cancleServiceRequestForm.reset();
    document.getElementById('closeModel').click();
  }
  // Cancled Request Model
  createCancleRequestModle() {
    const model: UpdateServiceStatus = {
      RequestId: this.requestId,
      StatusType: ServiceRequestStatus.Canceled,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.cancleServiceRequestForm.controls.comments.value,
        CaseId: this.serviceRequestData.CaseId,
        NotesType: NoteType.Homeowner,
        CreatedByUserName: this.serviceRequestData.CreatedByUserName,
        CreatedByUserId: this.serviceRequestData.CreatedByUserId,
        CaseFeatureType: CaseFeatureType.ServiceRequest
      }
    }
    return model;
  }
}
