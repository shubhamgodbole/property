export class UpdateServiceStatus {
    RequestId: string;
    StatusType: string;
    CaseNotes: CaseNotesModel;

}
export class CaseNotesModel {
    CaseNoteId: string;
    Note: string;
    CaseId: string;
    CreatedByUserId: string;
    NotesType: string;
    CaseFeatureType: string;
    CreatedByUserName: string;
}

export class CaseNoteModel {
    AssociationId: string;
    Domain: string;
    TypeOfDocument: string;
    Document: any[];
    CaseNotes: RequestCaseNoteModel;
}
export class RequestCaseNoteModel {
    CaseNoteId: string;
    Note: string;
    CreatedByUserId: string;
    CaseId: string;
    NotesType: string;
    CreatedByUserName: string;
    CaseFeatureType: string;
}
export enum NoteType {
    BoardMember = "BoardMember",
    CommitteeMember = "CommitteeMember",
    Homeowner = "Homeowner",
    General = "General"
}
export enum CaseFeatureType {
    ServiceRequest = "ServiceRequest",
    BoardTask = "BoardTask",
    Violation = "Violation",
    ARCRequest = "ARCRequest"
}