export class CaseRequestModel
{    
    Title:string;
    AssociationId:string;
    AssociationName :string;
    CaseType:string;
    SubCaseType:string;
    CaseCategory:string;
    CaseSubCategory:string;
    CasePriority:string;
    Comments:string;
    CustomerType:string;
    LastName:string;
    FirstName:String;
    AssociationUnitId:string;
}

export class CaseUnitModel {
    ServiceRequestDetailId:string;
    CreatedByUnitId: string;
    CreatedByUnitNumber : string;
    CreatedByUnitAddress1: string;
    CreatedByUnitAddress2: string;
    CreatedByUnitCity: string;
    CreatedByUnitState: string;
    CreatedByUnitZip: string;
}
export enum ServiceRequestStatus {
    All = "All",
    New = "New",
    InProgress = "InProgress",
    AwaitingBoardDecision = "AwaitingBoardDecision",
    Completed = "Resolved",
    Canceled = "Canceled",
}
export enum NoteType {
    BoardMember = "BoardMember",
    CommitteeMember = "CommitteeMember",
    Homeowner = "Homeowners",
    General = "General"
}