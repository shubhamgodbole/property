import { Component, OnInit, ViewChild } from '@angular/core';
import { ServiceRequestService } from 'src/app/services/service-request.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { fromEvent } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { Router } from '@angular/router';
import { CaseRequestModel, CaseUnitModel ,NoteType } from './ho-service-request.model';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { debug } from 'util';


@Component({
  selector: 'app-ho-service-request-list',
  templateUrl: './ho-service-request-list.component.html',
  styleUrls: ['./ho-service-request-list.component.scss']
})
export class HoServiceRequestListComponent implements OnInit {

  status = "All";
  selectedCaseCategory: string = "All";
  selectedPriority: string = "All";
  filter = false;
  sidebar = false;
  AssociationId : string;
  UserId :string;
  AssociationName: string;
  userName: string;
  FirstName:string;
  LastName :string;
  Role :string;
  customerType = "Association";
  caseType :string;
  noDataMessage ="No Data Found";
  allServiceRequest: any;
  statusCount: any;
  allCategory: any;
  subCategory: any;
  addRequestForm: FormGroup;
  filterByKeyWords: string = "";
  imgFlag: boolean = false;
  fileData: any = [];
  AssociationUnitId;
  subCaseType = "ServiceRequest"
  @ViewChild('searchData') searchData: any;
  associationUnitData:any = [];
  typeOfDocument="CaseDocuments";
  domain:string;
  userData: UserData; 

  constructor(private serviceRrequest: ServiceRequestService, private formBuilder: FormBuilder, private router: Router,  private readonly appConfig: AppConfig) { 
    this.userData = this.appConfig.getCurrentUser();
      this.AssociationId = this.userData.UserAssociations[0].AssociationId;
      this.AssociationName = this.userData.UserAssociations[0].Name;
      this.UserId = this.userData.UserProfileId;
      this.userName = this.userData.UserName;
      this.domain = this.userData.UserAssociations[0].Domain;
      this.FirstName = this.userName.split(' ')[0];
      this.LastName = this.userName.split(' ')[1];
      this.Role = this.userData.Role;
      
  }

  ngOnInit() {
    this.getAllServiceRequest();
    this.getAllCategory();
    this.getAllAssociationUnit();
    this.addRequestForm = this.formBuilder.group({
      serviceRequestDetailId:[''],
      title: ['', Validators.required],
      category: ['', Validators.required],
      subCategory: ['', Validators.required],
      associationUnit: ['', Validators.required],
      urgencyLevel: ['', Validators.required],
      comment: ['', Validators.required],
      attechment: ['', Validators.required],
    });
    fromEvent(this.searchData.nativeElement, 'keyup')
    .pipe(
      map((k: any) => k.target.value),
      debounceTime(1500),
    ).subscribe(val => {
      this.filterByKeyWords = val;
      this.sort();
    });
  }
  // get all serviceRequest Data
  getAllServiceRequest() {
    let status = this.status === 'All' ? '' : this.status;
    let resCategory =  this.selectedCaseCategory;
        resCategory =  resCategory === "All" ? resCategory = "" : resCategory;   
    let resPriorty = this.selectedPriority;
        resPriorty = resPriorty === "All" ? resPriorty = "" : resPriorty;
    let resFilterByKeyWords = this.filterByKeyWords;
    this.serviceRrequest.getAllServiceRequest(this.UserId,this.AssociationId, this.Role, status,resCategory,resPriorty,resFilterByKeyWords).subscribe(
      (response: any) => {
        this.allServiceRequest = response.caseRequestListResults[0].serviceRequestList;
        this.statusCount = response.caseRequestListResults[0].StatusTypeCount;
      }
    );
  }
  // get all categories
  getAllCategory() {
    this.caseType = NoteType.Homeowner;
    this.serviceRrequest.getAllCategories(this.customerType, this.caseType).subscribe(
      (response: any) => {
        this.allCategory = response.CaseType.CaseCategory
      }
    );
  }
  
  filterToggle() {
    this.clearFilter();
    if (this.filter)
      this.filter = false;
    else
      this.filter = true;
  }

  sidebarToggle() {
    if (this.sidebar) {
      this.reset();
      this.sidebar = false;
    }
    else
      this.sidebar = true;
  }
  // change status
  statusChange(s) {
    this.status = s;
    this.getAllServiceRequest();

  }
  // filter service Request data
  sort() {
    this.getAllServiceRequest();
  }
  // upload Documents
  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
              var reader = new FileReader();
              reader.onload = (event: any) => {
                let type =  evt.target.files[i].name.split(".");
                 this.fileData.push({
                   inputStream: event.target.result,
                   name: evt.target.files[i].name,
                   type: evt.target.files[i].type,
                   mediaType: type[1]
                 });
              }
              reader.readAsDataURL(evt.target.files[i]);
      }
    }
    
  }
  // remove uploaded Documents
  removeImage(src) {
    var tempArray = [];
      this.fileData.forEach((e) => {  
          if(e.inputStream !== src) {
              tempArray.push(e);
          }
    });
    this.fileData = tempArray;
    if(this.fileData.length === 0){
      this.imgFlag = true;
    } 
  }
  // get Category
  getCategory(event) {
    this.addRequestForm.controls.subCategory.setValue('');
    let subCategory =this.allCategory.filter(cat => cat.Name ===event.value );
    this.subCategory = subCategory[0].CaseSubCategories;
  }
  // send Request
  senRequest() {
    let CaseRequest = {
      Case :this.createRequestModel(),
      ServiceRequest: this.createCaseUnitModel(),
      TypeOfDocument:this.typeOfDocument,
      Domain: this.domain, 
      Document:this.fileData,     
    } ;
    this.serviceRrequest.addRequest(CaseRequest).subscribe(
      (response: any) => {
        if(response.caseRequestListResults[0].Success) {
          this.reset();
          this.getAllServiceRequest();
          console.log('Added');
        }
    });
    
  }
  // Request Model
  createRequestModel() {
    let model: CaseRequestModel = {    
      Title :  this.addRequestForm.controls.title.value,
      AssociationId:this.AssociationId,
      AssociationName: this.AssociationName,
      CaseType:this.caseType,
      SubCaseType:this.subCaseType,
      CaseCategory :  this.addRequestForm.controls.category.value,
      CaseSubCategory :  this.addRequestForm.controls.subCategory.value,
      CasePriority :  this.addRequestForm.controls.urgencyLevel.value,
      Comments :  this.addRequestForm.controls.comment.value,
      CustomerType: this.customerType,
      FirstName: this.FirstName,
      LastName: this.LastName,
      AssociationUnitId:this.addRequestForm.controls.associationUnit.value.id 
    }
    return model;
  }
  // Case Unit Model
  createCaseUnitModel() {
    let model1: CaseUnitModel ={
      ServiceRequestDetailId:this.addRequestForm.controls.serviceRequestDetailId.value,
      CreatedByUnitId: this.addRequestForm.controls.associationUnit.value.id,
      CreatedByUnitNumber : this.addRequestForm.controls.associationUnit.value.AssociationUnitNumber,
      CreatedByUnitAddress1 : this.addRequestForm.controls.associationUnit.value.AssociationUnitAddress1,
      CreatedByUnitAddress2 : this.addRequestForm.controls.associationUnit.value.AssociationUnitAddress2,
      CreatedByUnitCity : this.addRequestForm.controls.associationUnit.value.AssociationUnitCity,
      CreatedByUnitState : this.addRequestForm.controls.associationUnit.value.AssociationUnitState,
      CreatedByUnitZip:  this.addRequestForm.controls.associationUnit.value.AssociationUnitZip,
    }
    return model1
  }
  // get Requst ID & redirect on Detail page
  getRequest(requestId) {
    this.serviceRrequest.domain = this.domain;
    this.serviceRrequest.requestId =requestId;
    this.router.navigate(['/ho-service-request-detail']);
  }
  // reset Form
  reset() {
    this.sidebar = false;
    this.addRequestForm.reset();
    this.fileData = [];
  }
  // get All AssociationUnits
  getAllAssociationUnit() {
    this.serviceRrequest.getAllAssociationUnit(this.UserId,this.AssociationId).subscribe(
      (response: any) => {
        this.associationUnitData = response.AssociationUnit;
        if(this.associationUnitData.length === 1)
        {
          this.addRequestForm.controls.associationUnit.setValue(this.associationUnitData[0].AssociationUnitAddress2 !== null ? this.associationUnitData[0].AssociationUnitAddress1 + ' ' + this.associationUnitData[0].AssociationUnitAddress2 + ' '+ this.associationUnitData[0].AssociationUnitCity + ' ' + this.associationUnitData[0].AssociationUnitState +' '+ this.associationUnitData[0].AssociationUnitZip:this.associationUnitData[0].AssociationUnitAddress1 + ' ' + this.associationUnitData[0].AssociationUnitCity + ' ' + this.associationUnitData[0].AssociationUnitState +' '+ this.associationUnitData[0].AssociationUnitZip);
        }
        
      }
    );
  }
  // clear FIlter
  clearFilter() {
    this.selectedCaseCategory = "All";
    this.filterByKeyWords = "";
    this.selectedPriority = "All";
    this.filterByKeyWords = "";
    this.getAllServiceRequest();
  }
}
