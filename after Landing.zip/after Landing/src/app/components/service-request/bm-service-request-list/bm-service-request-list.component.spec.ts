import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BmServiceRequestListComponent } from './bm-service-request-list.component';

describe('BmServiceRequestListComponent', () => {
  let component: BmServiceRequestListComponent;
  let fixture: ComponentFixture<BmServiceRequestListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BmServiceRequestListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BmServiceRequestListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
