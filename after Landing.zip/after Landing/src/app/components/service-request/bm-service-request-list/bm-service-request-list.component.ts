import { Component, OnInit, ViewChild } from '@angular/core';
import { ServiceRequestService } from 'src/app/services/service-request.service';
import { fromEvent } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { Router } from '@angular/router';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';
import { NoteType } from './bm-servise-request.model';
@Component({
  selector: 'app-bm-service-request-list',
  templateUrl: './bm-service-request-list.component.html',
  styleUrls: ['./bm-service-request-list.component.scss']
})

export class BmServiceRequestListComponent implements OnInit {

  status = "All";
  filter = false;
  selectedCaseCategory: string ;
  selectedPriority: string;
  AssociationId : string;
  UserId :string;
  Role :string;
  customerType = "Association";
  caseType :string;
  noDataMessage ="No Data Found";
  allServiceRequest: any;
  statusCount: any;
  allCategory: any;
  filterByKeyWords: string = "";
  userData: UserData; 
  domain:string;
  @ViewChild('searchData') searchData: any;

  constructor(private serviceRrequest: ServiceRequestService ,private router: Router, private readonly appConfig: AppConfig) { 
    this.userData = this.appConfig.getCurrentUser();
    this.AssociationId = this.userData.UserAssociations[0].AssociationId;
    this.UserId = this.userData.UserProfileId;
    this.Role = this.userData.Role;
    this.domain =  "testassociation";
 
  }

  ngOnInit() {
    this.getAllServiceRequest();
    this.getAllCategory();
    fromEvent(this.searchData.nativeElement, 'keyup')
    .pipe(
      map((k: any) => k.target.value),
      debounceTime(1500),
    ).subscribe(val => {
      this.filterByKeyWords = val;
      this.sort();
    });
  }
  // get all serviceRequest Data
  getAllServiceRequest() {
    let status = this.status === 'All' ? '' : this.status;
    let resCategory =  this.selectedCaseCategory;
        resCategory =  resCategory === "All" ? resCategory = "" : resCategory;   
    let resPriorty = this.selectedPriority;
        resPriorty = resPriorty === "All" ? resPriorty = "" : resPriorty;
    let resFilterByKeyWords = this.filterByKeyWords;
    this.serviceRrequest.getAllServiceRequest(this.UserId,this.AssociationId, this.Role, status,resCategory,resPriorty,resFilterByKeyWords).subscribe(
      (response: any) => {
        this.allServiceRequest = response.caseRequestListResults[0].serviceRequestList;
        this.statusCount = response.caseRequestListResults[0].StatusTypeCount;
      }
    );
  }
  // get all categories
  getAllCategory() {
    this.caseType = NoteType.Homeowner;
    this.serviceRrequest.getAllCategories(this.customerType, this.caseType).subscribe(
      (response: any) => {
        this.allCategory = response.CaseType.CaseCategory
      }
    );
  }
  addClass()
  {
    this.selectedCaseCategory = "All";
    this.selectedPriority = "All";
    if(this.filter)
      this.filter = false;
    else 
      this.filter = true;
  }
  // change status
  statusChange(s) {
    this.status = s;
    this.getAllServiceRequest();
  }
  // filter service Request data
  sort() {
    this.getAllServiceRequest();
  }
  // get Requst ID & redirect on Detail page
  getRequest(requestId) {
    this.serviceRrequest.domain = this.domain;
    this.serviceRrequest.requestId =requestId;
    this.router.navigate(['/bm-service-request-detail']);
  }
  // clear FIlter
  clearFilter() {
    this.selectedCaseCategory = "All";
    this.filterByKeyWords = "";
    this.selectedPriority = "All";
    this.filterByKeyWords = "";
    this.getAllServiceRequest();
  }

}
