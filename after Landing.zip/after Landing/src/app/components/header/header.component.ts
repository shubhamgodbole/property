import { Component, OnInit } from '@angular/core';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  nav = false;
  headcreate = false;
  viewprofilelink = false;
  userData: UserData;
  menu = new Array<any>();
  parentMainMenu = new Array<any>();


  constructor(private readonly appConfig: AppConfig) {
    this.userData = this.appConfig.getCurrentUser();
    if (this.userData) {
      this.parentMainMenu = this.userData.FeatureMenuPermissions.filter(m => m.FeatureParentId === null);

      this.parentMainMenu.forEach(element => {
        var childMenu = this.userData.FeatureMenuPermissions.filter(el => el.FeatureParentId == element.FeatureId);

        const menuData = {
          parent: element,
          child: childMenu
        }
        this.menu.push(menuData);
      });
    }
  }

  ngOnInit() {
  }

  addClass() {
    if (this.nav)
      this.nav = false;
    else
      this.nav = true;
  }

  headcreateToggle() {
    if (this.headcreate)
      this.headcreate = false;
    else
      this.headcreate = true;
  }

  myprofileToggle() {
    if (this.viewprofilelink)
      this.viewprofilelink = false;
    else
      this.viewprofilelink = true;
  }

}

export class Menu {
  parent: any;
  child: any;
}