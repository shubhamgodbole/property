import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bm-inspection-list',
  templateUrl: './bm-inspection-list.component.html',
  styleUrls: ['./bm-inspection-list.component.scss']
})
export class BmInspectionListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
