import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-board-member',
  templateUrl: './board-member.component.html',
  styleUrls: ['./board-member.component.css']
})
export class BoardMemberComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
