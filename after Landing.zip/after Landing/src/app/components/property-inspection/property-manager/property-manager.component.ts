import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-property-manager',
  templateUrl: './property-manager.component.html',
  styleUrls: ['./property-manager.component.scss']
})
export class PropertyManagerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
