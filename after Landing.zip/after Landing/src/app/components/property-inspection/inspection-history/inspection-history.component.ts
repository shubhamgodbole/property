import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inspection-history',
  templateUrl: './inspection-history.component.html',
  styleUrls: ['./inspection-history.component.scss']
})
export class InspectionHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
