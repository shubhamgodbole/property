import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PmCreateReportComponent } from './pm-create-report.component';

describe('PmCreateReportComponent', () => {
  let component: PmCreateReportComponent;
  let fixture: ComponentFixture<PmCreateReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PmCreateReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PmCreateReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
