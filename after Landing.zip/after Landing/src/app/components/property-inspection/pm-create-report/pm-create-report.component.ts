import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pm-create-report',
  templateUrl: './pm-create-report.component.html',
  styleUrls: ['./pm-create-report.component.scss']
})
export class PmCreateReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
