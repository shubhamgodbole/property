import { Component, OnInit } from '@angular/core';
import { LoginApiService } from 'src/app/services/login-api.service';
import { FormBuilder, FormGroup, Validators, FormGroupDirective } from '@angular/forms';
import { flatten } from '@angular/core/src/render3/util';
import { getMatFormFieldMissingControlError, MatStepper } from '@angular/material';
import { modelGroupProvider } from '@angular/forms/src/directives/ng_model_group';
import { Case, RequestActivationCode } from './sign-up-model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {

  resData: any;
  isLinear: boolean = true;
  activationCodeForm: FormGroup;
  secondFormGroup: FormGroup;
  isSelect: boolean = false;
  displayNoActivationCodeForm: boolean = false;
  resitrationInfo;
  isIncorectInfo = true;
  incorrectInformationForm: FormGroup;
  loginForm: FormGroup;
  loginDisable: boolean = false;
  radioIncorrect: string = "continue";
  isActivationCode: boolean = true;
  activationCodeValidate: boolean = false;
  requestActivationForm: FormGroup;
  associationList: any;
  customerTypeForm: FormGroup;
  invalidActivationCode: boolean = false;
  errorMsg: boolean = false;
  isPass: string = "true";
  customerTypes: any;

  constructor(private formBuilder: FormBuilder, private service: LoginApiService, private router: Router) {

  }

  ngOnInit() {
    this.createForm();
    this.getMasterData();
  }
  
  steperClick(stepper: MatStepper) {
    console.log(stepper.selectedIndex);
  }

  validateActivationCode(stepper: MatStepper) {

    this.service.validateActivationCade(this.activationCodeForm.controls.activationCode.value).subscribe(response => {
      this.resData = response;
      if (this.resData.Success) {
        this.resitrationInfo = this.resData.UserRegistrationDetails;
        this.activationCodeValidate = true;
        setTimeout(() => {
          this.goForward(stepper);
        }, 20);

      }
      else {
        console.log("Invalid Code");
      }
    }, error => {

    })
  }

  goForward(stepper: MatStepper) {
    stepper.next();
  }

  createForm() {
    this.activationCodeForm = this.formBuilder.group({
      activationCode: ['', Validators.required],
      isActivationCode: ['true'],
      activationCodeValid: ['', Validators.required]
    });

    this.customerTypeForm = this.formBuilder.group({
      customerType: ['', Validators.required]
    });

    this.incorrectInformationForm = this.formBuilder.group({
      incorrectRadio: ['true'],
      email: ['', Validators.required],
      comment: ['', Validators.required]
    });

    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    });

    this.requestActivationForm = this.formBuilder.group({
      association: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      zip: ['', Validators.required],
      address1: ['', Validators.required],
      address2: ['', Validators.required],
      email: ['', Validators.required],
      mobile: ['', Validators.required]
    });

  }

  changeSteeper(hasCode) {
    if (hasCode)
      this.isActivationCode = true;
    else
      this.isActivationCode = false;
  }

  changeDiv(isIncorectInfo) {
    if (isIncorectInfo)
      this.isIncorectInfo = true;
    else
      this.isIncorectInfo = false;
  }



  incorrectInfoRequest() {
    let res;
    let model = this.createIncorrectInfoModel();
    this.service.requestIncorectInfo(model).subscribe(response => {
      res = response;
      if (res.Success) {
        alert("Thank you our team will contact you soon");
        this.loginDisable = true;
      }
      else {
        console.log("Invalid Information");
      }
    }, error => {

    })
  }

  createIncorrectInfoModel() {
    const associationName = this.requestActivationForm.controls.association.value.AssociationName;
    const resAssociationName = this.resitrationInfo != null ? this.resitrationInfo.AssociationName : null;
    const _case: Case =
    {
      Title: this.displayNoActivationCodeForm ? 'Request For Activation Code' : "Incorrect User Information",
      Description: this.displayNoActivationCodeForm ? '' : this.incorrectInformationForm.controls.comment.value,
      CustomerType: this.displayNoActivationCodeForm ? this.customerTypeForm.controls.customerType.value.Name : "Association",
      AssociationName: this.displayNoActivationCodeForm ? associationName : resAssociationName
    }

    const model: RequestActivationCode = {
      AssociationName: this.displayNoActivationCodeForm ? associationName : this.resitrationInfo.AssociationName,
      UnitNumber: this.displayNoActivationCodeForm ? null : this.resitrationInfo.UnitNumber,
      Address1: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.address1.value : this.resitrationInfo.UnitAddress1,
      Address2: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.address2.value : this.resitrationInfo.UnitAddress2,
      City: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.city.value : this.resitrationInfo.UnitCity,
      State: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.state.value : this.resitrationInfo.UnitState,
      Zip: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.zip.value : this.resitrationInfo.UnitZip,
      Mobile: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.mobile.value : this.resitrationInfo.mobile,
      Case: _case,
      Email: this.displayNoActivationCodeForm ? this.requestActivationForm.controls.email.value : this.incorrectInformationForm.controls.email.value
    }
    return model;
  }

  createLogin() {
    let res;
    this.service.registration(this.loginForm.value.email, this.loginForm.value.password, this.activationCodeForm.controls.activationCode.value).subscribe(response => {
      res = response;
      console.log('response ', res);
      if (res.Errors.length !== 0)
        console.log("invalid Info");
      else
        this.router.navigate(['login']);
    },
      (err) => {
        console.log(err);
      });
  }

  getMasterData() {
    let res;
    this.service.getMasterData().subscribe(response => {
      res = response;
      if (res.Success){
        this.associationList = res.GetMasterDataForActivationCode.Association;
        this.customerTypes = res.GetMasterDataForActivationCode.CustomerType;
      }
      else
        console.log(res.Errors[0].message);
    },
      (err) => {
        console.log(err);
      });
  }

  resetForm(formDirective: FormGroupDirective) {
    console.log("resetForm");
    this.requestActivationForm.reset();
    formDirective.resetForm();
  }

}
