import { Component, OnInit, ViewChild } from '@angular/core';
import { BoardMemberDirectoryApiService } from 'src/app/services/board-member-directory-api.service';
import {  FormGroup, FormBuilder, Validators, FormGroupDirective, FormArray } from '@angular/forms';
import { startWith, map } from 'rxjs/operators';
import { BoardMember, BoardMemberPosition } from './board-member-directory-model';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';

@Component({
  selector: 'app-board-member-directory',
  templateUrl: './board-member-directory.component.html',
  styleUrls: ['./board-member-directory.component.scss']
})
export class BoardMemberDirectoryComponent implements OnInit {
  frmBoardMember: FormGroup;
  addboardmember: boolean = false;
  resData: any;
  boardMembersList: any;
  userList: any;
  filteredUsers: any;
  editMode: boolean = false;
  associationBoardTitles;
  userName: string;
  boardMember;
  termStartEndDateValidation: boolean = false;
  positionStartEndDateValidation: boolean = false;
  btnDisable: boolean = false;
  addRes: any;
  editRes: any;
  userData: UserData;
  associationId: string;
  associationName: string;
  userId: string;
  domain: string;

  @ViewChild('formDirective') formDirective: FormGroupDirective;

  constructor(private service: BoardMemberDirectoryApiService, private readonly formBuilder: FormBuilder, private readonly appConfig: AppConfig) {
    this.userData = appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.domain =  this.userData.UserAssociations[0].Domain;
    this.getMasterData();
  }

  private _filterUsers(value: string) {
    const filterValue = value;
    return this.userList.filter(user => user.UserName.toLowerCase().indexOf(filterValue) === 0);
  }

  ngOnInit() {
    this.getBoardMemberDirectory();
    this.createForm();
  }

  displayFn(user) {
    return user ? user.UserName : null;
  }

  createForm() {
    this.frmBoardMember = this.formBuilder.group({
      boardTermStartDate: ['', Validators.required],
      boardTermEndDate: ['', Validators.required],
      userName: ['', Validators.required],
      homeOwner: ['', Validators.required],
      positions: this.formBuilder.array([])
    });
  }

  // use for show and hide model
  addboardmemberToggle() {
    if (this.addboardmember) {
      this.addboardmember = false;
    }
    else {
      this.addboardmember = true;
    }
    this.removeAllPositionControl();
  }

  //use for remove position control
  removeAllPositionControl() {
    for (let i = 0; i < this.boardMemberPositions.length; i++) {
        console.log('assd ', i);
        this.removePosition(i);
    }
  }

  //Get List of board member
  getBoardMemberDirectory() {
    this.service.getBoardMembers(this.associationId).subscribe(
      (response) => {
        this.resData = response;
        this.boardMembersList = this.resData.BoardMembersList;
      },
      (error) => {

      }
    );
  }

  // use for get master data that is use for bind data in form
  getMasterData() {
    this.service.getMasterData(this.associationId).subscribe(
      (response) => {
        this.resData = response;
        this.userList = this.resData.BoardMemberMasters.UserProfiles;
        this.associationBoardTitles = this.resData.BoardMemberMasters.AssociationBoardTitles;
        this.getAssociationTitle();
        this.filteredUsers = this.frmBoardMember.controls.homeOwner.valueChanges
          .pipe(
            startWith(''),
            map((data) => data ? this._filterUsers(data) : this.userList.slice())
          );
      },
      (error) => {

      }
    );
  }

  //Use for get association title
  getAssociationTitle() {
    this.associationBoardTitles.map(
      (a) => {
        if (a.BoardTitle === 'Other')
          a.BoardTitle = a.CustomBoardTitleName;
        else
          a.BoardTitle = a.BoardTitle;
        return a;
      });
  }

  // Call after click on add or Edit button
  onSubmit() {
    this.btnDisable = true;
    const boardMemberModel = this.createModel();
    if (this.editMode)
      this.editBoardMember(boardMemberModel);
    else
      this.addBoardMember(boardMemberModel);
  }

  //use for Create Board Member model
  createModel() {
   
    let boardMemberPositions = new Array<BoardMemberPosition>();
    const formPositions = this.frmBoardMember.controls.positions.value;
    for (let i = 0; i < formPositions.length; i++) {
       let boardPosition: BoardMemberPosition = new BoardMemberPosition();
       boardPosition.PositionTitleName = formPositions[i].positionTitle.BoardTitle;
       boardPosition.CustomBoardTitleName = formPositions[i].positionTitle.CustomBoardTitleName;
       boardPosition.PositionTitleId = formPositions[i].positionTitle.AssociationBoardTitleId;
       boardPosition.PositionEndDate = new Date(formPositions[i].positionEndDate).toISOString();
       boardPosition.PositionStartDate = new Date(formPositions[i].positionStartDate).toISOString();
       boardPosition.BoardMemberPositionId = formPositions[i].positionTitle.BoardMemberPositionId;
       boardMemberPositions.push(boardPosition);
    }

    const model: BoardMember = {
      id: this.editMode ? this.boardMember.id : '',
      BoardMemberCoverImagepath: '',
      BoardMemberProfileImagepath: '',
      Description: '',
      BoardMemberUserProfileId: this.editMode ? this.boardMember.BoardMemberUserProfileId : this.frmBoardMember.value.homeOwner.UserProfileId.toString(),
      BoardMemberName: this.editMode ? this.boardMember.BoardMemberName : this.frmBoardMember.value.homeOwner.UserName,
      BoardMemberStartDate: new Date(this.frmBoardMember.value.boardTermStartDate).toISOString(),
      BoardMemberEndDate: new Date(this.frmBoardMember.value.boardTermEndDate).toISOString(),
      AssociationId: this.associationId,
      AssociationName: this.associationName,
      CreatedOn: new Date().toISOString(),
      CreatedByUserId: this.userId,
      CreatedByUserName: this.userName,
      BoardMemberPositions: boardMemberPositions
    }
    
    return model;
  }

  // use for add board member
  addBoardMember(boardMemberModel: BoardMember) {
    this.service.addBoardMember(boardMemberModel, this.domain).subscribe(
      (res) => {
        this.addRes = res;
        this.btnDisable = true;
        this.addboardmember = false;
        this.resetForm();
        this.getBoardMemberDirectory();
        if (this.addRes.Success === false) {
          console.log("Board Member is not added, Please try again");
        }
      },
      (error) => {

      }

    );
  }

  //use for edit board member
  editBoardMember(boardMemberModel: BoardMember) {
    console.log(boardMemberModel);
    this.service.editBoardMember(boardMemberModel).subscribe(
      (res) => {
        this.editRes = res;
        this.btnDisable = true;
        this.editMode = false;
        this.resetForm();
        this.getBoardMemberDirectory();
        if (!this.editRes.success) {
          console.log("Unable to edit Board Member");
        }
      }, (error) => {

      }
    );
  }

  resetForm() {
    this.frmBoardMember.reset();
    this.formDirective.resetForm();
    this.addboardmember = false;
    this.btnDisable = false;
    this.editMode = false;
    this.removeAllPositionControl();
  }

  // use for bind data for edit
  boardMemberEdit(boardMember) {
    console.log(boardMember);
    this.editMode = true;
    this.addboardmemberToggle();
    this.boardMember = boardMember;
    this.userName = boardMember.BoardMemberName;
    this.frmBoardMember.controls.boardTermEndDate.setValue(boardMember.BoardMemberEndDate);
    this.frmBoardMember.controls.boardTermStartDate.setValue(boardMember.BoardMemberStartDate);
    let countPosition = boardMember.BoardMemberPositions.length;
    if (countPosition > 0) {
      for (let i = 0; i < countPosition; i++) {
        this.editPosition(boardMember.BoardMemberPositions[i]);
      }
    }
   
  }

  getToday(): string {
    return new Date().toISOString().split('T')[0]
  }

  onDateChange(position) {
    console.log('position', position);
  }

  get boardMemberPositions() {
    return this.frmBoardMember.get('positions') as FormArray;
  }

  addPosition() {
    this.boardMemberPositions.push(this.formBuilder.group({
      positionTitle: ['', Validators.required],
      positionStartDate: ['', Validators.required],
      positionEndDate: ['']
    }));
  }

  editPosition(model: any) {
    const position = this.associationBoardTitles.find(a => a.AssociationBoardTitleId == model.PositionTitleId);
    this.boardMemberPositions.push(this.formBuilder.group({
      positionStartDate: [model.PositionStartDate, Validators.required],
      positionEndDate: [model.PositionEndDate],
      positionTitle: [position, Validators.required],
      boardMemberPositionId: [model.BoardMemberPositionId],
      }));
  }

  removePosition(index) {
    this.boardMemberPositions.removeAt(index);
  }
}

