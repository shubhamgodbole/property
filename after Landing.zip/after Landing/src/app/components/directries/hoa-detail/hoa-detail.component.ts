import { Component, OnInit } from '@angular/core';
import { HoaDirectoryApiService } from 'src/app/services/hoa-directory-api.service';
import { BasicDetailsModel } from '../../my-profile/my-profile.model';
import { Router } from '@angular/router';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';

@Component({
  selector: 'app-hoa-detail',
  templateUrl: './hoa-detail.component.html',
  styleUrls: ['./hoa-detail.component.scss']
})
export class HoaDetailComponent implements OnInit {
  resData: any;
  hoaDetailList: any;
  unitEmergencyContactsList: any;
  vehiclesList: any;
  petsList: any;
  tenantsList: any;
  associationUnitId: string;
  accountNumber: string;
  unitNumber: string;
  basicDetails: BasicDetailsModel;
  serviceList: any;
  violationList: any;
  arcRequestList: any;
  userData: UserData;
  role: string;
  constructor(
    private _router: Router,
    private hoaDirectoryApiService: HoaDirectoryApiService,
    private readonly appConfig: AppConfig) {
      this.userData = appConfig.getCurrentUser();
      this.role = this.userData.Role;
     }

  ngOnInit() {
    if (this.hoaDirectoryApiService.userId !== undefined && this.hoaDirectoryApiService.associationUnitId !== undefined && this.hoaDirectoryApiService.associationId !== undefined) {
      this.getData();
    } else {
      this._router.navigate(["/hoa-directory"]);
    }
  }

  getData() {
    this.hoaDirectoryApiService.getHoaDetails(this.hoaDirectoryApiService.userId, this.hoaDirectoryApiService.associationUnitId, this.hoaDirectoryApiService.associationId).subscribe(res => {
      this.resData = res;
      debugger;
      if (this.resData.Success === true) {
        this.hoaDetailList = this.resData.HOADetail.UserProfileDetailWithAddress;
        this.associationUnitId = this.hoaDirectoryApiService.associationUnitId;
        if (this.hoaDetailList !== null) {
          this.vehiclesList = this.hoaDetailList.UnitVehicles;
          this.petsList = this.hoaDetailList.UnitPets;
          this.tenantsList = this.hoaDetailList.UnitTenants;
          this.accountNumber = this.hoaDetailList.UnitRole.UnitRoleProfiles[0].AccountNumber;
          this.unitNumber = this.hoaDetailList.AssociationUnit.AssociationUnitNumber;
          this.unitEmergencyContactsList = this.hoaDetailList.UnitEmergencyContacts;
          this.getBasicDetails();
        }
        this.serviceList = this.resData.HOADetail.serviceRequestList;
        this.violationList = this.resData.HOADetail.violationList;
        this.arcRequestList = this.resData.HOADetail.arcRequestList;
      
      } else {
        alert("Details Not Found");
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  getBasicDetails() {
    let propertyAddress = this.getFullMailingAddress();
    let mailAddress = this.getFullMailingAddress();
    let basicDetail: BasicDetailsModel = {
      dateOfBirth: this.hoaDetailList.UserProfile.BirthDate,
      emailAddress: this.hoaDetailList.UserProfile.EmailAddress,
      gender: this.hoaDetailList.UserProfile.Gender,
      homePhoneNumber: this.hoaDetailList.UserProfile.HomePhone,
      mailingAddress: mailAddress,
      mobileNumber: this.hoaDetailList.UserProfile.Mobile,
      propertyAddress: propertyAddress,
      workPhoneNumber: this.hoaDetailList.UserProfile.WorkPhone1,
    }
    this.basicDetails = basicDetail;
  }

  getFullPropertyAddress(): string {
    let propertyAddress = "";
    let fullPropertyAddress = this.hoaDetailList.AssociationUnit;
    if (fullPropertyAddress.AssociationUnitAddress1 !== null) {
      propertyAddress = fullPropertyAddress.AssociationUnitAddress1 + ",";
    }
    if (fullPropertyAddress.AssociationUnitAddress2 !== null) {
      propertyAddress = propertyAddress + fullPropertyAddress.AssociationUnitAddress2;
    }
    if (fullPropertyAddress.AssociationUnitCity !== null) {
      propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitCity;
    }
    if (fullPropertyAddress.AssociationUnitState !== null) {
      propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitState + ",";
    }
    if (fullPropertyAddress.AssociationUnitCounty !== null) {
      propertyAddress = propertyAddress + fullPropertyAddress.AssociationUnitCounty;
    }
    if (fullPropertyAddress.AssociationUnitZip !== null) {
      propertyAddress = propertyAddress + " " + fullPropertyAddress.AssociationUnitZip;
    }
    return propertyAddress;
  }

  getFullMailingAddress(): string {
    let fullMailingAddress = this.hoaDetailList.Address;
    let mailAddress = "";
    if (fullMailingAddress.Address1 !== null) {
      mailAddress = fullMailingAddress.Address1 + ",";
    }
    if (fullMailingAddress.Address2 !== null) {
      mailAddress = mailAddress + fullMailingAddress.Address2;
    }
    if (fullMailingAddress.City !== null) {
      mailAddress = mailAddress + " " + fullMailingAddress.City;
    }
    if (fullMailingAddress.State !== null) {
      mailAddress = mailAddress + " " + fullMailingAddress.State + ",";
    }
    if (fullMailingAddress.County !== null) {
      mailAddress = mailAddress + fullMailingAddress.County;
    }
    if (fullMailingAddress.ZIP !== null) {
      mailAddress = mailAddress + " " + fullMailingAddress.ZIP;
    }
    return mailAddress;
  }


}
