import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoaDirectoryComponent } from './hoa-directory.component';

describe('HoaDirectoryComponent', () => {
  let component: HoaDirectoryComponent;
  let fixture: ComponentFixture<HoaDirectoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoaDirectoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoaDirectoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
