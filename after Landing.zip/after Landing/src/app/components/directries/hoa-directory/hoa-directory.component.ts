import { Component, OnInit } from '@angular/core';
import { HoaDirectoryApiService } from 'src/app/services/hoa-directory-api.service';
import { Router } from '@angular/router';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';

@Component({
  selector: 'app-hoa-directory',
  templateUrl: './hoa-directory.component.html',
  styleUrls: ['./hoa-directory.component.scss']
})
export class HoaDirectoryComponent implements OnInit {
  //For Static Data used associationId
  associationId: string;
  status = UnitRole.unitRoleAll;
  resData: any;
  hOADirectoryList: any;
  filterHOADirectoryList: any;
  totalUnit: number;
  totalUnitForOwner: number;
  totalUnitForRenter: number;
  userData: UserData;


  constructor(
    private _router: Router,
    private hoaDirectoryApiService: HoaDirectoryApiService,  private readonly appConfig: AppConfig) { 
      this.userData = appConfig.getCurrentUser();
      this.associationId = this.userData.UserAssociations[0].AssociationId;
    }

  ngOnInit() {
    this.getData();
  }

  statusChange(s) {
    let filterHOADirectoryList = this.filterHOADirectoryList;
    if (s === UnitRole.unitRoleOwner) {
      this.hOADirectoryList = filterHOADirectoryList.filter(x => x.UnitRole === UnitRole.unitRoleOwner);
    }
    if (s === UnitRole.unitRoleRenter) {
      this.hOADirectoryList = filterHOADirectoryList.filter(x => x.UnitRole === UnitRole.unitRoleRenter);
    }
    if (s === UnitRole.unitRoleAll) {
      this.hOADirectoryList = filterHOADirectoryList;
    }
    this.status = s;
  }

  getData() {
    this.hoaDirectoryApiService.getHoaDirectory(this.associationId).subscribe(res => {
      this.resData = res;
      if (this.resData.Errors.length !== 0)
        alert('Details not found');
      else {
        this.hOADirectoryList = this.resData.HOADirectory;
        debugger;
        this.filterHOADirectoryList = this.resData.HOADirectory;
        this.totalUnit = this.hOADirectoryList.length;
        let countOwner = 0, countRenter = 0;
        for (let i of this.hOADirectoryList) {
          if (i.UnitRole === UnitRole.unitRoleOwner) {
            countOwner++;
          }
          if (i.UnitRole === UnitRole.unitRoleRenter) {
            countRenter++;
          }
        }
        this.totalUnitForOwner = countOwner;
        this.totalUnitForRenter = countRenter;
      }

    },
      (err) => {
        console.log(err);
      }
    );
  }
  myProfileDetails(associationUnitId: string, userId: string) {
    if ((userId !== null && userId !== "" && userId !== undefined) && (associationUnitId !== null && associationUnitId !== "" && associationUnitId !== undefined)) {
      this.hoaDirectoryApiService.userId = userId;
      this.hoaDirectoryApiService.associationUnitId = associationUnitId;
      this._router.navigate(["/my-profile"]);
    }
    else {
      alert("User details not found...");
    }
  }
  myHoaDetails(associationUnitId: string, userId: string) {
    if ((userId !== null && userId !== "" && userId !== undefined) && (associationUnitId !== null && associationUnitId !== "" && associationUnitId !== undefined)) {
      this.hoaDirectoryApiService.userId = userId;
      this.hoaDirectoryApiService.associationUnitId = associationUnitId;
      this.hoaDirectoryApiService.associationId = this.associationId;
      this._router.navigate(["/hoa-detail"]);
    }
    else {
      alert("Hoa details not found...");
    }
  }
}
export const UnitRole = {
  unitRoleOwner: "Owner",
  unitRoleRenter: "Renter",
  unitRoleAll: "All"
};