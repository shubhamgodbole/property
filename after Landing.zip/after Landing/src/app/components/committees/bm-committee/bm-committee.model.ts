
export class AddCommittee {
    CustomCommitteeName: string
    Description: string
    CommitteeType: string
    AssociationId: string
    AssociationName: string
}

export class AddCommitteeMember {
    UserProfileId: string
    CommitteeMemberName: string
    StartDate: string
    EndDate: string
    AssociationCommitteeUserDesignation: string
}

export class CommitteeContactData {
    Messsage: string
    Subject: string
    AssociationName: string
    AssociationCommittee: string
}

export class EditCommittee {
    id: string
    CustomCommitteeName: string
    Description: string
    CommitteeType: string
    AssociationCommitteeUsers: any
}

