import { Component, OnInit } from '@angular/core';
import { CommitteeApiService } from 'src/app/services/committee-api.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AddCommittee, AddCommitteeMember, EditCommittee, CommitteeContactData } from './bm-committee.model';

@Component({
  selector: 'app-bm-committee',
  templateUrl: './bm-committee.component.html',
  styleUrls: ['./bm-committee.component.scss']
})
export class BmCommitteeComponent implements OnInit {
  addCommitteeForm: FormGroup;
  editCommitteeForm: FormGroup;
  addCommitteeMemberForm: FormGroup;
  sendMessageForm: FormGroup;
  editcommittee = false;
  addcommittee = false;
  addCommitteemember = false;
  editCommitteemember :any;
  messagecommittee = false;
  committeeData: any;
  committeeTypesData: any;
  designationData: any;
  memberData: any;
  showCommitteeName: boolean = false;
  fileData: any = [];
  oldImage:any;
  newImage:any;
  errorMsg: string;
  AssociationId = "3B36963A-CD68-E511-80BF-000D3A30426B";
  AssociationName = "Dummy Test Association";
  editData: any = {};
  editMembers:any = [];
  AssociationCommitteeId: string;
  AssociationCommittee: string;
  isEdit: boolean = false;
  editAssociationCommitteeUserId = "";
  newDesignation: string = "";
  newStartdate: string = "";
  newEnddate: string = "";
  minDate: any;
  isMemeberExistMsg ="";
  constructor(private committeeService: CommitteeApiService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.addCommitteeForm = this.formBuilder.group({
      committeeName: [''],
      committeeType: ['', Validators.required],
      description: ['', Validators.required],
      attechment: ['', Validators.required],
    });
    this.editCommitteeForm = this.formBuilder.group({
      committeeName: [''],
      committeeType: ['', Validators.required],
      description: ['', Validators.required],
      attechment: [''],
      designation: ['', Validators.required],
      startData: ['', Validators.required],
      endDate: ['', Validators.required],
    });
    this.addCommitteeMemberForm = this.formBuilder.group({
      memberName: ['', Validators.required],
      designation: ['', Validators.required],
      startData: ['', Validators.required],
      endDate: ['', Validators.required],
    });
    this.sendMessageForm = this.formBuilder.group({
      subject: ['' , Validators.required],
      message: ['', Validators.required],
    });
    this.getAllCommittee();
  }
  // get all committee
  getAllCommittee() {
    let resData;
    this.committeeService.getAllCommittee(this.AssociationId).subscribe(
      (response: any) => {
        resData = response;
        this.committeeData = resData.Committee.AssociationCommitteeList;
        this.committeeTypesData = resData.Committee.CommitteeTypes;
        this.designationData = resData.Committee.DesignationTypes;
      }
    );
  }

  // get all members
  getAllMember(AssociationCommitteeId) {

    this.committeeService.getAllMember(this.AssociationId, AssociationCommitteeId).subscribe(
      (response: any) => {

        this.memberData = response.Users;
      }
    );
  }

  editcommitteeToggle() {
    if (this.editcommittee) {
      this.resetEditComittee();
      this.editcommittee = false;
    }
    else
      this.editcommittee = true;
  }
  addcommitteeToggle() {
    if (this.addcommittee) {
      this.reset();
      this.addcommittee = false;
    }
    else
      this.addcommittee = true;
  }
  addcommitteeMemberToggle(id) {
    this.AssociationCommitteeId = id;
    this.getAllMember(id);
    if (this.addCommitteemember) {

      this.resetComitteeMamber();
        this.addCommitteemember = false;
    }
    else
      this.addCommitteemember = true;
  }

  messagecommitteeToggle(committeeName) {
    this.AssociationCommittee = committeeName;
    if (this.messagecommittee)
      this.messagecommittee = false;
    else
      this.messagecommittee = true;
  }
  onUploadChange(evt: any) {
    // this.imgFlag = false;
    this.fileData = [];
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.fileData.push({
          inputStream: event.target.result,
          name: evt.target.files[0].name,
          type: evt.target.files[0].type
        });
      }
      reader.readAsDataURL(evt.target.files[0]);
      this.newImage = this.fileData[0].inputStream;
      console.log('new file', this.newImage);
    }

  }
  // reset Add Committee Form
  reset() {
    this.addCommitteeForm.reset();
    this.addcommittee = false;
    this.fileData = [];
  }
  // reset Add Committee Member Form
  resetComitteeMamber() {
    this.addCommitteeMemberForm.reset();
    this.addCommitteemember = false;
  }
  // reset Edit Committee Form
  resetEditComittee() {
    this.editCommitteeForm.reset();
    this.editcommittee = false;
    this.isEdit = false;
  }
  resetSendMessageForm() {
    this.sendMessageForm.reset();
    this.messagecommittee = false;
  }
  // get Committee Type 
  // if Committee Type is Other then show TextBox for CommitteeName
  getCommitteeType(type) {
    this.errorMsg = "";
    this.showCommitteeName = false;
    this.addCommitteeForm.controls.committeeName.setValue('');
    if (type.value === 'Others') {
      this.showCommitteeName = true;
    }
  }
  // add Committee 
  addCommittee() {
    const addCommitteeData = this.createCommitteeModel();
    this.committeeService.addCommittee(addCommitteeData, this.fileData[0].inputStream).subscribe(
      (response: any) => {
        if (response.success) {
          this.getAllCommittee();
          this.reset();
        }
        else {
          this.errorMsg = "This Committee is already exist";
          console.log('Add Committee : ',this.errorMsg);
        }
      }
    );
  }
  // add Committee Model
  createCommitteeModel() {
    let model: AddCommittee = {
      CustomCommitteeName: this.addCommitteeForm.controls.committeeName.value,
      CommitteeType: this.addCommitteeForm.controls.committeeType.value,
      Description: this.addCommitteeForm.controls.description.value,
      AssociationId: this.AssociationId,
      AssociationName: this.AssociationName
    };
    return model;
  }
  
  changeMemberName() {
    this.isMemeberExistMsg = '';
  }
  // add Committee Member
  addCommitteeMember() {
    let memberData = this.createCommitteeMemberModel();
    this.committeeService.addCommitteeMember(memberData, this.AssociationCommitteeId).subscribe(
      (response: any) => {
        if(response.success) {
          this.resetComitteeMamber();
          this.getAllCommittee();
          console.log('Added new Committee Member');
        }
        else {
          this.isMemeberExistMsg = response.Errors[0].Message;
          console.log('Added new Committee Member : ', this.isMemeberExistMsg);
        }
      });
    console.log(memberData);
  }
  // add Committee Member Model
  createCommitteeMemberModel() {
    let model: AddCommitteeMember = {
      UserProfileId :this.addCommitteeMemberForm.controls.memberName.value.UserProfileId ,
      CommitteeMemberName: this.addCommitteeMemberForm.controls.memberName.value.UserName,
      StartDate: this.addCommitteeMemberForm.controls.startData.value,
      EndDate: this.addCommitteeMemberForm.controls.endDate.value,
      AssociationCommitteeUserDesignation: this.addCommitteeMemberForm.controls.designation.value,
    }
    return model;
  }
  // get Start date
  // set minDate for EndDate
  changeSDate() {
    this.minDate = this.addCommitteeMemberForm.controls.startData.value;
  }
  // get committeeData For Edit
  edit(editCommitteeData) {
    this.AssociationCommitteeId = editCommitteeData.id;
    this.editCommitteeForm.controls.description.setValue(editCommitteeData.Description);
    this.editCommitteeForm.controls.committeeName.setValue(editCommitteeData.CustomCommitteeName);
    this.editCommitteeForm.controls.committeeType.setValue(editCommitteeData.CommitteeType);
    this.oldImage = editCommitteeData.CommitteeImageBlobPath;
    this.editCommitteemember=editCommitteeData.AssociationCommitteeUsers;
    this.showCommitteeName = false;
    if (editCommitteeData.CommitteeType === 'Others') {
      this.showCommitteeName = true;
    }
  }
  // get MemberData for Edit
  editMember(editMemberData) {
    this.editAssociationCommitteeUserId = editMemberData.AssociationCommitteeUserId;
    this.isEdit = !this.isEdit;
    let id = editMemberData.AssociationCommitteeUserId;
    this.editCommitteeForm.controls.designation.setValue(editMemberData.AssociationCommitteeUserDesignation);
    this.editCommitteeForm.controls.startData.setValue(editMemberData.StartDate);
    this.editCommitteeForm.controls.endDate.setValue(editMemberData.EndDate);
    this.newStartdate = editMemberData.StartDate;
  }
  // change Designation for Edit
  changeDesignation(MemberData) {
    this.newDesignation = this.editCommitteeForm.controls.designation.value;
    this.createUpdateMemberModel(MemberData);
  }
  // Change Start Date for Edit
  changeStartdate(MemberData) {
    this.newStartdate = this.editCommitteeForm.controls.startData.value;
    this.createUpdateMemberModel(MemberData);
  }
  // change End Date for Edit
  changeEndDate(MemberData) {
    this.newEnddate = this.editCommitteeForm.controls.endDate.value;
    this.createUpdateMemberModel(MemberData);
  }
  // update Committee
  update() {
   let updateCommitteeData = this.createUpdateModel();
   let ImageStream = this.fileData.length > 0 ? this.newImage : '';
    this.committeeService.updateCommittee(updateCommitteeData, ImageStream).subscribe(
      (response: any) => {
        if(response.success) {
          console.log('Update Committee');
            this.getAllCommittee();
        }
        else {
          console.log('Error in Update Committee');
        }
        this.resetEditComittee();
      });
    
  }
  // update Memeber Model
  createUpdateMemberModel(editMemberData) {
    this.editMembers.push({
      AssociationCommitteeUserId : editMemberData.AssociationCommitteeUserId,
      AssociationCommitteeUserDesignation : this.newDesignation !== "" ? this.newDesignation : editMemberData.AssociationCommitteeUserDesignation,
      StartDate : this.newStartdate !== "" ? this.newStartdate : editMemberData.StartDate,
      EndDate : this.newEnddate !== "" ? this.newEnddate : editMemberData.EndDate,
      CommitteeMemberName:editMemberData.CommitteeMemberName,
      AssociationCommitteeCompositionId:editMemberData.AssociationCommitteeCompositionId,
      CommitteeMemberImagePath:editMemberData.CommitteeMemberImagePath
    });
    return this.editMembers;
  }
  // Update Committee Model
  createUpdateModel() {
    let model : EditCommittee = {
      id : this.AssociationCommitteeId,
      CustomCommitteeName: this.editCommitteeForm.controls.committeeName.value,
      CommitteeType: this.editCommitteeForm.controls.committeeType.value,
      Description: this.editCommitteeForm.controls.description.value,
      AssociationCommitteeUsers : this.editMembers
    }
    return model;
  }
  senMessageModel() {
    let model: CommitteeContactData = {
      Messsage :  this.sendMessageForm.controls.message.value,
      Subject : 'Problem',//this.sendMessageForm.controls.subject.value,
      AssociationName : this.AssociationName,
      AssociationCommittee : this.AssociationCommittee
    }
    return model;
  }
  senMessage() {
    let CommitteeContactData = this.senMessageModel();
    this.committeeService.sendMessage(CommitteeContactData).subscribe(
      (response: any) =>{
        if(response.success) {
          this.resetSendMessageForm();
          console.log('Send Message');
        }
      }
    );
  }
}
