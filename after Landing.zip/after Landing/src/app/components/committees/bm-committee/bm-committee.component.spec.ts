import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BmCommitteeComponent } from './bm-committee.component';

describe('BmCommitteeComponent', () => {
  let component: BmCommitteeComponent;
  let fixture: ComponentFixture<BmCommitteeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BmCommitteeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BmCommitteeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
