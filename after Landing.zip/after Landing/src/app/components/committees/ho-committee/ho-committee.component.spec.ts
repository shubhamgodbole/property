import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HoCommitteeComponent } from './ho-committee.component';

describe('HoCommitteeComponent', () => {
  let component: HoCommitteeComponent;
  let fixture: ComponentFixture<HoCommitteeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HoCommitteeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HoCommitteeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
