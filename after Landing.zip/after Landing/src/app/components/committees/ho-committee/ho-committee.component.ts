import { Component, OnInit } from '@angular/core';
import { CommitteeApiService } from 'src/app/services/committee-api.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-ho-committee',
  templateUrl: './ho-committee.component.html',
  styleUrls: ['./ho-committee.component.scss']
})
export class HoCommitteeComponent implements OnInit {
  
  messagecommittee = false;
  committeeData: any;
  userJoinRequestForm: FormGroup;
  listData:any;
  AssociationId = "3B36963A-CD68-E511-80BF-000D3A30426B";

  constructor(private committeeService: CommitteeApiService,  private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.userJoinRequestForm = this.formBuilder.group({
      message: ['', Validators.required],

    });
    this.getAllCommittee();
  }
  getAllCommittee() {
    this.committeeService.getAllCommittee(this.AssociationId).subscribe(
      (response: any) => {
        this.committeeData = response.Committee.AssociationCommitteeList;
      }
    );
  }
  messagecommitteeToggle(list)
  {
    this.listData = list;
    if(this.messagecommittee)
     this.messagecommittee = false;
    else 
    this.messagecommittee = true;
  }
  reset() {
    this.userJoinRequestForm.reset();
    this.messagecommittee = false;
  }
  senRequest() {
    let AssociationCommitteeJoinRequest = this.associationCommitteeJoinRequestModel();
    this.committeeService.sendUserJoinRequest(AssociationCommitteeJoinRequest,this.listData.id).subscribe(
      (response: any) => {
        if(response.success) {
            console.log('Send Request Successfully');
            this.reset();
        }
        else {
          console.log('Error In SendRequest');
        }
      }
    );
  }
  associationCommitteeJoinRequestModel() {
    let model = {
      CreatedByUserId : this.listData.CreatedByUserId,
      CreatedByUserName : this.listData.CreatedByUserName,
      Message: this.userJoinRequestForm.controls.message.value,
    }
    return model;
  }
}
