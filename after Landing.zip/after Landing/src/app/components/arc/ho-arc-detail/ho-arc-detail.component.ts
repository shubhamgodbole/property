import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ho-arc-detail',
  templateUrl: './ho-arc-detail.component.html',
  styleUrls: ['./ho-arc-detail.component.scss']
})
export class HoArcDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
