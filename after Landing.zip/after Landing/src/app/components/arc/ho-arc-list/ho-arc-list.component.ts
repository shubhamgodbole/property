import { Component, OnInit, ViewChild } from '@angular/core';
import { UserData } from 'src/app/shared/models/user-data-model';
import { ARCStatus } from '../arc-model';
import { ArcRequestApiService } from 'src/app/services/arc-request-api.service';
import { AppConfig } from 'src/app/app.config';
import { fromEvent } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ho-arc-list',
  templateUrl: './ho-arc-list.component.html',
  styleUrls: ['./ho-arc-list.component.scss']
})
export class HoArcListComponent implements OnInit {
  filter = false;
  userData: UserData;
  associationId: string;
  arcList: any;
  arcStatusCount: any;
  count: number;
  arcRequestStatus = ARCStatus;
  status: string = ARCStatus.All;
  role: string;
  userId: string;
  sidebar = false;
  //For filter by key word
  filterByKeyWords: string = "";
  @ViewChild('searchData') searchData: any;

  constructor(private service: ArcRequestApiService, private readonly appConfig: AppConfig, 
    private router: Router) {
    this.userData = this.appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.role = "Member";
    this.userId = this.userData.UserProfileId;
  }

  ngOnInit() {
    //Filter By Key word
    fromEvent(this.searchData.nativeElement, 'keyup')
      .pipe(
        map((k: any) => k.target.value),
        debounceTime(1500),
      ).subscribe(val => {
        this.filterByKeyWords = val;
        this.getData();
      });
    this.getData();
  }


  addClass() {
    if (this.filter)
      this.filter = false;
    else
      this.filter = true;
  }

  getData() {
    let resData;
    let resFilterByKeyWords = this.filterByKeyWords;
    let resStatus = this.status === "All" ? "" : this.status;
    this.service.getFilteredARCRequestForHo(this.associationId, this.userId, this.role, resStatus, resFilterByKeyWords).subscribe(res => {
      resData = res;
      console.log(resData);
      this.arcList = resData.caseRequestListResults[0].arcRequestList;
      this.arcStatusCount = resData.caseRequestListResults[0].ARCStatusCount;
      this.count = resData.caseRequestListResults[0].ResultCount;
    },
      (err) => {
        console.log(err);
      }
    )
  }

  clearFilter() {
    this.filterByKeyWords = "";
  }

  arcDetail(id) {
    this.service.arcRequestId = id;
    this.router.navigate(['/ho-arc-detail']);
  }


  statusChange(s) {
    this.status = s;
    this.getData();
  }

}
