import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BmArcDetailComponent } from './bm-arc-detail.component';

describe('BmArcDetailComponent', () => {
  let component: BmArcDetailComponent;
  let fixture: ComponentFixture<BmArcDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BmArcDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BmArcDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
