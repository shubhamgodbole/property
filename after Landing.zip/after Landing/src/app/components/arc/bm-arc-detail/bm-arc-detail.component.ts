import { Component, OnInit } from '@angular/core';
import { ArcRequestApiService } from 'src/app/services/arc-request-api.service';
import { getMatIconFailedToSanitizeLiteralError } from '@angular/material';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { Router } from '@angular/router';
import { NoteType } from '../arc-model';

@Component({
  selector: 'app-bm-arc-detail',
  templateUrl: './bm-arc-detail.component.html',
  styleUrls: ['./bm-arc-detail.component.scss']
})
export class BmArcDetailComponent implements OnInit {

  userData: UserData;
  userId: string;
  domain: string;
  arcRequest: any;
  arcRequestDocument: any;
  committeeMemberCaseNotes: any;
  caseNotes: any;
  hocaseNotes: any;
  noteType = NoteType;
  displayDiv: boolean = false;

  constructor(private service: ArcRequestApiService,  private readonly appConfig: AppConfig,
     private router: Router) {
    this.userData = this.appConfig.getCurrentUser();
    this.domain = this.userData.UserAssociations[0].Domain;
   }

  ngOnInit() {
    if(this.service.arcRequestId)
      this.getDetail();
    else{
      this.router.navigate(['/ARCRequestsBoard']);
    }
  }

  getDetail()
  {
    let resData;
    this.service.getARCRequestDetail(this.service.arcRequestId, this.domain).subscribe(response => {
      resData = response;
      this.arcRequest = resData.RequestDetail.ARCRequest;
      this.arcRequestDocument = resData.RequestDetail.Document;
      this.caseNotes =  resData.RequestDetail.CaseNotes;
      this.committeeMemberCaseNotes = this.caseNotes.filter(note => note.NotesType == this.noteType.CommitteeMember);
      this.hocaseNotes = this.caseNotes.filter(note => note.NotesType == this.noteType.Homeowner);
      this.displayDiv = true;
    });
  }



}
