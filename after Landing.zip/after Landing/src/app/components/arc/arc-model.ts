export enum ARCStatus {
    All = "All",
    Submitted = "Submitted",
    Approved = "Approved",
    Denied = "Denied",
    WorkCompleted = "WorkCompleted",
    Cancelled = "Cancelled"
}

export class DisplayPriority {
    public static PriorityList = [
        { value: "High", text: "High" },
        { value: "Medium", text: "Medium" },
        { value: "Low", text: "Low" }
    ]
}

export enum NoteType {
    BoardMember = "BoardMember",
    CommitteeMember = "CommitteeMember",
    Homeowner = "Homeowner",
    General = "General"
}

