import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cm-arc-detail',
  templateUrl: './cm-arc-detail.component.html',
  styleUrls: ['./cm-arc-detail.component.scss']
})
export class CmArcDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
