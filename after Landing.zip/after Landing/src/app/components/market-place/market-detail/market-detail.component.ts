import { Component, OnInit } from '@angular/core';
import { MarketPlaceApiService } from 'src/app/services/market-place-api.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Enquiry } from './market-detail.model';
import { UserData } from 'src/app/shared/models/user-data-model';
import { AppConfig } from 'src/app/app.config';

@Component({
  selector: 'app-market-detail',
  templateUrl: './market-detail.component.html',
  styleUrls: ['./market-detail.component.scss']
})
export class MarketDetailComponent implements OnInit {
  addEnquiryForm: FormGroup;
  sidebar = false;
  userData: UserData;
  associationId:string;
  userId: string;
  associationName: string;
  userName: string;
  domain: string;
  myadds: any;
  classifiedAd: any;
  classifiedAdDocumentList: any;
  relatedPostList: any;
  classifiedAdUserResponse: any;
  categories: any;
  selectedCategory: string;
  displayDiv: boolean = false;

  constructor(public service: MarketPlaceApiService, private router: Router,
    private formBuilder: FormBuilder, private readonly appConfig: AppConfig) { 
    this.userData = this.appConfig.getCurrentUser();
    this.userData = appConfig.getCurrentUser();
    this.associationId = this.userData.UserAssociations[0].AssociationId;
    this.associationName = this.userData.UserAssociations[0].Name;
    this.userId = this.userData.UserProfileId;
    this.userName = this.userData.UserName;
    this.domain =  this.userData.UserAssociations[0].Domain;
    this.getDetail();
  }

  getDetail() {
    let resData;
    if(this.service.classifiedAdId){
      this.service.classifiedAdDetail(this.domain).subscribe(response =>{
        resData = response;
        if(resData.Success){
          this.displayDiv = true;
          console.log('deatil ',resData);
          this.classifiedAd = resData.ClassifiedAdDetail.ClassifiedAd;
          this.classifiedAdDocumentList = resData.ClassifiedAdDetail.Documents;
          this.relatedPostList = resData.ClassifiedAdDetail.GetPostAds[0].ClassifiedAdList;
          this.classifiedAdUserResponse = resData.ClassifiedAdDetail.ClassifiedAd.ClassifiedAdUserResponses;
          console.log('category ', this.classifiedAd);
          console.log('all cate ',this.categories);
          this.selectedCategory = this.categories.find(a=>a.ClassifiedAdCategoryName ==   this.classifiedAd.ClassifiedAdCategory);
        }
      });
    } else {
      this.router.navigate(['/ClassifiedAds']);
    }
  }

  ngOnInit() {
    this.createFrom();
    this.getAllCategories();
    //this.showEnquiry();
  }

  createFrom() {
    this.addEnquiryForm = this.formBuilder.group({
      name: ['', Validators.required],
      email: new FormControl('', [Validators.required, Validators.email]),
      phone: ['', Validators.required],
      price: ['', Validators.required],
      message: ['', Validators.required],
    });
  }

  sidebarToggle() {
    if (this.sidebar) {
      this.sidebar = false;
    }
    else {
      this.sidebar = true;
    }
  }

  // fetch all categories
  getAllCategories() {
    this.service.getAllCategories().subscribe((response: any) => {
      this.categories = response.ClassifiedAdCategory;
    });
  }

  // filter adds
  filterData(event) {
    let resData;
    console.log('selected Value ',this.selectedCategory);
    this.service.getClassifiedAdListByCategory(event.value.ClassifiedAdCategoryName).subscribe(response => {
      resData = response;
      this.relatedPostList = resData.Result[0].ClassifiedAdList
    });
  }

  // detail
  detail(id) {
   this.service.classifiedAdId = id;
   this.getDetail();
  }

  // delete
  delete(id) {
    if(confirm("Are you sure to delete ?")) {
      this.service.deleteClassifiedAdds(id).subscribe(
        (response: any) => {
          if (response.Success === true) {
            console.log('deleted');
            this.router.navigate(['/ClassifiedAds']);
          }
          else {
            console.log('Some Error');
          }
        }
      );
    } 
  }

  addEnquiry() {
    const enquiryData = this.createEnqiryModel();
    const Id = this.service.classifiedAdId;
    this.service.addClassifiedEnquiry(enquiryData, Id).subscribe(
      (response: any) =>{
        if(response.Success){
          this.getDetail();
          this.reset();
        }
      }
    );
  }

   // reset data
   reset(){
    this.addEnquiryForm.reset();
    this.sidebar = false;
  }

  // Enquiry model
  createEnqiryModel() : Enquiry {
    let model: Enquiry = {
      UserName: this.addEnquiryForm.controls.name.value,
      Email: this.addEnquiryForm.controls.email.value,
      Phone: this.addEnquiryForm.controls.phone.value,
      Price: this.addEnquiryForm.controls.price.value,
      Message: this.addEnquiryForm.controls.message.value
    }
    return model;
  }
}
