import { Component, OnInit } from '@angular/core';
import { LoginApiService } from 'src/app/services/login-api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-password',
  templateUrl: './update-password.component.html',
  styleUrls: ['./update-password.component.scss']
})
export class UpdatePasswordComponent implements OnInit {

  password:any;
  resData:any;
  constructor(private service: LoginApiService, private router: Router) { }

  ngOnInit() {
  }

  updatePassword() {
      this.service.updatePassword(this.password).subscribe(response => {
        this.resData = response;
        if(this.resData.Success)
          this.router.navigate(['/login']);
      }, error => {

      })
  }

}
