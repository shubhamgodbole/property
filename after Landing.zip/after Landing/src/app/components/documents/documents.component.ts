import { Component, OnInit, ViewChild } from '@angular/core';
import { DocumentsApiService } from 'src/app/services/documents-api.service';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { DocumentModel } from './documents.model';
import { AppConfig } from 'src/app/app.config';
import { UserData } from 'src/app/shared/models/user-data-model';
import { TypeOfDocument } from 'src/app/shared/Enums/typeOfDocuments';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit {
  /* Static Data for test*/
  associationId: string;
  canRead = "true";
  userId: string;
  domain: string;
  userName: string;
  isEditMode: boolean = false;
  frmCreateDocument: FormGroup;
  isTableList: boolean = true;
  adddocument = false;
  documentsList: any;
  documentCategoryDdl: any;
  userData: UserData;
  resData: any;
  resDataCreate: any;
  fileFullName: any;
  url: string = "";
  fileName: string;
  pdfvalidation: boolean = false;
  //For Filter data
  selectedDocumentCategory: string = "All";
  filterDocumentList: any;
  isSubmitBtnDisabled: boolean = false;
  pdfShow: boolean = false;
 // base64textString = [];
  inputStreamString= "";
  @ViewChild('formDirective') formDirective: FormGroupDirective;
  constructor(private readonly formBuilder: FormBuilder,
    private documentsApiService: DocumentsApiService, 
    private readonly appConfig: AppConfig) {
      this.userData = this.appConfig.getCurrentUser();
      this.associationId = this.userData.UserAssociations[0].AssociationId;
      this.userId = this.userData.UserProfileId;
      this.userName = this.userData.UserName;
      this.domain =  this.userData.UserAssociations[0].Domain;
      this.createForm();
     }

  ngOnInit() {
    this.getDocumentCategoryDdl();
    
  }
  displayList(d) {
    if (d === "tableView") {
      this.isTableList = true;
    } else {
      this.isTableList = false;
    }
  }



  onUploadChange(evt: any) {
    const file = evt.target.files[0];
    if (file !== undefined) {
      this.fileFullName = file;
      this.fileName = this.fileFullName.name;
      const reader = new FileReader();
      reader.onload = this.handleReaderLoaded.bind(this);
      reader.readAsBinaryString(file);
    }
    else{
      this.fileName = "";
      this.url = "";
      this.pdfvalidation = true;
    }
  }

  handleReaderLoaded(e) {
   // this.base64textString = [];
   // this.base64textString.push('data:image/png;base64,' + btoa(e.target.result));
    this.inputStreamString = 'data:image/png;base64,' + btoa(e.target.result);
    if (this.fileFullName.name.substring(this.fileFullName.name.indexOf(".")) === ".pdf") {
      this.url = "../../../../assets/images/preview-images/pdf-preview.png";
      this.pdfvalidation = false;
    }
    else {
      this.url = "";
      this.fileName = "";
      this.pdfvalidation = true;
    }
  }

  onSubmit(formDirective: FormGroupDirective) {
    if (this.pdfvalidation === true || this.fileFullName === undefined || this.fileFullName === null) {
      this.pdfvalidation = true;
      return
    }
    this.isSubmitBtnDisabled = true;
    if (this.frmCreateDocument.valid) {
      let model = this.createFormModel();
      if (this.isEditMode) {
        this.editData(model,formDirective);
      } else {
        this.saveData(model,formDirective);
      }
    }
  }

  editData(model: any,formDirective: FormGroupDirective) {
    this.documentsApiService.editDocument(model).subscribe(res => {
      this.resDataCreate = res;
      this.isSubmitBtnDisabled = false;
      if (this.resDataCreate.Success === true) {
        alert("Document updated successfully.");
        this.getData();
        this.adddocument = false;
        this.resetForm();
      }
      else if (this.resDataCreate.Success === false) {
        alert("Not Save");
      }
    });
  }

  saveData(model: any,formDirective: FormGroupDirective) {
    this.documentsApiService.createDocument(model).subscribe(res => {
      this.resDataCreate = res;
      this.isSubmitBtnDisabled = false;
      if (this.resDataCreate.Success === true) {
        alert("Document saved successfully.");
        this.getData();
        this.adddocument = false;
        this.resetForm();
      }
      else if (this.resDataCreate.Success === false) {
        alert("Not Updated");
      }
    });
  }
  createFormModel() {
    let isPublished;
    let currentDate = new Date();
    const publishDate = new Date(this.frmCreateDocument.controls.publishDate.value);
    if (publishDate.toLocaleDateString() <= currentDate.toLocaleDateString()) {
      isPublished = true;
    } else {
      isPublished = false;
    }
    let inputStream = "";
    let name ="";
    let mediaType = "";
    if (this.inputStreamString !== "") {
      inputStream =this.inputStreamString;//this.base64textString[0];
      name=this.fileFullName.name;
      mediaType =this.fileFullName.name.substring(this.fileFullName.name.indexOf("."));
    }
    const model: DocumentModel = {
      Domain: this.domain,
      AssociationId: this.associationId,
      TypeOfDocument: TypeOfDocument.AssociationDocuments,
      RequestDocuments:
        [{
          documentId: this.frmCreateDocument.controls.documentId.value,
          documentTitle: this.frmCreateDocument.controls.documentTitle.value,
          documentCategoryId: this.frmCreateDocument.controls.documentCategoryId.value.DocumentCategoryId,
          associationDocumentCategoryId: this.frmCreateDocument.controls.documentCategoryId.value.id,
          publishDate: publishDate.toISOString(),
          isPublished: isPublished,
          documentCategoryName: this.frmCreateDocument.controls.documentCategoryId.value.DocumentCategory,
          inputStream:inputStream,
          name: name,
          mediaType: mediaType,
          CreatedByUserId: this.userId,
          CreatedByUserName: this.userName
        }]
    }
    return model;
  }

 
  createForm() {
    this.frmCreateDocument = this.formBuilder.group({
      documentId: [''],
      documentTitle: ['', Validators.required],
      documentCategoryId: ['', Validators.required],
      publishDate: ['', Validators.required]
    });
  }

  getData() {
    this.documentsApiService.getDocument(this.associationId, this.domain, TypeOfDocument.AssociationDocuments).subscribe(res => {
      this.resData = res;
      this.documentsList = this.resData.DocumentDetails.Documents;
      this.filterDocumentList = this.resData.DocumentDetails.Documents;
    },
      (err) => {
        console.log(err);
      }
    )
  }

  filterGetData() {
    let filterDocument = this.filterDocumentList;
    if (this.selectedDocumentCategory === "All") {
      this.documentsList = filterDocument;
    } else {
      this.documentsList = filterDocument.filter(x => x.DocumentCategoryName === this.selectedDocumentCategory);
    }
  }


  deleteDoucment(documentId) {
    this.documentsApiService.deleteDocument(documentId).subscribe(res => {
      this.resData = res;
      if (this.resData.Success === true) {
        this.getData();
        alert(this.resData.Message);
      }

    },
      (err) => {
        console.log(err);
      })
  }
  getDocumentCategoryDdl() {
    this.documentsApiService.getDocumentCategoryDdl(this.associationId, this.canRead, this.userId).subscribe(res => {
      this.resData = res;
      this.documentCategoryDdl = this.resData.DocumentDetails.DocumentCategories;
      this.getData();
    },
      (err) => {
        console.log(err);
      }
    )
  }

  editRow(document: any) {
    this.isEditMode = true;
    this.adddocument = true;
    
    if (document.DocumentPath !== "" && document.DocumentPath !== null) {
      this.url = "../../../../assets/images/preview-images/pdf-preview.png";
      this.fileName = document.DocumentName;
      this.pdfvalidation = false;
      this.fileFullName = document.FilePath;
    }
    this.frmCreateDocument.controls.documentId.setValue(document.id);
    this.frmCreateDocument.controls.documentTitle.setValue(document.DocumentTitle);
    this.frmCreateDocument.controls.publishDate.setValue(document.PublishDate);
    let selectedDocumentCategory = this.documentCategoryDdl.find(x => x.id === document.DocumentCategoryId)
    this.frmCreateDocument.controls.documentCategoryId.setValue(selectedDocumentCategory);
  }
  // test() {
  //   this.pdfShow = true;
  // }
  
  adddocumentToggle() {
    
    if (this.adddocument)
      this.adddocument = false;
    else
      this.adddocument = true;
    this.resetForm();
  }

 
  resetForm() {
    this.url = "";
    this.pdfvalidation = false;
    this.frmCreateDocument.reset();
    this.formDirective.resetForm();
    this.fileFullName = "";
    this.fileName = "";
    this.isEditMode = false;
    this.isSubmitBtnDisabled = false;
    //this.base64textString = [];
    this.inputStreamString = "";
  }

}
