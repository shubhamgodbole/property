export enum BoardTaskStatus {
    All = "All",
    New = "New",
    InProgress = "InProgress",
    AwaitingBoardDecision = "AwaitingBoardDecision",
    Completed = "Completed",
    Canceled = "Canceled"
}

export enum NoteType {
    BoardMember = "BoardMember",
    CommitteeMember = "CommitteeMember",
    Homeowner = "Homeowner",
    General = "General"
}

export enum CaseFeatureType {
    ServiceRequest = "ServiceRequest",
    BoardTask = "BoardTask",
    Violation = "Violation",
    ARCRequest = "ARCRequest",
    Motion = "Motion"
}

export class DisplayPriority {
    public static PriorityList = [
        { value: "High", text: "High" },
        { value: "Medium", text: "Medium" },
        { value: "Low", text: "Low" }
    ]
}

export class CaseSubCategory {
    caseCategoryName: string;
    caseSubCategoryNames: CaseSubCategoryName[];
}
export class CaseSubCategoryName {
    caseSubCategory: string;
}
export class BoardTaskModel {
    Domain: string;
    TypeOfDocument: string;
    Document: any[];
    Case: RequestBoardTaskModel;
}
export class RequestBoardTaskModel {
    CaseId: string;
    Title: string;
    AssociationId: string;
    AssociationName: string;
    CaseType: string;
    SubCaseType: string;
    CaseCategory: string;
    CaseSubCategory: string;
    Comments: string;
    CustomerType: string;
    DueDate: string;
    CasePriority: string;
    LastName: string;
    FirstName: String;
}

export class CaseNoteModel {
    AssociationId: string;
    Domain: string;
    TypeOfDocument: string;
    Document: any[];
    CaseNotes: RequestCaseNoteModel;
}
export class RequestCaseNoteModel {
    CaseNoteId: string;
    Note: string;
    CreatedByUserId: string;
    CaseId: string;
    NotesType: string;
    CreatedByUserName: string;
    CaseFeatureType: string;
}
export class UpdateBoardTaskStatus {
    RequestId: string;
    StatusType: string;
    //CaseId: string;
    CaseNotes: RequestCaseNoteModel;
}
// export class CaseStatusReasonModel {
//     StatusReason: string;
//     Reason: string;
//     CreatedByUserId: string;
//     CreatedByUserName: string;
// }


export class MotionModel {
    MotionId: string;
    CaseId: string;
    AssociationId: string;
    AssociationName: string;
    CreatedByUserId: string;
    CreatedByUserName: string;
    Description: string;
    CaseFeatureType: string;
}


// export class MotionVoteModel
// {
//     CaseId:string;
//     RequestId:string;
//     AssociationId:string;
//     Votes:VotesModel;
// }
export class VotesModel{
    Vote:boolean;
    CreatedByUserId:string;
    CreatedByUserName:string;
}