import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { BoardTaskApiService } from 'src/app/services/board-task-api.service';
import { BoardTaskStatus, DisplayPriority, CaseSubCategory, BoardTaskModel } from '../board-task.model';
import { fromEvent } from 'rxjs';
import { map, debounceTime } from 'rxjs/operators';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-board-task-list',
  templateUrl: './board-task-list.component.html',
  styleUrls: ['./board-task-list.component.scss']
})
export class BoardTaskListComponent implements OnInit {
  // Static Data
  associationId = "3B36963A-CD68-E511-80BF-000D3A30426B";
  role = "BoardMember";
  customerType = "Association";
  caseType = "Board Members";
  subCaseType = "BoardTask";
  domain = "testassociation";
  typeOfDocument = "CaseDocuments";
  associationName = "Test Association";
  firstName = "Darshana";
  lastName = "Gupta";
  //For filter by key word
  filterByKeyWords: string = "";
  @ViewChild('searchData') searchData: any;


  resData: any;
  boardTaskList: any;
  statusTypeCount: any;

  filterBoardTaskList: any;
  caseCategoryDdl: any;
  selectedCaseCategory: string = "All";
  priorityDdl: any;
  selectedPriority: string = "All";
  boardTaskStatusEnum = BoardTaskStatus;
  status = "All";

  /*For add Edit Form */
  caseSubCategoryDdlList = new Array<CaseSubCategory>();
  frmCreateBoardTask: FormGroup;
  caseSubCategoryDdl: any;
  isSubmitBtnDisabled: boolean = false;
  isEditMode: boolean = false;
  fileData = [];
  resDataCreate: any;
  @ViewChild('formDirective') formDirective: FormGroupDirective;
  statusChange(s) {
    this.status = s;
    this.getData();
  }

  filter = false;
  filterToggle() {
    if (this.filter)
      this.filter = false;
    else
      this.filter = true;
  }

  sidebar = false;
  sidebarToggle() {
    if (this.sidebar)
      this.sidebar = false;
    else
      this.sidebar = true;
    this.resetBoardTaskForm();
  }

  @Output() searchChangeEmitter = new EventEmitter();
  constructor(private boardTaskApiService: BoardTaskApiService,
    private readonly formBuilder: FormBuilder,
    private _router: Router) {
    this.createBoardTaskForm();
    this.getCaseCategoryDdl();
    this.priorityDdl = DisplayPriority.PriorityList;

  }

  ngOnInit() {
    //Filter By Key word
    fromEvent(this.searchData.nativeElement, 'keyup')
      .pipe(
        map((k: any) => k.target.value),
        debounceTime(1500),
      ).subscribe(val => {
        this.filterByKeyWords = val;
        this.getData();
      });
    this.getData();
  }


  getData() {
    let resFilterByKeyWords = this.filterByKeyWords;
    let resStatus = this.status === "All" ? "" : this.status;
    let resCaseCategory = this.selectedCaseCategory === "All" ? "" : this.selectedCaseCategory;
    let resPriority = this.selectedPriority === "All" ? "" : this.selectedPriority;
    this.boardTaskApiService.getFilteredBoardTask(this.associationId, this.role, resStatus, resPriority, resCaseCategory, resFilterByKeyWords).subscribe(res => {
      this.resData = res;
      this.boardTaskList = this.resData.caseRequestListResults[0].boardTaskRequestList;
      this.statusTypeCount = this.resData.caseRequestListResults[0].StatusTypeCount;
    },
      (err) => {
        console.log(err);
      }
    )
  }

  getCaseCategoryDdl() {
    this.boardTaskApiService.getCaseCategoryDdl(this.customerType, this.caseType).subscribe(res => {
      this.resData = res;
      this.caseCategoryDdl = this.resData.CaseType.CaseCategory;
      if (this.caseCategoryDdl.length > 0) {
        for (let i = 0; i < this.caseCategoryDdl.length; i++) {
          let model: CaseSubCategory = new CaseSubCategory();
          model.caseCategoryName = this.caseCategoryDdl[i].Name;
          model.caseSubCategoryNames = this.caseCategoryDdl[i].CaseSubCategories;
          this.caseSubCategoryDdlList.push(model);
        }
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }

  onChangeCaseCategory(event) {
    let caseSubcat = this.caseSubCategoryDdlList.find(x => x.caseCategoryName === event.value);
    this.caseSubCategoryDdl = caseSubcat.caseSubCategoryNames;
  }


  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.fileData.push({
            inputStream: event.target.result,
            name: evt.target.files[i].name,
            type: evt.target.files[i].type,
            mediaType: evt.target.files[i].name.substring(evt.target.files[i].name.indexOf("."))
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
    console.log(this.fileData);
  }

  removeImage(name) {
    this.fileData = this.fileData.filter(a => a.name !== name);
  }

  clearFilter() {
    this.selectedCaseCategory = "All";
    this.filterByKeyWords = "";
    this.selectedPriority = "All";
    this.filterByKeyWords = "";
    this.getData();
  }

  createBoardTaskForm() {
    this.frmCreateBoardTask = this.formBuilder.group({
      caseId: [''],
      title: ['', Validators.required],
      caseCategory: ['', Validators.required],
      caseSubCategory: ['', Validators.required],
      dueDate: ['', Validators.required],
      priority: ['', Validators.required],
      comment: ['', Validators.required]
    });
  }
  createBoardTaskFormModel() {

    const model: BoardTaskModel = {
      Domain: this.domain,
      TypeOfDocument: this.typeOfDocument,
      Document: this.fileData,
      Case:
      {
        CaseId: this.frmCreateBoardTask.controls.caseId.value,
        AssociationId: this.associationId,
        Title: this.frmCreateBoardTask.controls.title.value,
        AssociationName: this.associationName,
        CaseType: this.caseType,
        SubCaseType: this.subCaseType,
        CaseCategory: this.frmCreateBoardTask.controls.caseCategory.value,
        CaseSubCategory: this.frmCreateBoardTask.controls.caseSubCategory.value,
        Comments: this.frmCreateBoardTask.controls.comment.value,
        CustomerType: this.customerType,
        CasePriority: this.frmCreateBoardTask.controls.priority.value,
        DueDate: this.frmCreateBoardTask.controls.dueDate.value.toISOString(),
        FirstName: this.firstName,
        LastName: this.lastName
      }
    }
    return model;

  }
  onSubmit() {
    if (this.frmCreateBoardTask.valid) {
      this.isSubmitBtnDisabled = true;
      let model = this.createBoardTaskFormModel();
      this.boardTaskApiService.createBoardTask(model).subscribe(res => {
        this.isSubmitBtnDisabled = false;
        this.resDataCreate = res;
        if (this.resDataCreate.caseRequestListResults[0].Success === true) {
          alert("Board Task save successfully");
          this.getData();
          this.sidebar = false;
          this.resetBoardTaskForm();
        }
        else if (this.resDataCreate.caseRequestListResults[0].Success === false) {
          alert("Not Save");
        }
      });
    }
  }
  resetBoardTaskForm() {
    this.frmCreateBoardTask.reset();
    this.formDirective.resetForm();
    this.isEditMode = false;
    this.isSubmitBtnDisabled = false;
    this.fileData = [];
  }

  getBoardTaskDetails(detailId, caseId, boardCastStatus) {
    debugger;
    if (detailId !== "" && detailId !== null && boardCastStatus !== null) {
      this.boardTaskApiService.boardTaskDetailId = detailId;
      this.boardTaskApiService.caseId = caseId;
      this.boardTaskApiService.domain = this.domain;
      this.boardTaskApiService.boardTaskStatus = boardCastStatus;
      this._router.navigate(["/board-task-detail"]);
    }
  }

   /*:Check Current Date*/
   getToday(): string {
    return new Date().toISOString().split('T')[0]
  }
}
