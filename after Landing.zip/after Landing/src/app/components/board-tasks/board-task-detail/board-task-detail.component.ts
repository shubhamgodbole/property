import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { BoardTaskApiService } from 'src/app/services/board-task-api.service';
import { FormGroup, FormBuilder, Validators, FormGroupDirective } from '@angular/forms';
import { CaseNoteModel, NoteType, CaseFeatureType, UpdateBoardTaskStatus, BoardTaskStatus, MotionModel, VotesModel } from '../board-task.model';

@Component({
  selector: 'app-board-task-detail',
  templateUrl: './board-task-detail.component.html',
  styleUrls: ['./board-task-detail.component.scss']
})
export class BoardTaskDetailComponent implements OnInit {
  typeOfDocument = "CaseDocuments";
  associationName = "Test Association";
  associationId = "3B36963A-CD68-E511-80BF-000D3A30426B";
  createdByUserName = "Darshana";
  createdByUserId = "E08E3746-C9CD-E711-80D4-00155D000C26";
  boardTaskStatus: string = "";

  isApiResponseCome: boolean = false;

  boardTaskStatusEnum = BoardTaskStatus;
  /*Case Note Form*/
  frmCreateCaseNote: FormGroup;
  fileData = [];
  isSubmitBtnDisabled: boolean = false;
  resDataCreate: any;
  @ViewChild('formDirective') formDirective: FormGroupDirective;

  /*Board Cast Status Form*/
  frmCreateBoardTaskStatus: FormGroup;
  isSubmitBtnDisabledBoardTaskStatus: boolean = false;
  resDataCreateBoardTaskStatus: any;
  @ViewChild('formDirectiveBoardTaskStatus') formDirectiveBoardTaskStatus: FormGroupDirective;

  /*Motion Form*/
  frmCreateMotion: FormGroup;
  isSubmitBtnDisabledMotion: boolean = false;
  resDataCreateMotion: any;
  @ViewChild('formDirectiveMotion') formDirectiveMotion: FormGroupDirective;

  /*Reopen Form*/
  frmCreateReopen: FormGroup;
  isSubmitBtnDisabledReopen: boolean = false;
  resDataCreateReopen: any;
  @ViewChild('formDirectiveReopen') formDirectiveReopen: FormGroupDirective;

  /*Completed Form*/
  frmCreateComplete: FormGroup;
  isSubmitBtnDisabledComplete: boolean = false;
  resDataCreateComplete: any;
  @ViewChild('formDirectiveComplete') formDirectiveComplete: FormGroupDirective;

  /*ReviewAndRating Form*/
  frmCreateReviewAndRating: FormGroup;
  isSubmitBtnDisabledReviewAndRating: boolean = false;
  resDataCreateReviewAndRating: any;
  @ViewChild('formDirectiveReviewAndRating') formDirectiveReviewAndRating: FormGroupDirective;
  countRating: number = 0;
  resData: any;
  boardTaskDetailList: any;
  documentList: any;
  caseNoteList: any;
  motionList: any;
  motionVoteCount: number = 0;
  /**Motion vote */
  resDataCreateMotionVote: any;
  isDisplayVoteList: boolean = false;
  constructor(private _router: Router,
    private readonly formBuilder: FormBuilder,
    private boardTaskApiService: BoardTaskApiService) {
    this.createCaseNoteForm();
    this.createBoardTaskStatusForm();
    this.createMotionForm();
    this.createReopenForm();
    this.createCompleteForm();
    this.createReviewAndRatingForm();
  }

  ngOnInit() {

    //this.boardTaskApiService.caseDetailId = "962c6825-64e2-479c-af9c-96b7a56f7914";
    //this.boardTaskApiService.caseDetailId = "93c74473-c0b5-40d9-9653-6ed4fefe5fa9";
    // this.boardTaskApiService.boardTaskDetailId = "5a2ffecb-9a48-4452-bb50-1e4edb48adbb";
    // this.boardTaskApiService.boardTaskDetailId = "8260D2AB-2A8F-E811-8C6E-0004FFB3BC58";
    // this.boardTaskApiService.caseId = "174468EC-34A1-E811-B96F-0004FFB07FAD";
    // this.boardTaskApiService.domain = "testassociation";
    // this.boardTaskApiService.boardTaskDetailId = "5a2ffecb-9a48-4452-bb50-1e4edb48adbb";
    // this.boardTaskApiService.caseId = "d390ad0b-3383-4936-beb8-6f45999fd40f";
    // this.boardTaskApiService.boardTaskStatus = "Canceled";
    //  this.boardTaskApiService.domain = "testassociation";
    // this.boardTaskApiService.boardTaskDetailId = "8cb7b277-1932-4c96-bacf-d9713a506fc1";
    // this.boardTaskApiService.caseId = "47655aed-fbb2-4821-be4e-ecbf3086cdfd";
    // this.boardTaskApiService.boardTaskStatus = "New";
    if (this.boardTaskApiService.domain !== undefined && this.boardTaskApiService.domain !== "" && this.boardTaskApiService.domain !== null
      && this.boardTaskApiService.boardTaskDetailId !== undefined && this.boardTaskApiService.boardTaskDetailId !== "" && this.boardTaskApiService.boardTaskDetailId !== null
      && this.boardTaskApiService.caseId !== undefined && this.boardTaskApiService.caseId !== "" && this.boardTaskApiService.caseId !== null
      && this.boardTaskApiService.boardTaskStatus !== "" && this.boardTaskApiService.boardTaskStatus !== null && this.boardTaskApiService.boardTaskStatus !== undefined) {
      this.boardTaskStatus = this.boardTaskApiService.boardTaskStatus;
      this.getData();
    } else {
      this._router.navigate(["/board-task-list"]);
    }
  }
  getData() {
    this.boardTaskApiService.getBoardTaskDetails(this.boardTaskApiService.boardTaskDetailId, this.boardTaskApiService.domain).subscribe(res => {
      this.resData = res;
      console.log(res);
      if (this.resData.RequestDetail.Success === true) {
        this.isApiResponseCome = true;
        this.boardTaskDetailList = this.resData.RequestDetail.BoardTask;
        this.documentList = this.resData.RequestDetail.Document;
        this.caseNoteList = this.resData.RequestDetail.CaseNotes;
        this.motionList = this.resData.RequestDetail.Motion;
        if (this.motionList.Votes !== null) {
          this.motionVoteCount = this.motionList.Votes.length;
        }
        if (this.boardTaskDetailList !== null) {
          this.boardTaskStatus = this.boardTaskDetailList.BoardTaskStatus;
        }
      } else if (this.resData.Errors.length === 0) {
        this.isApiResponseCome = true;
        this.boardTaskDetailList = this.resData.RequestDetail.BoardTask;
        this.documentList = this.resData.RequestDetail.Document;
      }
      else {
        alert("Details Not Found");
        this._router.navigate(["/board-task-list"]);
      }
    },
      (err) => {
        console.log(err);
      }
    )
  }
  /*Case Note Add Module*/
  createCaseNoteForm() {
    this.frmCreateCaseNote = this.formBuilder.group({
      caseNoteId: [''],
      comments: ['', Validators.required]
    });
  }

  onUploadChange(evt: any) {
    if (evt.target.files && evt.target.files[0]) {
      var filesAmount = evt.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.fileData.push({
            inputStream: event.target.result,
            name: evt.target.files[i].name,
            type: evt.target.files[i].type,
            mediaType: evt.target.files[i].name.substring(evt.target.files[i].name.indexOf("."))
          });
        }
        reader.readAsDataURL(evt.target.files[i]);
      }
    }
  }

  onSubmitCaseNote() {
    if (this.frmCreateCaseNote.valid) {
      this.isSubmitBtnDisabled = true;
      let model = this.createBoardTaskFormModel();
      this.boardTaskApiService.createCaseNote(model).subscribe(res => {
        this.isSubmitBtnDisabled = false;
        this.resDataCreate = res;
        if (this.resDataCreate.caseRequestListResults[0].Success === true) {
          alert("Case note save successfully");
          this.getData();
          this.resetCaseNoteForm();
        }
        else if (this.resDataCreate.caseRequestListResults[0].Success === false) {
          alert("Not Save");
        }
      });
    }
  }

  createBoardTaskFormModel() {
    const model: CaseNoteModel = {
      AssociationId: this.associationId,
      TypeOfDocument: this.typeOfDocument,
      Document: this.fileData,
      Domain: this.boardTaskApiService.domain,
      CaseNotes:
      {
        CaseNoteId: this.frmCreateCaseNote.controls.caseNoteId.value,
        Note: this.frmCreateCaseNote.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: NoteType.BoardMember,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask
      }
    }
    return model;
  }

  resetCaseNoteForm() {
    this.frmCreateCaseNote.reset();
    this.formDirective.resetForm();
    this.isSubmitBtnDisabled = false;
    this.fileData = [];
  }

  /*Update status of board task*/

  createBoardTaskStatusForm() {
    this.frmCreateBoardTaskStatus = this.formBuilder.group({
      comments: ['', Validators.required]
    });
  }

  onSubmitBoardTaskStatus() {
    if (this.frmCreateBoardTaskStatus.valid) {
      this.isSubmitBtnDisabledBoardTaskStatus = true;
      let model = this.createBoardTaskStatusFormModel();
      this.boardTaskApiService.updateBoardTaskStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledBoardTaskStatus = false;
        this.resDataCreateBoardTaskStatus = res;
        if (this.resDataCreateBoardTaskStatus.caseRequestListResults[0].Success === true) {
          alert("Board cast status updated successfully");
          this.getData();
          this.resetBoardTaskStatusForm();
        }
        else if (this.resDataCreateBoardTaskStatus.caseRequestListResults[0].Success === false) {
          alert("Board cast not status updated");
        }
      });
    }
  }

  createBoardTaskStatusFormModel() {
    const model: UpdateBoardTaskStatus = {
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      StatusType: BoardTaskStatus.Canceled,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreateBoardTaskStatus.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: NoteType.BoardMember,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask
      }
    }
    return model;
  }


  resetBoardTaskStatusForm() {
    this.frmCreateBoardTaskStatus.reset();
    this.formDirectiveBoardTaskStatus.resetForm();
    document.getElementById('closeModelCreateBoardTaskStatus').click();

  }


  /*Create motion of board task */
  createMotionForm() {
    this.frmCreateMotion = this.formBuilder.group({
      comments: ['', Validators.required]
    });
  }

  onSubmitMotion() {
    if (this.frmCreateMotion.valid) {
      this.isSubmitBtnDisabledMotion = true;
      let model = this.createMotionFormModel();
      this.boardTaskApiService.createMotion(this.boardTaskApiService.boardTaskDetailId, model).subscribe(res => {
        this.isSubmitBtnDisabledMotion = false;
        this.resDataCreateMotion = res;
        if (this.resDataCreateMotion.caseRequestListResults[0].Success === true) {
          alert("Motion saved successfully");
          this.getData();
          this.resetMotionForm();
        }
        else if (this.resDataCreateMotion.caseRequestListResults[0].Success === false) {
          alert("Motion not saved");
        }
      });
    }
  }

  createMotionFormModel() {
    const model: MotionModel = {
      MotionId: '',
      CaseId: this.boardTaskApiService.caseId,
      AssociationId: this.associationId,
      CaseFeatureType: CaseFeatureType.Motion,
      CreatedByUserId: this.createdByUserId,
      CreatedByUserName: this.createdByUserName,
      AssociationName: this.associationName,
      Description: this.frmCreateMotion.controls.comments.value
    }
    return model;
  }


  resetMotionForm() {
    this.frmCreateMotion.reset();
    this.formDirectiveMotion.resetForm();
    document.getElementById('closeModelCreateMotion').click();
  }

  /**Create Motion Vote */
  createMotionVote(voteStatus) {
    let model = this.createMotionVoteModel(voteStatus);
    this.boardTaskApiService.createMotionVote(this.boardTaskApiService.caseId, this.boardTaskApiService.boardTaskDetailId, this.associationId, model).subscribe(res => {
      debugger;
      this.resDataCreateMotionVote = res;
      if (this.resDataCreateMotionVote.caseRequestListResults[0].Success === true) {
        debugger;
        this.motionList = this.resDataCreateMotionVote.caseRequestListResults[0].Motion;
        //alert("Motion vote added");
        //this.getData();
      }
      else if (this.resDataCreateMotionVote.caseRequestListResults[0].Success === false) {
        alert("Motion vote not added");
      }
    });
  }

  createMotionVoteModel(voteStatus) {
    let vote = false;
    if (voteStatus === "Approve") {
      vote = true;
    }
    const model: VotesModel = {
      Vote: vote,
      CreatedByUserId: this.createdByUserId,
      CreatedByUserName: this.createdByUserName
    }
    return model;
  }

  /*Display list of vote*/
  displayVoteListToggle() {
    this.isDisplayVoteList
    if (this.isDisplayVoteList)
      this.isDisplayVoteList = false;
    else
      this.isDisplayVoteList = true;
  }

  /*Create Reopen of board task */
  createReopenForm() {
    this.frmCreateReopen = this.formBuilder.group({
      comments: ['', Validators.required]
    });
  }

  onSubmitReopen() {
    if (this.frmCreateReopen.valid) {
      this.isSubmitBtnDisabledReopen = true;
      let model = this.createReopenFormModel();
      this.boardTaskApiService.updateBoardTaskStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledReopen = false;
        this.resDataCreateReopen = res;
        if (this.resDataCreateReopen.caseRequestListResults[0].Success === true) {
          alert("Reopen saved successfully");
          this.getData();
          this.resetReopenForm();
        }
        else if (this.resDataCreateReopen.caseRequestListResults[0].Success === false) {
          alert("Reopen not saved");
        }
      });
    }
  }

  createReopenFormModel() {
    const model: UpdateBoardTaskStatus = {
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      StatusType: BoardTaskStatus.InProgress,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreateReopen.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: NoteType.BoardMember,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask
      }
    }
    return model;
  }


  resetReopenForm() {
    this.frmCreateReopen.reset();
    this.formDirectiveReopen.resetForm();
    document.getElementById('closeModelReopen').click();
  }



  /*Create Complete of board task */
  createCompleteForm() {
    this.frmCreateComplete = this.formBuilder.group({
      comments: ['', Validators.required]
    });
  }

  onSubmitComplete() {
    if (this.frmCreateComplete.valid) {
      this.isSubmitBtnDisabledComplete = true;
      let model = this.createCompleteFormModel();
      this.boardTaskApiService.updateBoardTaskStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledComplete = false;
        this.resDataCreateComplete = res;
        if (this.resDataCreateComplete.caseRequestListResults[0].Success === true) {
          alert("Reopen saved successfully");
          this.getData();
          this.resetCompleteForm();
        }
        else if (this.resDataCreateComplete.caseRequestListResults[0].Success === false) {
          alert("Reopen not saved");
        }
      });
    }
  }

  createCompleteFormModel() {
    const model: UpdateBoardTaskStatus = {
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      StatusType: BoardTaskStatus.Completed,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreateComplete.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: NoteType.BoardMember,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask
      }
    }
    return model;
  }


  resetCompleteForm() {
    this.frmCreateComplete.reset();
    this.formDirectiveComplete.resetForm();
    document.getElementById('closeModelComplete').click();
  }


  /*Create Review and Rating of board task */
  createReviewAndRatingForm() {
    this.frmCreateReviewAndRating = this.formBuilder.group({
      comments: ['', Validators.required]
    });
  }

  onSubmitReviewAndRating() {
    if (this.frmCreateReviewAndRating.valid) {
      this.isSubmitBtnDisabledReviewAndRating = true;
      let model = this.createReviewAndRatingFormModel();
      this.boardTaskApiService.updateBoardTaskStatus(model).subscribe(res => {
        this.isSubmitBtnDisabledReviewAndRating = false;
        this.resDataCreateReviewAndRating = res;
        if (this.resDataCreateReviewAndRating.caseRequestListResults[0].Success === true) {
          alert("Reopen saved successfully");
          this.getData();
          this.resetReviewAndRatingForm();
        }
        else if (this.resDataCreateReviewAndRating.caseRequestListResults[0].Success === false) {
          alert("Reopen not saved");
        }
      });
    }
  }

  createReviewAndRatingFormModel() {
    const model: UpdateBoardTaskStatus = {
      RequestId: this.boardTaskApiService.boardTaskDetailId,
      StatusType: BoardTaskStatus.Canceled,
      CaseNotes:
      {
        CaseNoteId: '',
        Note: this.frmCreateReviewAndRating.controls.comments.value,
        CaseId: this.boardTaskApiService.caseId,
        CreatedByUserId: this.createdByUserId,
        NotesType: NoteType.BoardMember,
        CreatedByUserName: this.createdByUserName,
        CaseFeatureType: CaseFeatureType.BoardTask
      }
    }
    return model;
  }


  resetReviewAndRatingForm() {
    this.frmCreateReviewAndRating.reset();
    this.formDirectiveReviewAndRating.resetForm();
    document.getElementById('closeModelReviewAndRating').click();
  }

  countRate(evt: any) {
    console.log(evt);
    this.countRating = this.countRating + 1;
  }

}
