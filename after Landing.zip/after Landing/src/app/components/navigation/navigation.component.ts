import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss']
})
export class NavigationComponent implements OnInit {

  nav = false;

  constructor() { }

  ngOnInit() {
  }

  addClass()
  {
    if(this.nav)
      this.nav = false;
    else 
      this.nav = true;
  }
}
