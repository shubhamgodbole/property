import { Component, OnInit } from '@angular/core';
import { PaymentsApiService } from 'src/app/services/payments-api.service';

@Component({
  selector: 'app-delienquency',
  templateUrl: './delienquency.component.html',
  styleUrls: ['./delienquency.component.scss']
})
export class DelienquencyComponent implements OnInit {
  resData: any;
  delienquencySheetList: any;
  filterDelienquencyList: any;
  constructor(private paymentsApiService: PaymentsApiService) { }

  ngOnInit() {
    this.getData();
  }

  getData() {
    //For Static Data used associationId
    let customerAgingReport = {
      "Year": 2018,
      "Month": 3,
      "MonthInterval": 0,
      "Association": "TCH"
    };
    this.paymentsApiService.getDeliquency(customerAgingReport).subscribe(res => {
      this.resData = res;
      this.delienquencySheetList = this.resData.CustomerAgingReport.ReportDetailList;
      this.filterDelienquencyList = this.resData.CustomerAgingReport.ReportDetailList;
    },
      (err) => {
        console.log(err);
      }
    )
  }
}
