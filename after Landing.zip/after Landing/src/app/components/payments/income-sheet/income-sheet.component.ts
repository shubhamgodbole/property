import { Component, OnInit } from '@angular/core';
import { PaymentsApiService } from 'src/app/services/payments-api.service';

@Component({
  selector: 'app-income-sheet',
  templateUrl: './income-sheet.component.html',
  styleUrls: ['./income-sheet.component.scss']
})
export class IncomeSheetComponent implements OnInit {

  resData: any;
  incomeSheetList: any;
  filterIncomeSheetList: any;
  constructor(private paymentsApiService: PaymentsApiService) { }

  ngOnInit() {
    this.getData();
  }
  getData() {
    //For Static Data used associationId
    let incomeSheetReport = {
      "Year": 2018,
      "Month": 3,
      "MonthInterval": 0
    };
    this.paymentsApiService.getIncomeSheet(incomeSheetReport).subscribe(res => {
      this.resData = res;
      this.incomeSheetList = this.resData.IncomeSheetReport.AccountHeaderList;
      this.filterIncomeSheetList = this.resData.IncomeSheetReport.AccountHeaderList;
    },
      (err) => {
        console.log(err);
      }
    )
  }
}
