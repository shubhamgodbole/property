import { Component, OnInit } from '@angular/core';
import { PaymentsApiService } from 'src/app/services/payments-api.service';
import { BalanceSheetReportModel, AccountHeaderModel, AccountSubHeaderModel, AccountDetailsModel } from './balance-sheet-model';

@Component({
  selector: 'app-balance-sheet',
  templateUrl: './balance-sheet.component.html',
  styleUrls: ['./balance-sheet.component.scss']
})
export class BalanceSheetComponent implements OnInit {
  resData: any;
  balanceSheetList: any;
  filterbalanceSheetList: any;
  constructor(private paymentsApiService: PaymentsApiService) { }

  ngOnInit() {
    this.getData();
    this.getDataUsingModel();
  }

  getData() {
    //For Static Data used associationId
    let balanceSheetReport = {
      "Year": 2018,
      "Month": 3,
      "MonthInterval": 0
    };
    this.paymentsApiService.getBalanceSheet(balanceSheetReport).subscribe(res => {
      this.resData = res;
      this.balanceSheetList = this.resData.BalanceSheetReport.AccountHeaderList;
      this.filterbalanceSheetList = this.resData.BalanceSheetReport.AccountHeaderList;
    },
      (err) => {
        console.log(err);
      }
    )
  }

  getDataUsingModel() {
    //For Static Data used associationId
    let balanceSheetReport = {
      "Year": 2018,
      "Month": 3,
      "MonthInterval": 0
    };
    this.paymentsApiService.getBalanceSheet(balanceSheetReport).subscribe(res => {
      this.resData = res;
      this.balanceSheetList = this.resData.BalanceSheetReport.AccountHeaderList;
      this.filterbalanceSheetList = this.resData.BalanceSheetReport.AccountHeaderList;
      let accountHeaderModelList = new Array<AccountHeaderModel>();
      for (let i = 0; i < this.balanceSheetList.length; i++) {
        let accountHeaderModel: AccountHeaderModel = new AccountHeaderModel();
        accountHeaderModel.header = this.balanceSheetList[i].Header;
        let accountSubHeaderModelList = new Array<AccountSubHeaderModel>();
        for (let j = 0; j < this.balanceSheetList[i].AccountSubHeaderList.length; j++) {
          let accountSubHeaderModel: AccountSubHeaderModel = new AccountSubHeaderModel();
          accountSubHeaderModel.subHeader = this.balanceSheetList[i].AccountSubHeaderList[j].SubHeader;
          let accountDetailsModelList = new Array<AccountDetailsModel>();
          for (let k = 0; k < this.balanceSheetList[i].AccountSubHeaderList[j].AccountDetailsList.length; k++) {
            let accountDetailsModel: AccountDetailsModel = new AccountDetailsModel();
            accountDetailsModel.accountMain = this.balanceSheetList[i].AccountSubHeaderList[j].AccountDetailsList[k].AccountMain;
            accountDetailsModel.accountName = this.balanceSheetList[i].AccountSubHeaderList[j].AccountDetailsList[k].AccountName;
            accountDetailsModel.operatingMST = this.balanceSheetList[i].AccountSubHeaderList[j].AccountDetailsList[k].ReportDetails.OperatingMST;
            accountDetailsModel.reserveMST = this.balanceSheetList[i].AccountSubHeaderList[j].AccountDetailsList[k].ReportDetails.ReserveMST;
            accountDetailsModel.totalMST = this.balanceSheetList[i].AccountSubHeaderList[j].AccountDetailsList[k].ReportDetails.TotalMST;
            accountDetailsModelList.push(accountDetailsModel);
          }
          accountSubHeaderModelList.push(accountSubHeaderModel);
        }
        accountHeaderModelList.push(accountHeaderModel);
      }
      console.log(accountHeaderModelList);
    },
      (err) => {
        console.log(err);
      }
    )
  }
}
