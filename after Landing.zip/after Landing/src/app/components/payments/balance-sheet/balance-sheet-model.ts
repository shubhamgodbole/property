export class BalanceSheetReportModel
{
    accountHeaderModel: AccountHeaderModel[];
}
export class AccountHeaderModel
{
    header: string;
    accountSubHeaderModel:AccountSubHeaderModel[];
    total:TotalModel
}
export class AccountSubHeaderModel{
    subHeader:string;
    accountDetailsList:AccountDetailsModel[]
}
export class AccountDetailsModel
{
    accountMain:string;
    accountName:string;
    operatingMST:string;
    reserveMST:string;
    totalMST:string
}
export class TotalModel
{
    operatingMST:string;
    reserveMST:string;
    totalMST:string
}
