import { Component, OnInit } from '@angular/core';
import { PaymentsApiService } from 'src/app/services/payments-api.service';

@Component({
  selector: 'app-prepayment',
  templateUrl: './prepayment.component.html',
  styleUrls: ['./prepayment.component.scss']
})
export class PrepaymentComponent implements OnInit {

  resData: any;
  prepaymentSheetList: any;
  filterprepaymentList: any;
  constructor(private paymentsApiService: PaymentsApiService) { }

 
  ngOnInit() {
    this.getData();
  }

  getData() {
    //For Static Data used associationId
    let customerAgingReport = {
      "Year": 2018,
      "Month": 3,
      "MonthInterval": 0,
      "Association": "TCH"
    };
    this.paymentsApiService.getPrePayment(customerAgingReport).subscribe(res => {
      this.resData = res;
      this.prepaymentSheetList = this.resData.CustomerAgingReport.ReportDetailList;
      this.filterprepaymentList = this.resData.CustomerAgingReport.ReportDetailList;
    },
      (err) => {
        console.log(err);
      }
    )
  }
}
